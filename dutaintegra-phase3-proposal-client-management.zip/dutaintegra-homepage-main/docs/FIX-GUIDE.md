# Live-site fix guide — dutaintegra.my

Everything here is confirmed by rendering your production site in a real browser (all 11 routes), not by reading source. Each item has an exact fix.

Ordered by damage-per-minute-to-fix. **Items 1–3 are worth doing today.**

---

## 0. The repo situation — read this first

`github.com/shamelali/dutaintegraweb-main` **returns 404** — it's private (or renamed), so `git clone` fails for anyone without a token, including CI.

More importantly, there are **three public repos that are completely empty**:

| Repo | Public | Files | Last pushed |
|---|---|---|---|
| `shamelali/dutaintegraweb-main` | ❌ 404 | — | — |
| `shamelali/dutaintegraweb-live` | ✅ | **0 — "This repository is empty."** | 24 Sep 2026 |
| `shamelali/dutaintegra-solutions` | ✅ | **0 — "This repository is empty."** | 24 Sep 2026 |
| `shamelali/dutaintegra-solutions-live` | ✅ | **0 — "This repository is empty."** | 24 Sep 2026 |

Each has commits but no files on the default branch. That's the signature of either (a) work pushed to a branch other than `main`, or (b) a broken/abandoned deploy pipeline.

**Why it matters:** you have four near-identically-named repos, three of which are publicly visible, empty, and look abandoned. Two concrete risks:

1. **Deploy fragility.** If your deploy points at one of these and someone pushes to another, you get silent divergence — exactly the kind of thing that ships `svc4Desc` to production and nobody notices for weeks.
2. **Brand credibility.** A public repo named `dutaintegra-solutions-live` with a commits log and zero files is a strange thing for a prospect or a partner to find. Either make them private or archive them.

**Action:** delete or archive the three empty public repos, confirm which repo actually deploys, and make sure `main` on it has content (`git ls-tree -r origin/main --name-only | head`). Then add a `README` documenting the deploy path — future-you will need it.

I could not diff your source against my rebuild, since I can't read the repo. The rebuild is based on your live site's markup, copy, pricing and compiled CSS, so it matches what your users actually see.

---

## 1. 🔴 Missing PDPA consent checkbox on your own contact form — fix today

This is the most serious item on this list, because of what you sell.

Your live `/contact` form collects **fullName, email, company, phone, service, message** — and has **no consent checkbox, and no link to a privacy notice**.

Under the PDPA:
- **s.7(2)** requires the notice to be given *"as soon as practicable… when the data subject is first asked to provide his personal data."*
- **s.7(3)** requires that notice in **both Bahasa Malaysia and English**.
- Your site currently provides **neither**, on the form, or anywhere else (see item 2).

Then compare it to your own marketing: *"PDPA compliance audit & policy drafting"*, *"PDPA compliance review"* included in plans, and `/privacy` linked in the footer. Pointing a prospect at that combination during a sales conversation is a bad moment.

**The fix** is already written — the rebuilt homepage form has:
- A required consent checkbox that names the PDPA explicitly
- A link to the privacy notice
- Server-side validation still required (never trust the client)
- A `consent: true` field in the POST payload, so **you keep a record of consent** — which is what s.7 is actually about at audit time

Deploy `index.html` and this gap closes. If you want to patch the React form instead, copy the consent block from the rebuilt form.

---

## 2. 🔴 `/privacy`, `/terms`, `/cases`, `/stats`, `/insights` render **zero content**

All five routes return HTTP 200 and render **header + footer only**. Measured main-content length on each: **0 characters**.

This means:
- The **privacy notice you link to in your footer does not exist.** Combined with item 1, that's a visible PDPA failure on a PDPA vendor's own site.
- `/cases`, `/stats` and `/insights` are linked in the footer too — three links that lead nowhere.
- Search engines can index five thin pages under your domain.

**The fix:**
- **`/privacy` — done.** `privacy.html` is in this folder. Bilingual (s.7(3)), written against Act 709 as amended by the 2024 Amendment Act, complete with the 72-hour breach notification and 7-day data-subject notification clocks, DPO details, cross-border transfer position, retention table, and the five new data-subject rights including portability. **11 `[CONFIRM]` markers** are highlighted in amber — fill those in before you publish. A [CONFIRM] left visible on a live page is worse than no page, so grep for `class="fill"` before deploy.
- **`/terms`** — needs writing; a service agreement template is different work and I haven't invented one.
- **`/cases`** — either build it from real work (see `TESTIMONIAL-KIT.md`) or **remove the footer link** until you have something. A dead "Case Studies" link is worse than no link.
- **`/stats`** and **`/insights`** — remove from the footer until they exist.

---

## 3. 🔴 Three untranslated i18n placeholders (exact copy to paste)

Confirmed rendering as literal text in production:

| Route | Visible text | Position |
|---|---|---|
| `/services` | `svc4Desc` | Under "IT Security & PDPA Compliance" |
| `/services` | `svcStep4Desc` | Under "Support" in the Process section |
| `/about` | `aboutVal2Desc` | Under "Partnership, Not Transaction" |

Your components pass these keys correctly (`descKey: \`svc4Desc\``), so the bug is simply missing entries in your translation resource. Paste this in:

```json
{
  "en": {
    "svc4Desc": "Know what personal data you hold, where it lives, and what to do when something goes wrong.",
    "svcStep4Desc": "Ongoing monitoring, helpdesk and reporting. If something we built stops working, fixing it is our job — not your discovery.",
    "aboutVal2Desc": "We stay involved after go-live. Your problems are ours to solve, not yours to discover alone."
  },
  "ms": {
    "svc4Desc": "Ketahui data peribadi yang anda pegang, di mana ia disimpan, dan apa yang perlu dilakukan apabila berlaku masalah.",
    "svcStep4Desc": "Pemantauan, helpdesk dan pelaporan berterusan. Jika sesuatu yang kami bina berhenti berfungsi, membaikinya adalah tanggungjawab kami.",
    "aboutVal2Desc": "Kami kekal terlibat selepas sistem beroperasi. Masalah anda adalah tanggungjawab kami untuk selesaikan bersama."
  }
}
```

**Have the BM reviewed by a native speaker.** Machine-quality BM on a site whose whole pitch is "local expertise" is a quiet credibility leak — and it's the same class of error as item 4.

**Note on scale:** 181 content keys exist in the bundle (`svc1Title`…`svc5Feat6`, `quizQ1`…`quizQ3A4`, `contact*`, `about*`, `svcStep*`). Only 3 are broken *on the rendered routes today*, so the rest are probably defined. But the presence of these three suggests the key set and the translation resource have drifted. Worth a scripted check in CI: walk every `*Key` reference in the bundle and fail the build if any key is missing from the EN or MS resource. That's ~30 minutes of work that permanently retires this bug class.

---

## 4. 🟠 Starter lists "24/7 support" — but only in one place

Both `/services` and `/pricing` list **"24/7 support"** (or "24/7 system monitoring") as a **Starter** feature. Your Business tier separately lists "24/7 monitoring & alerts". Starter's own helpdesk line says *"business hours."*

A client reading carefully — or a competitor pointing at it — will ask which is true. **Pick one:**
- Either 24/7 monitoring on Starter (and then say what's *not* 24/7: human response), or
- Remove 24/7 from Starter entirely.

The rebuilt homepage already uses the second, defensible version: *"Remote helpdesk, business hours"*, *"Monthly system health check"*, with 24/7 monitoring appearing only in Business and Enterprise.

---

## 5. 🟠 "Get Notified" buttons on services you already sell

`/services` shows **"Get Notified"** next to all five offerings, including AI Software Development and Managed IT — services you sell today. A visitor reads that as *"not launched yet."*

On a **live** service, the second button should never be "Get Notified."

- Replace with **"See Pricing →"** or **"Get a Quote"**. (The copy `svcGetQuote` already exists in your bundle, so this is a one-line swap.)
- **Keep** "Get Notified" for Business Intelligence only. The rebuilt homepage does exactly this — BI stays flagged *Launching next* with a WhatsApp notify link, and it reads as roadmap rather than vapour.

---

## 6. 🟠 No SSM registration number anywhere

Malaysian B2B buyers check SSM. It costs nothing and it's one of the few trust signals you can add today that isn't a fabrication.

- Add it to the footer: `Duta Integra Solutions · [SSM No.] · Level 22, Tamarind Suites…`
- Add it to the privacy notice (`[CONFIRM]` marker #2)
- Add it to any proposal or audit document you send out

---

## 7. 🟡 The EN/BM toggle doesn't localise page content

On `/quiz` (and elsewhere), clicking **BM** changes the nav labels — *Perkhidmatan, Tentang, Harga* — but the page body stays in English. So a BM reader gets a BM shell around English content, and *"Run Your Free IT Audit / 3 quick questions…"* stays English.

That's worse than no toggle, because it looks broken.

**Fix:** either complete the BM resource for the routes that matter (home, services, pricing, contact — in that order), or **remove the BM toggle** until it's done. Half-translated is the only option that hurts you.

Priority order if you do localise: **contact form + homepage hero + pricing** — those are the three screens where a BM reader either converts or leaves.

---

## 8. 🟡 OG image, title tags, and structured data

- **No `og:image`.** Every WhatsApp and LinkedIn share of your site renders as a grey box. For a company whose primary channel is WhatsApp, this is a real, immediate loss. Add a 1200×630 image.
- **All routes share the homepage `<title>`.** `/pricing` and `/services` should each have their own title and description; right now they compete with the homepage for the same query.
- **No structured data.** The rebuilt homepage includes `ProfessionalService` JSON-LD with your five real offers and prices. Worth porting to the React app.

---

## 9. Verification checklist before you deploy

```
[ ] grep -r "svc4Desc\|svcStep4Desc\|aboutVal2Desc" → zero literal renders on /services, /about
[ ] grep -r 'class="fill"' privacy.html → zero [CONFIRM] markers left
[ ] /privacy, /terms load with real content (not 0 chars)
[ ] Footer links all resolve, or are removed
[ ] SSSM number in footer
[ ] Contact form has consent checkbox + privacy link, and consent is stored with the lead
[ ] ALLOWED_ORIGINS includes https://dutaintegra.my AND https://www.dutaintegra.my
[ ] og:image present and renders in a WhatsApp share test
[ ] Submit the live form yourself; confirm the enquiry arrives AND lands in ENQUIRY_STORE
[ ] BM toggle: every page it claims to translate is actually translated
```

Last item matters most: **submit your own form and watch it land.** Your server appends the enquiry to `ENQUIRY_STORE` *before* sending mail — that's a good decision, keep it. But it only helps if the origin is allowlisted. If `www` isn't on the list, every lead from `www.dutaintegra.my` is silently 403'd, and the visitor sees nothing happen.
