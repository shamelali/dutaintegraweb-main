# Fill-in sheet — the last step before publishing

`privacy.html` currently shows **9 amber instruction boxes** to anyone who opens it. They are internal notes ("`[CONFIRM: …]`") that were never removed. Publishing in that state would be self-inflicted: the one page where you claim PDPA compliance would display a to-do list.

Everything needed is collected in one file: **`config/identity.json`**. Fill it, run one command, done.

```bash
python3 /home/user/tools/fill.py --check     # what's still missing
python3 /home/user/tools/fill.py             # apply
python3 /home/user/tools/fill.py --revert    # undo
```

It refuses to write anything while a required value is still `<in angle brackets>`, so you cannot half-publish. It backs up both files first, and `--revert` restores them byte-for-byte (tested).

---

## 1. Effective date — required

The date the notice goes live. Shown in the header of both language versions.

```json
"effective_date": { "en": "<e.g. 15 October 2026>", "bm": "<e.g. 15 Oktober 2026>" }
```

Use the date you actually publish. If you later change the notice, update this date and add a line to §13 explaining what changed and when.

## 2. Business registration number — required

```json
"business_reg_no": { "value": "<your business registration number>" }
```

Two things to get right:

- **An Enterprise number is not a company number.** New format looks like `202403123456`. Older businesses still use a state-prefixed format like `SA0123456-A` (SA = Selangor, JH = Johor).
- It appears **twice** — once in the English notice, once in the Malay — and both are filled from this single value.

This number is also the blank field in the engagement letter's parties table.

## 3. DPO or data protection contact — required, read this first

```json
"dpo_or_contact": {
  "meets_dpo_threshold": false,
  "en": "<name or job title>",
  "bm": "<nama atau jawatan>"
}
```

**The threshold question matters more than the name.** The PDPA requires a DPO only if you process personal data of **more than 20,000** people, sensitive or financial data of **more than 10,000**, or carry out regular and systematic monitoring. As an IT provider serving SMEs, you almost certainly meet none of these.

That means: **do not call yourself a DPO.** Naming a DPO you are not required to have creates an obligation you then have to satisfy — registration with the Commissioner within 21 days, a dedicated mailbox, a formal appointment letter. It is a real commitment, not a label.

- **If you do not meet a threshold** (likely): set `meets_dpo_threshold: false`. The notice will call this person a **data protection contact**, and the mailto link is automatically redirected to `support@dutaintegra.my`.
- **If you do meet one:** set it to `true`. The notice will say **Data Protection Officer**, and you must then register at `daftar.pdp.gov.my` within 21 days.

This is the same advice you give clients. It applies to you.

## 4. Contact email — required

```json
"dpo_email": { "address": "dpo@dutaintegra.my", "en_note": "monitored during business hours", "bm_note": "dipantau pada waktu perniagaan" }
```

Either **create the `dpo@` mailbox** and keep this as-is, or set `address` to `support@dutaintegra.my` and delete the separate-mailbox sentence. What you must not do is publish a link to a mailbox that doesn't exist — the notice is a promise about how to reach you.

If you keep `dpo@` but are **not** appointing a DPO, consider `privacy@` or `datarequest@` instead. A `dpo@` address implies an appointed officer.

## 5. Retention periods — required decision

```json
"retention": { "confirmed": false }
```

The notice's retention table currently uses sensible defaults: **7 years** for accounting and contract records (Malaysian accounting and tax requirements), **24 months** for enquiries that don't become engagements.

**Check these against how you actually work.** If they match, set `confirmed: true` and the prompt is removed. If your practice differs, edit the table in `privacy.html` first, then set it to true.

The point of the exercise: a published retention period you don't follow is worse than one you do. Someone will eventually ask why you still hold a 2022 enquiry.

## 6. Cookies and analytics — required

```json
"cookies": {
  "en": "<what your site actually uses>",
  "bm": "<versi Bahasa Malaysia>"
}
```

**Right now the honest statement is a strong one.** `analytics.js` is cookie-free by design — it stores nothing in the browser and identifies no one. So the accurate sentence is:

> We do not use tracking cookies, advertising pixels or third-party analytics. Our lead-tracking script stores nothing in your browser.

That is worth stating explicitly rather than leaving vague, and for an IT provider it is a genuine differentiator against competitors running Google Analytics without a cookie notice.

**If you ever add analytics, a cookie banner or an ad pixel, you must update this the same week.** A notice that says "no tracking cookies" while tracking is exactly the kind of gap you charge clients to find.

Suggested BM:

> Kami tidak menggunakan kuki penjejakan, piksel pengiklanan atau analitik pihak ketiga. Skrip penjejakan petunjuk kami tidak menyimpan apa-apa dalam pelayar anda.

## 7. Proprietor name — required

```json
"proprietor_name": { "value": "<proprietor full name as per SSM>" }
```

Goes into the engagement letter's parties table. A sole proprietor is identified by name — you contract personally, not as an entity. The signature block already reads "Proprietor, Duta Integra Solutions", which matches.

---

## What the command does

| Field | Where it lands |
|---|---|
| effective date | `privacy.html` header, EN section |
| registration no. | `privacy.html` §1 **in both languages** |
| contact name | `privacy.html` §1 in both languages |
| DPO vs contact wording | `privacy.html` §1 — role label changes in both languages |
| contact email | `privacy.html` §1 mailto links throughout |
| retention | removes the prompt when confirmed |
| cookies | `privacy.html` §11, both languages |
| proprietor name | SOW parties table |

Then it reports the marker count. **9 → 0 means ready to publish.**

---

## Still outstanding after filling

| Item | Where | Note |
|---|---|---|
| **Malay reviewed by a native speaker** | `privacy.html` §BM | Non-negotiable if you're selling this service. Not something a script can do. |
| Business registration number | SOW + notice | Same value, filled by the script |
| `og-image.jpg` on the notice page | `privacy.html` head | Already referenced — verify it resolves once deployed |

## Order of operations for publishing

```bash
# 1. fill config/identity.json
python3 /home/user/tools/fill.py --check     # should print "All required values present"
python3 /home/user/tools/fill.py             # apply

# 2. confirm
grep -c 'class="fill"' privacy.html          # expect 0

# 3. deploy
#    follow DEPLOY.md — the notice goes to /privacy via _redirects
```

If anything looks wrong, `python3 /home/user/tools/fill.py --revert` puts both files back exactly as they were.
