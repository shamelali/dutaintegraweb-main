# Entity correction — Sdn Bhd → Enterprise

You confirmed the business is an **Enterprise** (sole proprietorship / individual business registered under the Business Registration Act 1956), not a Sdn Bhd (private limited company under the Companies Act 2016).

That is not just a name change. "Sdn Bhd" carries legal implications, and several places in the pack implied corporate status. All of it is now corrected.

---

## What changed

**16 files** updated. `Duta Integra Solutions Sdn Bhd` → `Duta Integra Solutions`.

| Area | Files |
|---|---|
| Site pages | `index.html`, `privacy.html`, `audit-scorecard.html`, `lead-magnet/pdpa-checklist.html` |
| Pack documents | `offer-sheet.html` + 7 client-pack documents |
| Docs | `FIX-GUIDE.md`, `HOMEPAGE-REVIEW.md`, both outreach packs, `draft-the-pack.md` |
| Regenerated | all 8 PDFs — verified as containing the new name and **zero** "Sdn Bhd" |

---

## The part that mattered more than the name

Five places asserted corporate legal status. Each is now factually correct for an Enterprise:

### 1. `privacy.html` — the public notice

**Was:** *"a company **incorporated in Malaysia** with registration number [CONFIRM: SSM registration number, e.g. 202401000000 (1234567-A)]"*

**Now:** *"a business **registered in Malaysia under the Business Registration Act 1956** with registration number [CONFIRM: business registration number, e.g. 202403123456 — or the older state format such as SA0123456-A]"*

Two things were wrong. An Enterprise is *registered*, not *incorporated* — incorporation is a Companies Act concept. And the example format shown was a **company number** (12-digit new format, or `1234567-A`); a business registration number looks different, and for older businesses still uses a state prefix like `SA0123456-A` or `JH0123456-A`.

The BM version was corrected in parallel: *diperbadankan* (incorporated) → *didaftarkan* (registered), with the Act named.

**The whole notice must be read as a sole proprietor's notice, not a company's.** There is no board, no company secretary, no separate legal personality — the proprietor is personally the data controller. If you are ever asked who the data controller is, the answer is you as the registered proprietor, trading as Duta Integra Solutions.

### 2. Engagement letter (`client-pack/08`) — parties and signature

**Was:** "Supplier: Duta Integra Solutions Sdn Bhd … Registration no. ____"

**Now:** adds an explicit line — *"A business registered in Malaysia under the Business Registration Act 1956, trading as Duta Integra."* — plus the business registration number **and a separate field for the proprietor's name**, which is the correct way to identify a sole proprietor as a contracting party.

**Signature block changed:** *"For and on behalf of Duta Integra Solutions"* → **"Proprietor, Duta Integra Solutions"**. A sole proprietor does not sign "for and on behalf of" the business — they *are* the business, and they sign personally.

### 3. Client templates made entity-neutral

`02-privacy-notice-TEMPLATE.html` and `09-kickoff-questionnaire.html` previously said "full registered **company** name" and gave company-number examples. A client could be a Sdn Bhd, an Enterprise, a partnership or a co-op, so the templates now ask for the **"registered name as it appears on your SSM certificate"** with both number formats shown as examples. This makes the templates usable for any client type, which they weren't before.

### 4. Form placeholder

The homepage contact form's Company field placeholder now reads `Syarikat Sdn Bhd / Enterprise`.

### 5. DPO pack

`05-dpo-appointment-pack.html` entity-type prompt now reads `Entity type (Sdn Bhd / Enterprise / etc.)`.

---

## What this means commercially — three things worth knowing

**1. The liability cap in §12 works differently, and it's worth understanding.** A Sdn Bhd shields the owner's personal assets; an Enterprise does not. You are personally liable for the business's obligations. §12 caps *contractual* liability at fees paid — keep it, and keep it at a level you could actually absorb. But be aware that a cap in a contract is not a guarantee of protection if someone sues the proprietor personally.

**2. "Registration no." is not a Companies Commission company number.** On tenders, RFPs and procurement forms, an Enterprise number is a different thing and some corporate buyers treat it differently. Not a problem — plenty of Malaysian businesses trade as Enterprises and win corporate work — but if a large client's procurement asks for a "company registration number", clarify rather than guess.

**3. Consider whether and when to convert.** Converting to a Sdn Bhd later means redoing the entity name on **every document in this pack**, plus the privacy notice, plus all client contracts. Cheap now, tedious later. Worth deciding deliberately rather than drifting. (Not my call — but if a client ever asks you to sign an MSA, that's usually the moment the question becomes real.)

---

## Still outstanding

The **business registration number itself is not filled in anywhere.** All 11 `.fill` markers in `privacy.html` remain, and the SOW has a blank for it. Both need your actual number before either document is published or sent.

```bash
grep -c 'class="fill"' privacy.html    # must be 0 before publishing
```

---

## Summary of verification

| Check | Result |
|---|---|
| `Sdn Bhd` remaining in own-identity contexts | **0** |
| Files renamed | 16 |
| PDFs regenerated | 8 — all contain "Enterprise", none contain "Sdn Bhd" |
| Offer sheet | 3 pages, 593 KB |
| Site routes | 14/14 PASS, no overflow, 0 JS errors |

The two remaining `Sdn Bhd` strings in the repo are deliberate and correct: a form placeholder accepting *any* company type, and a client-facing prompt asking *the client* what they are.
