# Roadmap status: safe repository work

This is the repository-only triage for roadmap items that can be completed
without inventing business facts, collecting credentials, or deploying.

## Safe to implement now

| Item | Evidence | Status |
|---|---|---|
| Static deploy-artifact and redirect integrity check | `public/`, `_redirects`, `_headers`, and `sitemap.xml` are in this checkout | **Done** — `tools/deploy-test.js` is wired into CI |
| Keep the privacy publish gate in CI | `tools/fill.py --check` exits non-zero until the notice is publishable | **Already covered** |
| Keep the existing no-network contract checks | `tools/i18n-test.js`, `analytics-test.js`, `send-email-test.js`, and `terms-check.js` use local fixtures/stubs | **Already covered**; the lead-store assertion now accounts for rate-limit KV writes |
| Document the local verification path | The project has no build step and the deploy guide lists host-specific checks | **Done** — see `DEPLOY.md` and the command list below |

## Requires owner input, external access, or real business data

These should remain blockers rather than being filled with guesses:

- Live deployment, DNS/Cloudflare setup, and post-deploy form submission require hosting access and environment configuration.
- Brevo delivery and the optional KV lead store require deployment secrets/bindings; the local contract test intentionally uses stubs.
- Enabling analytics requires a chosen provider and identifier/token, plus a matching privacy-notice decision.
- Testimonials, case studies, `/cases`, and outcome metrics require permission and real client evidence.
- BM copy review requires a native-speaker decision; automated key parity cannot validate language quality.
- `/stats` and `/insights` should stay redirected until real content exists.
- Archiving or deleting the empty GitHub repositories requires repository-owner access and a confirmed deploy source.
- SSM/identity fields must be confirmed from current business records; no new values were invented here.

## Local checks

Run from the application directory (`dutaintegra-homepage/`):

```bash
node tools/i18n-test.js
node tools/analytics-test.js
node tools/send-email-test.js
node tools/terms-check.js
node tools/deploy-test.js
python3 tools/fill.py --check
python3 tools/i18n-apply.py --dry
```

`nginx -t` remains a host-level check and can only run where nginx is
installed with the real server paths and certificates available.
