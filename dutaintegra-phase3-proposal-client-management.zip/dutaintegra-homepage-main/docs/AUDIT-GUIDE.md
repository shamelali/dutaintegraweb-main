# Free IT audit scorecard guide

This is the concise guide to the actual [`public/audit-scorecard.html`](../public/audit-scorecard.html). The scorecard is a static, paper-style self-assessment: it does not calculate, save or submit answers by itself.

## Choose the right free path

These are three different offers:

- **Free PDPA gap check** — a focused, approximately 30-minute check of the privacy notice and consent capture, with a written summary at no charge. Use the homepage compliance section: [local `/#pdpa`](../public/index.html#pdpa) or the hosted [compliance section `/#pdpa`](https://dutaintegra.my/#pdpa).
- **Broad free IT audit** — an initial, indicative review of infrastructure, security, backups, workflows and automation opportunities. Use the homepage audit form: [local `/#audit`](../public/index.html#audit) or hosted [`/#audit`](https://dutaintegra.my/#audit). The homepage says a person replies within one business day. The form requires name, work email, service, problem description and consent; company and WhatsApp are available fields, with company/phone optional in the current markup.
- **25-point scorecard self-assessment** — complete the scorecard yourself, total five sections, and use the band to choose priorities. Open the [local scorecard](../public/audit-scorecard.html) or the hosted [`/audit-scorecard.html`](https://dutaintegra.my/audit-scorecard.html).

## Five steps

1. Fill the context fields: company, name/role, date, staff/devices, industry and auditor.
2. Mark each line from the actual five-level scale:
   - **0 — No:** not done, or you do not know whether it is done.
   - **1 — Ad hoc:** happens sometimes, usually when someone remembers.
   - **2 — Partly:** mostly in place, but with real gaps or no documentation.
   - **3 — Yes:** consistent, owned and documented.
   - **4 — Proven:** done, documented, and tested or verified in the last 12 months.
3. Answer the 25 lines across five 20-point sections: Backup & Recovery; Security & Access Control; Devices, Patching & Network; PDPA & Data Protection; Automation & Manual Work. Do not guess. The printed instructions allow unknown items to remain blank so they become the audit agenda; a blank is not a pass.
4. Add the five answers in each section (maximum 20), then add the five section totals (maximum 100). If responses are unfinished, label the result incomplete rather than presenting it as a complete score.
5. Read the band and fill the scorecard’s **Fix now**, **Fix this quarter** and **Leave alone** columns. Use the Notes page for incidents, unclear ownership and the two printed questions.

## Score bands

| Band | Total | Meaning printed on the scorecard |
| --- | ---: | --- |
| **Strong** | 80–100 | Better shape than most SMEs; review automation opportunities rather than starting with firefighting. |
| **Fair** | 60–79 | Foundations exist but gaps are real; usually two or three fixes away from genuinely stable. |
| **At risk** | 40–59 | One incident could make for a bad week; find the single highest-priority fix first. |
| **Critical** | 0–39 | Get a second pair of eyes on the setup quickly; the issues are usually fixable in weeks, but need doing. |

These are directional bands, not a compliance pass/fail. The scorecard is a self-assessment tool, not compliance certification or a legal opinion. A high score does not guarantee no incident; a low score does not by itself prove a PDPA breach, because that depends on what personal data is processed and why.

## Evidence prompts

Check safe business records or observations, without copying their contents:

- **Backup:** backup history, dated restore-test note, off-site/cloud copy, recovery-time estimate and named owner.
- **Security:** MFA/account settings, user list, leaver checklist, alert/log review and admin-role list.
- **Devices/network:** patch or endpoint dashboard, device inventory, network summary and fallback-test record.
- **PDPA:** data inventory, current BM/English privacy notice, breach-response owner/procedure, access logs and DPO appointment or documented decision.
- **Automation:** recurring-task example, report workflow, approval/form path, enquiry response record and system hand-off map.

## Contact gate and print limitations

The audit is free. The scorecard asks for contact details only when obtaining the printable report:

1. Provide required **name, company and valid work email**.
2. Optionally provide a WhatsApp number.
3. Tick required consent to be contacted about the audit and acknowledge the privacy notice.
4. Select **Unlock my report**. A successful response reveals **Print / Save as PDF**, which calls the browser print flow. This gate only controls the page’s own button; it is not browser DRM and cannot prevent native browser printing.

The gate is a contact/consent workflow, **not a security control, password prompt, authentication or access check**. The page does not persist contact state in `localStorage` or `sessionStorage`. A failed request leaves printing locked and shows a retry/contact message. The local file can be read and completed, but unlock calls `/api/send-email`; use the hosted [`/audit-scorecard.html`](https://dutaintegra.my/audit-scorecard.html) if a local request cannot reach the endpoint.

Do not enter passwords, API keys, recovery codes, customer records, identity documents or other customer data. For unfinished lines, leave a short safe note such as “owner unknown” or “restore test not recorded.”
