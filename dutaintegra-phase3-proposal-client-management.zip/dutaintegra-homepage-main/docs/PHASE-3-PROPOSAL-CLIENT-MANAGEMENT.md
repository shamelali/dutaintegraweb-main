# Phase 3 — Proposal & Client Management

## What this release adds

- A private `/workspace` dashboard for provisioned Duta Integra staff and client users.
- Cloudflare Access JWT verification in the API, including issuer, audience, expiry, not-before, key ID and RSA signature validation.
- D1 persistence for organisations, workspace users, leads, proposals, projects and an append-only application audit log.
- Staff workflows to create/update leads, draft proposals and track projects.
- Client-scoped proposal/project visibility; clients can accept or decline sent proposals belonging to their own organisation only.
- Input validation, parameterised SQL, bounded request bodies, no-store API responses, and role checks in the server-side API.

## Important: this is not live until provisioned

The ZIP does not create Cloudflare resources or change the live site. Do not treat the workspace as production-ready until all steps below are complete.

### 1. Create and bind D1

Create a D1 database in the correct Cloudflare account. Add a `DB` D1 binding to the Pages project with that database. Apply the migration:

```sh
npx wrangler d1 migrations apply <DB_NAME> --remote
```

The migration is `migrations/0002_workspace.sql`. Confirm that the project's deployment config also includes the existing KV and email bindings used by the public lead forms.

### 2. Configure Cloudflare Access

Create an Access application covering **both** `/workspace*` and `/api/workspace*` on the production hostname. Use an explicit allow policy for authorised staff/client identities. Do not protect only the HTML page: the API must be behind the same Access policy. Configure the Access team domain and application audience as Pages environment variables:

- `CF_ACCESS_TEAM_DOMAIN` — e.g. `your-team.cloudflareaccess.com` (hostname only or full HTTPS URL accepted).
- `CF_ACCESS_AUD` — the Access application's exact AUD tag.

The API independently verifies the `CF-Access-Jwt-Assertion` signature and claims. Do not bypass Access at the origin or expose a separate unprotected deployment hostname.

### 3. Provision users and organisations

Create the organisation and users through a reviewed SQL session; do not accept role or organisation assignments from a public signup form. Example (replace every placeholder):

```sql
INSERT INTO organizations (id, name) VALUES ('org_example', 'Example Sdn Bhd');
INSERT INTO workspace_users (email, display_name, role, organization_id)
VALUES ('staff@example.com', 'Workspace Admin', 'admin', NULL);
INSERT INTO workspace_users (email, display_name, role, organization_id)
VALUES ('client@example.com', 'Client Contact', 'client', 'org_example');
```

Use named business accounts, least privilege and an approved offboarding process. Staff roles are `admin` and `staff`; client users must be attached to exactly one organisation. Never provision access solely because someone knows an email address.

### 4. Verify in staging

1. Anonymous requests to `/workspace` and `/api/workspace` are denied by Cloudflare Access.
2. A valid Access identity absent from `workspace_users` receives `403` and no records.
3. Staff can create a lead, draft a proposal, update a lead status and view projects.
4. A client can see only proposals/projects for their `organization_id` and can accept/decline only proposals in `sent` state.
5. Attempt cross-organisation record IDs; API returns `404` without leaking record details.
6. Test malformed JSON, oversized bodies, invalid status values and expired/incorrect-audience tokens.
7. Confirm audit rows are written and backups/retention are configured for D1.
8. Run browser tests on desktop/mobile and verify form keyboard accessibility.

## API contract

Base path: `/api/workspace` (all routes require Cloudflare Access and a provisioned D1 user).

- `GET /api/workspace` — summary plus role-scoped leads/proposals/projects.
- `GET /api/workspace/leads` — staff lead list.
- `POST /api/workspace/leads` — staff creates lead.
- `PATCH /api/workspace/leads/:id` — staff updates lead status/notes.
- `GET /api/workspace/proposals` — staff sees all proposals; clients see their organisation's proposals.
- `POST /api/workspace/proposals` — staff creates draft/sent proposal with MYR amount and summary.
- `PATCH /api/workspace/proposals/:id` — staff updates status; client accepts/declines a sent proposal in their organisation.
- `GET /api/workspace/projects` — staff sees all projects; clients see their organisation's projects.
- `POST /api/workspace/projects` — staff creates a project for an existing organisation.
- `PATCH /api/workspace/projects/:id` — staff updates project status, next action or target date.

## Deliberate limitations in this release

- No public signup, password reset or email-magic-link implementation.
- No online payments, e-signature, invoice generation, file uploads or outbound proposal email.
- Proposal acceptance records a status only; it is not a legally binding electronic signature.
- Lead capture from the Phase 2 assessment is not automatically persisted to this workspace yet. Integrate it only after consent, data-minimisation and retention requirements are agreed.
- Staff creates organisation/client records through controlled provisioning; no self-service organisation creation.
- Prices are manually entered and must be reviewed; no automatic pricing or tax calculation.
