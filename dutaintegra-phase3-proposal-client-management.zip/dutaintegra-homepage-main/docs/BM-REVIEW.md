# Bahasa Malaysia review — handoff pack

Updated 18 October 2026 (first issued 4 October 2026, scope expanded after the
AI-operations repositioning).

> ## ✅ SIGNED OFF — 18 October 2026
>
> **Reviewer:** Shamel Ali (self-review — native BM speaker, per §5.3).
> **Scope reviewed:** all surfaces in §1, in priority order, including the
> three static bilingual halves, all 8 BM dictionaries, and the fragments.
> **Decisions made as part of this sign-off:**
>
> 1. **keizinan site-wide** (open question §3.1) — the Act's BM text uses
>    *keizinan*; `pdpa-checklist.html` already did. Applied: `privacy.html`
>    (4), homepage dict (5), `bm/security-pdpa.js` (5) — including
>    "menarik balik keizinan" for withdrawal and homepage line 2336 aligned.
> 2. **"Pengasas dan Developer" retained** (open question §3.2) — acceptable
>    in BM professional register; also matches `config/identity.json`.
> 3. **BM is now the site default** — reviewer-approved as part of this
>    sign-off: BM renders by default on every page, `?lang=en` opts back to
>    English, EN/BM parity and the no-storage rule unchanged. Verified in a
>    real browser (21/21 Playwright checks) and by all 13 test suites.
>
> **Suites at sign-off:** npm test 13/13 suites green; motion, responsive
> (6 routes × 6 widths) green.

---

Estimated effort: **3–4 hours** end to end, or split into two sessions
(§A PDPA-legal pages ~1.5 h; §B marketing + product pages ~2 h). The site
teaches a machine-checkable subset of the rules — key parity, leftover-English
inventory, CJK/Cyrillic leakage — and all of those gates are green. What only a
human catches is grammar, register, and legal nuance. That is what this pack
asks for.

---

## 1. What to review (in priority order)

The order is by stakes, not by size: PDPA-legal claims first, money second,
marketing third.

| # | Surface | Size | What it is | How to view |
|---|---|---|---|---|
| 1 | `/privacy` BM half | 13 sections, ~1,200 words | Notis Privasi — the PDPA notice itself. Makes legal claims: 72-hour Commissioner notification, 7-day individual notice, DPO-threshold wording, cross-border transfer assessment effective 1 April 2025 | `public/privacy.html`, `<section data-lang="bm" id="bm-notice">` (line ~310) — or `http://127.0.0.1:8788/privacy` → **Bahasa Malaysia** |
| 2 | `/pdpa-checklist` BM half | 5 sections + tables + FAQ, ~1,000 words | Public lead magnet. Machine-translated BM, linked from the homepage nav and a dedicated homepage section. Makes the strongest claims on the site: RM 1,000,000 maximum fine, 72 jam / 7 hari / 21 hari deadlines, DPO thresholds (20,000 / 10,000 subjects) | `public/lead-magnet/pdpa-checklist.html`, `<section data-lang="bm" id="bm-checklist">` (line ~328) |
| 3 | `/terms` BM half | 14 sections, ~1,800 words | Syarat Perkhidmatan — contract-grade register required. Fees section quotes live prices (managed IT from **RM 2,500/bulan**, out-of-scope work **RM 100 sejam**, 7-day project termination notice) | `public/terms.html`, `<section data-lang="bm" id="bm-terms">` (line ~291) |
| 4 | `/pricing` + `/connect` + `/connect/rate-calculator` BM dicts | 118 + 139 + 57 strings | The money pages. Price figures, the "illustrative reference data, **not** live carrier quotes" disclaimer wording, and the pilot-invite honesty section ("live courier feeds are NOT done", "no price yet") | `public/bm/pricing.js`, `public/bm/connect.js`, `public/bm/connect-rate-calculator.js`; plus inline `STR.ms` in `public/connect-rateshop.js` and `public/rate-calculator.js` (courier/spread/outcome sentences) |
| 5 | Homepage BM dict | **346 keys** | Nav, hero, calculator promises, FAQ (incl. the agent-oversight answer that promises BM privacy notices), form + PDPA consent wording, footer, mobile drawer | `public/index.html`, `var BM = {` (line ~2305). Preview: `http://127.0.0.1:8080/?lang=bm` |
| 6 | Four service pages | 81 + 81 + 82 + 81 strings | `/ai-operations`, `/managed-it`, `/security-pdpa`, `/websites` — product claims per page, plus shared nav | `public/bm/ai-operations.js`, `managed-it.js`, `security-pdpa.js`, `websites.js`, `chrome.js` (32 shared keys) |
| 7 | Fragments | small | 404 page (bilingual in-DOM, "Halaman tidak dijumpai"); Ask-AI BM answers (`public/ask-ai.js`, `bmAnswers` dict ~line 46, UI copy ~line 138); PDPA offer sheet EN/BM toggle (`public/pdpa-starter-pack/offer-sheet.html`) | Grep `lang="ms"` / `bmAnswers` in each file |

Total translated surface: **346 + 671 = 1,017 data-i18n strings** plus the three
static bilingual halves and the fragments. If time forces a split, §1–3 are the
sign-off gate; §4–7 can follow a week later.

## 2. What must stay in English (do NOT translate)

- Product name **PDPA Starter Pack**; brand **Duta Integra / Duta Integra Solutions**
- **RM** amounts (RM 2,500, RM 599…), day/month formats *may* be BM (`3 hari bekerja`)
- Addresses (Tamarind Suites…), `support@dutaintegra.my`, `+60 11-5403 4051`
- SSM number **202503195000 (TR0325441-K)**; certificate name **DUTA INTEGRA SOLUTIONS**
- Section numbers, URLs, code/API names, courier names (J&T Express, Ninja Van,
  Pos Laju, DHL eCommerce are trademarks used as text identifiers)
- `<option>` dropdown `value=` attributes are pinned to EN text by design —
  translate the label, never the value (the WhatsApp/form prefills depend on it)

## 3. Known-risk terms — check these specifically

Already corrected in a previous pass (verify the fix still reads naturally):

| Was (wrong) | Now | Why |
|---|---|---|
| cadangan **berharga** tetap | cadangan **harga** tetap | "berharga" = valuable, not fixed-price |
| invois **lewat bayar** | invois **tertunggak** | baku term for outstanding |
| **mengutip** harganya | **mengemukakan sebut harga** | "mengutip" = collect money |
| menamakan satu **penyokong utama** | menamakan seorang **pelulus** | approver ≠ supporter |
| Undang-undang **terpilih** | Undang-undang **yang terpakai** | governing law, not "selected" |
| **serta-minta** | **serta-merta** | typo |
| salah laku **berbuat sengaja** | salah laku **sengaja** | wilful misconduct |

Open questions for the reviewer:

1. **keizinan vs persetujuan — now a live inconsistency, needs one decision.**
   The Act's BM text uses *keizinan*. Current usage:
   `privacy.html` uses *persetujuan* (4 hits, zero *keizinan*);
   `pdpa-checklist.html` uses *keizinan* (7 hits, zero *persetujuan*);
   the homepage dict is mixed — 5× *persetujuan* but line 2336 reads
   `healthSignalPdpa:'Jurang PDPA, notis privasi dan keizinan'`.
   **Pick ONE for the whole site and say which files change.** Whichever way
   you decide, line 2336 must be aligned with the rest of the homepage dict.
2. **"Shamel Ali, Pengasas dan Developer"** (privacy §1 contact) — is "Developer"
   acceptable in BM professional register, or should it be *Pembangun Perisian* /
   *Pembangun*? Keep the agreed spelling after review; it goes in `config/identity.json`.
3. **Register** — the site voice is direct/informal ("kami", "anda"). Confirm the
   BM holds that voice without sliding into non-baku territory; terms.html legal
   sections and all of privacy.html should read *baku* (contract-grade).
4. **Consistency** across the three static halves — same concept, same word
   (e.g. *data peribadi*, *pemproses*, *tujuan pemprosesan*, *pengawal data*).
5. Anglicisms that survived translation: *audit IT, cloud, hosting, deliverable,
   invois, penglibatan/pelantikan, airway bill* — flag any that read wrong in
   context and give the preferred native term.
6. **PDPA deadline phrasing** — verify "dalam masa 72 jam", "tidak lewat tujuh
   hari", and "dalam 21 hari" (privacy §9/§10, checklist §1/§4) match how the
   amendments are usually phrased in Malaysian compliance material.
7. **Rate disclaimers** — every courier rate on the money pages is labelled
   "illustrative reference data, not live carrier quotes" and the tests enforce
   the disclaimer's presence. Confirm the BM wording of `rcDisclaimer`
   (connect-rate-calculator.js) and `rsDisclaimer` (connect.js), plus the inline
   `STR.ms` outcome sentences in `connect-rateshop.js` and `rate-calculator.js`,
   say plainly that the numbers must not be used to book or quote a customer.

Already fixed while preparing this pack (confirm the wording reads naturally):

| Where | Was (broken) | Now | Why |
|---|---|---|---|
| rate-calculator.js `STR.ms.zoneNote` | "Itulah **sebabnyaKwarta** perbandingan wujud" | "Itulah **sebabnya perbandingan kadar** wujud" | garbled token — no space, stray fragment; no test covers this inline string |

## 4. How to return corrections

One row per issue, so nothing is lost in chat:

```
| location (page + section) | current BM | suggested BM | reason |
|---|---|---|---|
| terms §5 fees | kami akan mengemukakan sebut harga… | (keep / change to…) | … |
```

- **Do not edit the files directly** — corrections come back as rows and are
  applied through the tools so the suites re-run after. Gates that must stay
  green: `i18n-test` 21/21 (346 homepage keys), `terms-check` 21/21,
  `services-test` 60/60, `connect-rateshop-test` 47/47, `deploy-test` 62/62,
  browser leftover-English inventory 0.
- One native speaker is enough; two is better for the legal half of terms and
  all of privacy.

## 5. Where to get a reviewer

1. **Fastest/free** — a Malaysian colleague or friend who writes formal BM
   (admin, lecturers, SSM/company secretarial staff are usually exacting).
2. **Professional** — Dewan Bahasa dan Pustaka editing services, or a freelance
   BM editor (Fiverr / local agencies). Ask for *"proofread BM baku, laman web
   korporat + notis privasi + syarat perkhidmatan"*. Budget: small — the static
   halves are ~4,000 words and the dictionary strings are short.
3. **Self-review** — you are a native speaker: work through §3's open questions
   first (the keizinan/persetujuan decision in particular), then skim the
   pages in the §1 priority order.

## 6. Sign-off gate (CLOSED — see the block at the top of this file)

- [x] §1–3 reviewed and corrections applied; suites re-run and green
- [x] keizinan/persetujuan decided site-wide (**keizinan**); homepage line 2336 aligned
- [x] `python3 tools/fill.py --check` → 0
- [x] `grep -c 'class="fill"' privacy.html` → 0
- [x] Re-visited `/?lang=en`, `/privacy`, `/terms`, `/pdpa-checklist`, the
      BM-default pages and the 404 route in a real browser (Playwright, 21 checks)
- [x] §4–7 reviewed
- [x] Reviewer: **Shamel Ali** — signed off **18 October 2026**
