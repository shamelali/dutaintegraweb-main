# AI Business Health Check

The homepage form posts minimal company information to `/api/business-health-check`:

- `company` — required
- `website` — required, `http` or `https`
- `registrationNumber` — optional
- `signals` — optional focus areas
- `language` — `en` or `bm`

The function reads a small, same-origin set of public website pages and returns findings with source URLs. It rejects private/local targets, limits redirects and page size, checks the browser origin, and applies a per-IP KV rate limit when the `LEADS` binding is available. It does not store scan results.

## Provider configuration

Without AI variables, the endpoint returns a transparent rule-based public-evidence report with `mode: "public evidence"`.

For an OpenAI-compatible reasoning provider, configure the following Cloudflare Pages variables:

- `AI_API_KEY` — secret
- `AI_BASE_URL` — for example `https://api.openai.com/v1` or the NVIDIA NIM API base
- `AI_MODEL` — provider model name
- `AI_PROVIDER` — `openai` for OpenAI models via the standard `/chat/completions` endpoint; omit it (or set `nim`) for an OpenAI-compatible `/chat/completions` endpoint such as NVIDIA NIM
- `AI_ENABLE_WEB_SEARCH` — optional, `true` only when the configured OpenAI model supports function-calling web search; defaults to off

OpenAI mode uses `/chat/completions`, which is available on all API accounts. NIM provides model inference but does not provide web search by itself, so NIM mode uses the submitted website evidence unless a separate search connector is added.

The output is a prioritised discovery aid. It is not a legal opinion, security certification, or proof of internal business controls. Human confirmation remains required before a proposal or compliance conclusion is issued.
