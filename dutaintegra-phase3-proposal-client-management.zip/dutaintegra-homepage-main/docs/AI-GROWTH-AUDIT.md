# Duta Integra AI Growth Audit

**Audit date:** 11 October 2026  
**Canonical site:** `https://dutaintegra.my`  
**Canonical repository:** `dutaintegra-homepage`  
**Production host:** Cloudflare Pages project `dutaintegra`

## Executive decision

Do not embed all five repositories into the production website. The current site
is a static, fast Cloudflare Pages site with one Pages Function for enquiry
handling. Keep that public surface small and dependable. Build an internal
operations layer around it instead:

1. **Marketing Skills + privacy-first measurement** for acquisition.
2. **Remotion** as an isolated content-production workspace.
3. **OpenHands** as a controlled engineering assistant with human approval.
4. **PersonaLive** only as a separately evaluated experiment.
5. **MuMuAINovel** stays out of the core system unless a specific content
   workflow justifies a new license and maintenance burden.

The best first product is not an avatar or a rebuilt website. It is a measurable
AI Business Health Check that turns a visitor into a qualified conversation and
gives Duta Integra a repeatable delivery brief.

## Current-state findings

### What is already strong

- The live apex responds with HTTP 200; `www` redirects to the apex with HTTP
  301.
- The site has a clear Malaysian SME position, visible pricing, a free audit,
  WhatsApp fallback, bilingual legal pages, and a strong no-lock-in promise.
- The homepage has `ProfessionalService`, `Service`, and `FAQPage` structured
  data, canonical metadata, Open Graph tags, `robots.txt`, and a sitemap.
- The lead form has visible labels, semantic input types, consent capture,
  origin validation, a honeypot, server-side validation, HTML escaping, rate
  limiting, and a WhatsApp fallback.
- `functions/api/send-email.js` stores an accepted lead in KV before calling
  Brevo, which protects against losing a lead during a mail-provider outage.
- The repository is intentionally dependency-light: 80 tracked files, static
  `public/` output, and no application framework or package manifest.
- Existing checks passed during this audit: i18n 19/19, analytics 17/17,
  email contract 23/23, terms 21/21, deploy artifact integrity 19/19, and
  redirect validation.

### Immediate gaps

1. **No usable production metrics yet.** `public/analytics.js` ships with
   `transport: 'noop'`. It records events only in `window.__di_events`, so
   management cannot currently measure assessment starts, WhatsApp clicks,
   form submissions, or source-to-lead conversion.
2. **The sitemap advertises route-shaped URLs that are not separate pages.**
   `/services`, `/pricing`, `/contact`, `/quiz`, and `/about` currently return
   the same homepage document and title through the catch-all. They should be
   removed from the sitemap until dedicated pages exist, or each should become
   a real page with its own canonical metadata.
3. **The live form reachability is verified, but delivery is not.** A live GET
   returns 405 and malformed JSON returns 400, proving the Function is deployed.
   That does not prove `BREVO_API_KEY`, `EMAIL_TO`, `ALLOWED_ORIGINS`, and the
   `LEADS` binding are correctly configured in production. A real test enquiry
   requires an explicit human-approved submission.
4. **Social proof is deliberately empty.** The homepage avoids invented
   testimonials, which is correct. The next conversion asset should be one or
   two permissioned customer stories or anonymised before/after case studies.
5. **The public funnel is one long page.** It is good for the initial launch,
   but service-specific landing pages are needed for search intent, campaign
   attribution, and clearer qualification.

## Recommended build order

### P0 — Measurement and crawl hygiene

- Remove the five phantom sitemap URLs, or create real pages before submitting
  them to search engines.
- Choose one privacy-compatible measurement path. Prefer Cloudflare Web
  Analytics or a first-party `/api/analytics` endpoint only after reviewing the
  privacy notice and retention policy.
- Add a small weekly scorecard: visits, assessment starts, WhatsApp clicks,
  form submissions, qualified leads, response time, proposal rate, and wins.
- Verify the production lead path with a controlled test enquiry and document
  the result without committing credentials or personal data.

### P1 — Turn the homepage into a qualification funnel

- Keep the current short enquiry form as the primary conversion path.
- Add a separate two-minute AI Business Health Check rather than adding many
  required fields to the form. Capture company size, industry, systems, and the
  most expensive repetitive task; return a useful summary and a next action.
- Pass a compact, non-sensitive assessment summary into the enquiry handoff so
  the consultant receives a usable discovery brief.
- Add dedicated pages for managed IT, AI automation, cloud migration, and PDPA
  support. Each page should have one audience, one promise, one proof point,
  one CTA, and one tracked source path.

### P1 — Build the internal marketing engine

- Use Marketing Skills for SEO audits, copy review, CRO hypotheses, content
  briefs, and campaign measurement.
- Use Remotion outside the site repository to render a small set of reusable
  templates: service explainer, founder introduction, audit walkthrough, and
  one industry-specific case study.
- Start with three industries where Duta Integra can speak credibly. Do not
  generate a large programmatic SEO footprint before the first pages produce
  qualified conversations.

### P2 — Automate delivery safely

- Pilot OpenHands in a separate development environment against a low-risk
  internal task. Require a task brief, scoped credentials, tests, review, and a
  human-approved merge/deploy step.
- Keep production secrets, customer files, email credentials, and Cloudflare
  write access outside the agent's default environment.
- Record task duration, review findings, rework, and customer impact before
  expanding the pilot.

### P3 — Validate experiments

- Treat PersonaLive as a separate prototype, not a dependency of the public
  site. Compare it with a normal text assistant on completion rate, cost,
  latency, accessibility, and qualified-lead rate.
- Keep MuMuAINovel excluded from the core architecture. Only revisit it for a
  narrowly defined content workflow after a code, dependency, and license
  review.

## Repository fit and commercial-risk notes

| Repository | Initial fit | License / operational note |
|---|---|---|
| `coreyhaines31/marketingskills` | **Adopt first** for SEO, CRO, copy, analytics, and growth workflows | MIT; review any linked partner integrations separately |
| `remotion-dev/remotion` | **Adopt second** in an isolated content workspace | Current license has company-size/commercial-use conditions; confirm whether Duta Integra needs a Company License before client work |
| `OpenHands/OpenHands` | **Pilot internally** for scoped engineering tasks | MIT; the surrounding model providers, tools, credentials, and customer data still require separate review |
| `GVCLab/PersonaLive` | **Prototype only** | Repository license is GPL-3.0; do not embed or combine it into a proprietary customer-facing product without legal review |
| `xiamuceer-j/MuMuAINovel` | **Defer** | Repository license is GPL-3.0; low direct business fit and high maintenance/architecture risk for this site |

These are implementation-screening notes, not legal advice. Preserve license
files and obtain a formal review before distributing derivative software or
selling a product that incorporates a copyleft component.

## Success gates

Do not move to the next phase until the current phase has evidence:

- **Measurement:** at least one week of trustworthy event data and a known
  source for each qualified lead.
- **Health Check:** completion rate, qualified-lead rate, and response time are
  recorded; the report gives value even when the visitor does not buy.
- **Marketing engine:** three campaign assets and one landing-page experiment
  are published with attributable CTAs.
- **OpenHands pilot:** every change has a task record, test result, reviewer,
  and rollback path.
- **Advanced experiments:** continue only when the experiment beats a simpler
  text or manual workflow on a defined business metric.

## Next implementation slice

The smallest high-value slice is:

1. Correct the sitemap so it contains only real indexable pages.
2. Add a first-party, consent/privacy-compatible measurement decision without
   enabling a third-party tracker by accident.
3. Design the AI Business Health Check data contract and result states.
4. Build one dedicated landing page for the highest-margin service.
5. Verify the complete browser → Function → KV/Brevo path with a controlled
   test, then deploy through Cloudflare Pages.

No architecture rewrite is justified yet. The current static + Pages Function
foundation is sufficient for this slice.
