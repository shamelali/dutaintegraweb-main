# Homepage review — `index.html`

Reviewed at 1280px and 390px against the served page (`localhost`, honouring `_redirects`). Measured, not eyeballed — every number below comes from a script in `/home/user/tools/`.

**Verdict: the page is in good shape and does its job.** Two real defects worth fixing, one housekeeping item, and a list of things I checked that turned out to be fine.

---

## Defect 1 — 360px of dead space in the hero

**The most visible problem on the page.** The hero is a two-column grid. Measured heights:

| | Height |
|---|---|
| Left column (headline, sub, CTAs, assurances) | **632px** |
| Right column (ROI calculator) | **992px** |
| Dead space under the left column | **360px — 31% of the hero** |

The calculator is 360px taller than everything beside it, so the left column ends roughly a third of the way up and leaves an empty hole before the trust bar. On the first screen of the site. At every desktop width.

It is not a bug — the grid is `align-items:center`, so the left column is correctly centred against the taller card. But centring a 632px column against a 992px one produces a gap above *and* below, and the eye reads the lower one as unfinished.

**Fix options, best first:**

1. **Move the free PDPA checklist CTA into the hero's empty space.** You now have a genuinely useful free asset that did not exist when the hero was built. A compact "Free: PDPA compliance checklist — no signup" card under the assurance list fills the space with something that earns its place *and* feeds the new lead magnet.
2. **Distribute the left column** — `justify-content:space-between` on the left column so the assurance list sits near the bottom. Cheap, but it spreads 632px of content across 992px, so the spacing gets loose and slightly odd.
3. **Shorten the calculator.** Dropping the two small result tiles (RM 2,304 / RM 799) reclaims ~180px. But those tiles are the payoff of the interaction — don't remove them.

Option 1 is the only one that adds value rather than redistributing empty space. It also puts the lead magnet in front of every visitor instead of only those who scroll to the PDPA section.

---

## Defect 2 — two different things called "PDPA" at the same price

The PDPA section was added after the pricing section, and the two now contradict each other in a way a buyer will notice:

| Where | What it says |
|---|---|
| Services card | Security & PDPA Compliance — **RM 1,800** from, per audit |
| Projects list | **PDPA Audit** — From **RM 1,800** — "Audit, policy documentation and staff training." |
| New PDPA section | **PDPA Starter Pack** — From **RM 1,800** fixed price |
| FAQ (price answer) | "Projects start at RM 1,800 (**PDPA audit**)" |

Four mentions, two names, one price. A prospect cannot tell whether the Starter Pack *is* the PDPA Audit, an upgrade from it, or a third thing.

Worse, the projects list describes the RM 1,800 audit as including "policy documentation and staff training" — which is most of what the Starter Pack contains. So either the audit is underpriced or the two entries overlap.

**Recommended fix:** make the Starter Pack the single PDPA offer and retire the duplicate.

- Projects list: change the **PDPA Audit** row to **PDPA Gap Check — Free**, pointing at `/pdpa-checklist`. That matches how you now actually sell it: the audit is the free diagnostic, the pack is the paid product.
- Services card: leave the name, change the price line to "From RM 1,800" → "Free gap check · packs from RM 1,800".
- FAQ: update the parenthetical to match.

This turns a contradiction into a funnel: free check → paid pack → retainer.

---

## Housekeeping — nav placement

The `PDPA` link I added sits between `Services` and `Pricing`. It is the only nav item pointing at a *different page* while the rest are section anchors on this page, which makes it read as slightly off-language.

Two options: leave it (it works, and the checklist page is a real destination), or relabel it **"Free checklist"** so its different nature is explicit rather than accidental. I'd relabel it — "PDPA" tells a visitor nothing about why they'd click.

---

## Checked and clear

These were worth testing because they're where pages usually break. All pass:

| Check | Method | Result |
|---|---|---|
| **Colour contrast** | Real pixel sampling at 2× on rendered text, not CSS maths | **5.26 / 5.81 / 6.95 : 1** — passes WCAG AA comfortably |
| **Mobile horizontal overflow** | 390px viewport | `scrollWidth 390 = clientWidth 390` — none |
| **Sticky mobile bar** | Element-from-point at the submit button | Bar renders at 74px, does **not** block the button, footer clears it by **32px** |
| **Form labels** | Every input/select/textarea | **0 unlabelled** |
| **Image alt text** | All `<img>` | **0 missing** |
| **Heading structure** | `<h1>` count | Exactly **1**, then h2/h3 in order |
| **JS errors** | Console + pageerror across routes | **0** |
| **Mobile page height** | 390px | 17,087px ≈ 20 screens — long, but the content is dense and every section earns its place |

**A note on my own tools:** my first two contrast checks reported 21 and 13 failures. Both were **wrong** — the CSS-maths approach treats translucent overlays and gradients as opaque, so it compared cyan-on-navy as if both were the same colour. Only the pixel-sampling method gave a trustworthy answer. If you ever run an accessibility scanner over this page and it flags contrast, check the method before believing it.

---

## What's genuinely strong

Worth saying, because these are the parts that would be expensive to get wrong:

- **The calculator is the best thing on the page.** It is interactive, it produces a specific number, and it hands off to WhatsApp with the user's own figures. That is a lead magnet doing real work.
- **The pricing transparency is a real differentiator** in a market of "contact us for pricing", and it pre-qualifies enquiries.
- **"We'll tell you if you don't need us"** as one of four promises is unusually strong positioning. It is the kind of claim a competitor can't copy without meaning it.
- **The PDPA section made the headline honest.** Before it, the page sold AI and automation to businesses that mostly need plumbing. Now there's a specific, checkable reason to make contact this week.
- **The footer founder quote** gives a name and a reason. Most SME sites have neither.

---

## Priority order — all three DONE

| # | Item | Status |
|---|---|---|
| 1 | Fill the hero dead space with the free checklist CTA | ✅ **Fixed** — 360px gap → 153px |
| 2 | Resolve the PDPA price/name collision | ✅ **Fixed** — see below |
| 3 | Relabel the nav item to "Free checklist" | ✅ **Fixed** |

### What was actually done for #1 and #2

**#1 — hero.** Added a `hero-free` strip under the assurance list: green-bordered card pointing at
`/pdpa-checklist`. Measured before/after:

| | Left column | Right column | Gap |
|---|---|---|---|
| Before | 632px | 992px | **360px (31% of hero)** |
| After | 839px | 992px | **153px (13%)** |

**#2 — the PDPA collision.** The duplicate is resolved by making the free check the diagnostic and the
Starter Pack the product:

| Location | Before | After |
|---|---|---|
| Projects grid | PDPA Audit — From RM 1,800 | **PDPA Gap Check — Free** |
| Services card | RM 1,800 from, per audit | RM 1,800 fixed, **Starter Pack** |
| Visible FAQ (price) | "RM 1,800 (PDPA audit)…" | "RM 1,800 fixed for the PDPA Starter Pack. The PDPA gap check is free." |
| Visible FAQ (data) | "the PDPA audit (from RM 1,800) covers…" | "the free gap check shows where… the Starter Pack from RM 1,800 fixes it" |
| JSON-LD FAQPage | "PDPA audit from RM 1,800" | matches the visible answer |

**A mistake worth recording.** My first pass at #2 used `str.replace(..., 1)` against a string that appeared
in **both** the JSON-LD block and the visible FAQ. It silently updated the structured data and left the
visible text stale — so for a few minutes the page told users one thing and told Google another. A probe
caught it. Lesson: when a phrase appears in both JSON-LD and body copy, replace **all** occurrences and
then verify visible text and structured data separately.

Verified after the fix: visible stale reference `false`, JSON-LD stale reference `false`, both mention the
Starter Pack, 3 JSON-LD blocks intact.

---

## Still outstanding from earlier, unrelated to this review

- **`privacy.html` has 11 `.fill` markers** (SSM number, DPO name, `dpo@dutaintegra.my`, effective date). `grep -c 'class="fill"' privacy.html` must be 0 before publishing. You sell PDPA compliance — this is the one gap a prospect can find in ten seconds.
- ~~"Sdn Bhd" is unverified~~ — **resolved**: confirmed as an Enterprise. Renamed across 16 files and the corporate-specific wording corrected (see `docs/ENTITY-CORRECTION.md`).
- **The pricing remains my proposal.** RM 1,800 / 2,800 / 4,500 for the pack tiers is a recommendation, not your decision.
