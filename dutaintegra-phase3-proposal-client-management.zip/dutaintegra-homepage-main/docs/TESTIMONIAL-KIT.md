# Testimonial kit — get three real ones this week

You have no client logos, so you can't compete on social proof yet. You *can* compete on risk reversal (the rebuilt homepage does). But nothing beats a real named quote — it's the highest-leverage asset you're missing, and it costs one afternoon.

**Rule for this document: never invent a quote, a name, a metric or a logo.** For a company that sells PDPA compliance and asks clients to trust it with their data, fabricated proof isn't a growth hack — it's the thing that ends the business. Every word below is designed to get you *real* material.

---

## 1. The email to send

Send this individually. No BCC, no mail-merge. One client at a time, from a personal address, not `support@`.

> **Subject:** A small favour — two sentences about [project]?
>
> Hi [Name],
>
> Quick favour, and it's genuinely small — I'm not asking for a formal case study.
>
> We're rebuilding our website and we don't have any client stories on it yet. Rather than write something ourselves, I'd much rather publish something true. Could you answer these three, in a sentence or two each?
>
> 1. What was broken or manual before we worked together?
> 2. What's different now — ideally with a number or an amount of time saved?
> 3. Who would you recommend us to, and why?
>
> Even rough answers are useful. If you'd rather I drafted something from your answers and sent it back for you to approve or edit, that's often easier — just say so and I'll do it that way.
>
> No pressure either way. Thanks for the work you've given us.
>
> [Name]

**Why this works:** it's specific (three questions, not "can you write us a testimonial"), it's low-effort (two sentences each), it offers to do the writing, and it explicitly gives them an out. Reply rates on this are far higher than on a generic ask.

---

## 2. What a useful answer sounds like — and what doesn't

Your job is to steer from the second column to the first.

| ❌ Useless | ✅ Useful |
|---|---|
| "Great service, very professional." | "We were spending two days a month on reconciliation. It now runs overnight and nobody touches it." |
| "They're very responsive." | "I messaged them at 9pm on a Friday about the server and it was fixed before Saturday morning." |
| "Highly recommended." | "If you're a 20-person firm still doing invoices by hand, just call them." |
| "They helped us modernise." | "Three staff used to compile the Friday report by hand. That's gone — it's emailed at 8am automatically." |

**The pattern:** *before → after → number → who it's for.*

"Two days a month" beats "much more efficient" every single time. Numbers are what make a sceptical SME owner believe you, and they're what a competitor can't copy.

---

## 3. If they're reluctant to be named

Very common, especially for clients in regulated sectors and for IT work (nobody wants to advertise which vendor holds their network).

Work down this ladder — each step is still worth publishing:

1. **Named, with company** — best. Push gently for this first.
2. **Named person, unnamed company** — *"Sarah L., Finance Manager, logistics company (Johor)"*
3. **Anonymised role + sector + location** — *"Operations Manager, 30-person manufacturing firm, Klang Valley"*
4. **Sector only, quoted** — *"A healthcare client in Penang"*
5. **No quote, just a fact** — *"We automated month-end reporting for a 25-person accounting practice. It now takes 4 minutes instead of 3 hours."*

**Option 5 is underrated.** Even with zero permission to name anyone, you can publish what you did and what it saved — that's your own work, not their identity. Ask them for permission to describe the outcome without naming them.

Put the anonymisation level honestly in the attribution. **Do not** dress an anonymised quote up to look like a named one. Buyers notice, and it retroactively devalues your real ones.

---

## 4. Where to put them on the site

The rebuilt `index.html` has a **commented-out testimonials block** in the "Four promises you can hold us to" section. It exists so you can drop quotes straight in without touching layout. Uncomment, and:

- **One quote is enough to start.** Don't wait for three.
- Place the strongest quote **above the pricing section**, not in a separate testimonials page nobody visits. Social proof works next to the decision.
- Put a second one adjacent to the contact form — that's the point of highest hesitation.
- Always include **name, role, and something verifiable** (company or sector + location). "Ahmad, KL" reads as invented even when it isn't.

Add `Review`/`AggregateRating` structured data only if the reviews are real and attributable — Google penalises invented ones, and it's a fight you'd lose badly.

---

## 5. While you wait for replies: the honest interim

You'll have a gap of days-to-weeks before quotes land. Don't fill it with fake logos. Fill it with **facts you can defend**:

- **Real project outcomes, unnamed.** *"Automated month-end reporting for a 25-person accounting firm: 3 hours → 4 minutes."* If the work is real, this is honest without needing anyone's permission to name them.
- **Your own numbers, framed honestly.** Proposals in 3 working days, month-to-month, response times. These are commitments, not claims — they read as confidence.
- **Your founder's face and name.** You already have this. In a market full of anonymous vendors, a named person who says "if this doesn't work, that's my problem to fix" outperforms a logo wall.

What you already have on the site — **"3 Happy Clients"** — does the opposite of all this. Three clients is not a selling point; it's an admission. Remove it. Replace it with one specific anonymised outcome on the day you have one.

---

## 6. Track it

Keep a one-line log so you can tell whether this is working:

| Client | Asked | Reply | Named? | Quote usable? | Published where |
|---|---|---|---|---|---|
| | | | | | |

If you ask five clients and get zero, the ask is fine — the problem is the relationship depth. In that case go back to delivering the free audit for two more clients, then ask those.
