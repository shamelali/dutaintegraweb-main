# Certificate findings — SSM Borang D

Read from `uploads/Copy of TR0325441-K_CERT.pdf`, a **Borang D (Kaedah 13)** certificate under the **Business Registration Act 1956**, dated 16 July 2025.

---

## What the certificate actually says

| Field | Value |
|---|---|
| **Registered name** | **DUTA INTEGRA SOLUTIONS** |
| **Registration no.** | **202503195000 (TR0325441-K)** |
| Registered address | F2-22-15 Tamarind Suites, Tamarind Square, Persiaran Multimedia, Cyber 11, 63000 Cyberjaya, Selangor |
| Valid from | 16 July 2025 |
| **Valid until** | **15 July 2026** |
| Branches | TIADA |
| Issued by | Datuk Nor Azimah Abdul Aziz, Pendaftar Perniagaan, Semenanjung Malaysia |

---

## Finding 1 — registration renewed — RESOLVED

The registration was renewed on **15 July 2026**. The new certificate is valid until **15 July 2027**. Status: **AKTIF**.

| Field | Value |
|---|---|
| Registration no. | `202503195000` (TR0325441-K) — unchanged |
| Registered name | DUTA INTEGRA SOLUTIONS |
| Business form | PEMILIKAN TUNGGAL (sole proprietorship) |
| Start date | 11 July 2025 |
| Registration date | 16 July 2025 |
| **New expiry date** | **15 July 2027** |
| Status | AKTIF |
| Branches | TIADA |

The registration number did not change on renewal, so no other document needs editing. `config/identity.json` has been updated with the new expiry date.

---

## Finding 2 — the registered name has no "Enterprise" in it

You said "enterprise", which is the **entity type** — and that's correct, this is a sole proprietorship registered under the Business Registration Act 1956, not a company under the Companies Act 2016.

But the registered **name** is just **DUTA INTEGRA SOLUTIONS**. There is no "Enterprise" suffix on the certificate.

These are different things and the distinction matters:

| | |
|---|---|
| **Entity type** | Enterprise (sole proprietorship) |
| **Registered name** | Duta Integra Solutions |
| ~~Wrong~~ | ~~Duta Integra Solutions Enterprise~~ |
| ~~Wrong~~ | ~~Duta Integra Solutions Sdn Bhd~~ |

My previous change went too far — I read "enterprise" as part of the name and renamed everything to *Duta Integra Solutions Enterprise*. Corrected across 19 files back to the registered name. The documents now describe the type correctly in prose (*"a business registered in Malaysia under the Business Registration Act 1956"*) while using the exact registered name.

**If you trade as "…Enterprise" informally**, that's a trading style — but contracts, the privacy notice and anything a regulator reads must carry the **registered** name. Say the word if you want the trading style shown alongside it on the marketing pages only.

---

## Finding 3 — the address was wrong, and it wasn't only a formatting difference

The site said:

> ~~Level 22, Tamarind Suites, **Persiaran Bestari**, 63000 Cyberjaya, Selangor~~

The certificate says:

> **F2-22-15, Tamarind Suites, Tamarind Square, Persiaran Multimedia, Cyber 11, 63000 Cyberjaya, Selangor**

The street names differ — **Persiaran Bestari** and **Persiaran Multimedia** are different roads in Cyberjaya. This wasn't a formatting variation; the site was publishing an address that does not match the registered business address.

Now corrected in **all 20 locations**: the privacy notice §1 in both languages, the engagement letter parties table and letterhead, every pack footer, the homepage contact card and footer, the homepage JSON-LD `streetAddress`, the checklist page, and the outreach signature.

The JSON-LD fix matters independently: structured data said *Persiaran Bestari* while the visible footer said something else. Search engines read the structured data, and a mismatch between it and the visible page is exactly the kind of thing that erodes trust in the listing.

**If the old address was a correspondence address** you use deliberately — a mail forwarding service, for instance — tell me and I'll reinstate it as a *contact* address while keeping the registered address in the legal documents. That's a legitimate arrangement; publishing one address as if it were the other is not.

---

## What changed in the files

| Change | Scope |
|---|---|
| Name → `Duta Integra Solutions` | 19 files |
| Address → certificate address | 20 locations |
| Registration no. `202503195000` applied | `privacy.html` §1 EN + BM, SOW parties table |
| All 8 PDFs regenerated | verified: cert address present, no "Bestari", no "Solutions Enterprise" |
| Site routes | 14/14 PASS · 0 JS errors |

---

## Bugs found in my own tooling while doing this

Worth recording, because both could have shipped silently wrong documents:

1. **`fill.py` reverted its own mailbox change.** A later line in the script replaced `mailto:support@` back to `mailto:dpo@`, undoing the redirect it had just made.
2. **`fill.py` discarded edits that didn't change the marker count.** The file was only written when the number of `.fill` spans changed — so the role-wording harmonisation across §10 and §13 was computed and then thrown away without warning. Now the write condition compares full content.

**Both were caught by checking the rendered text, not the script's own success message.** The script reported "✓ role wording harmonised 2" while replacing nothing.

Lesson for anything similar: a tool's success report is a claim, not evidence. Verify the artefact.

---

## Role wording — now consistent

Because you do not meet a DPO threshold, the notice calls this a **data protection contact**, not a Data Protection Officer. Previously §1 said one thing and §10/§13 still said "our DPO" — an internal contradiction in a document whose entire purpose is precision.

| Check | Result |
|---|---|
| "our DPO" / "DPO kami" | **0** |
| "data protection contact" | 3 (EN) |
| "pegawai hubungan perlindungan data" | 3 (BM) |
| mailto targets | single: `support@dutaintegra.my` |

The mailbox was also switched from `dpo@` to **`support@`** — the rule being never publish a mailbox that may not exist. If you create a dedicated `privacy@` or `datarequest@`, change one line in `config/identity.json` and re-run; everything follows.

---

## Still outstanding

Registration is **not** on this list — it was renewed on 15 July 2026 and is valid until 15 July 2027 (Finding 1). What is left:

| Item | Where |
|---|---|
| **Renewal certificate (PDF)** | Not in `uploads/` — the only certificate here is the 2025 one, which expired **15 July 2026**. Finding 1 records the renewal to 15 July 2027; file the new PDF alongside the old one so the claim has a document behind it. |
| Effective date | `config/identity.json` |
| Data protection contact name | `config/identity.json` |
| Retention periods confirmed | `config/identity.json` |
| Proprietor name (for the SOW) | `config/identity.json` — **not on the Borang D**: that certificate prints the business name, registration number, address and branches only, and never the owner's name. Take it from the owner's MyKad or the SSM e-Form, not from the PDF. |
| Processor list (EN + BM) | edit `privacy.html` first, then set `retention.confirmed` |
| **Native Bahasa Malaysia review** | not automatable — do it before publishing |

```bash
python3 tools/fill.py --check    # currently 6 to fill
```
