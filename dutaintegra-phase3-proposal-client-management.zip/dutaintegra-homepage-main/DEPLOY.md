# Deploy guide — dutaintegra.my

Everything in this folder is ready to ship and has been verified by serving it through a real nginx instance and driving it in a real browser. This is the order to do it in.

---

## What's in the deploy set

| File | Goes to | Purpose |
|---|---|---|
| `index.html` | `/index.html` (or `/`) | Rebuilt homepage |
| `privacy.html` | `/privacy.html` | Bilingual PDPA notice — **fill in the 11 `[CONFIRM]` markers first** |
| `audit-scorecard.html` | `/audit-scorecard.html` | Free audit worksheet; print/save report unlocks after contact details and consent |
| `operations-demo.html` + assets | `/operations-demo` | Browser-only autonomous operations walkthrough and local proposal preview; no live infrastructure actions |
| `lead-magnet/pdpa-checklist.html` | `/lead-magnet/` | **New** — free PDPA checklist, public SEO lead magnet |
| `pdpa-starter-pack/` | *(not deployed)* | Sales + delivery assets. Referenced by `/pdpa-starter-pack` redirect if you want the offer sheet web-reachable |
| `analytics.js` | `/analytics.js` | Lead-event tracking (ships disabled — see below) |
| `og-image.jpg` | `/og-image.jpg` | 1200×630 social preview, 81 KB |
| `robots.txt` | `/robots.txt` | Crawl rules |
| `sitemap.xml` | `/sitemap.xml` | 10 real URLs, excludes the empty pages |
| `_headers` + `_redirects` | publish root | **Only if you're on Netlify / Cloudflare Pages** |
| `deploy/nginx.conf.example` | — | **Only if you self-host** (your repo implies you do) |

## Recommended source and hosting connection

Use one deployment path:

```text
GitHub (private source repository) → Cloudflare Pages → dutaintegra.my
```

This project is already structured for Cloudflare Pages: `public/` is the
output directory and `functions/api/send-email.js` is a Pages Function. Do not
connect the same production branch to Vercel at the same time; two active
deployments create avoidable source-of-truth and DNS ambiguity.

Before the first push, review the repository contents. `config/`, `docs/`,
`pdpa-starter-pack/`, `outreach/`, and `previews/` contain internal, legal,
commercial, or personal material. Keep the repository private unless those
directories have been deliberately separated. The Pages output is limited to
`public/`, but GitHub repository visibility is independent of Pages output.

Local Pages variables can be prepared from `.dev.vars.example`; keep the real
`.dev.vars` file untracked. Configure production values in Cloudflare Pages,
not in GitHub:

```text
BREVO_API_KEY   secret
EMAIL_TO        support@dutaintegra.my
EMAIL_FROM      verified sender on dutaintegra.my
ALLOWED_ORIGINS https://dutaintegra.my,https://www.dutaintegra.my
```

Bind a Cloudflare KV namespace as `LEADS` for lead storage and the basic abuse
limiter. KV read/modify/write is not a strict distributed rate limiter, so also
configure a Cloudflare edge rate-limiting rule for `POST /api/send-email` before
production traffic. The local contract test uses stubs and does not prove that
production bindings or secrets are configured.

---

## Before you deploy — three must-dos

### 1. Fill the `[CONFIRM]` markers in `privacy.html`

**Do not hand-edit the HTML.** Every value lives in `config/identity.json` and one command applies them:

```bash
python3 tools/fill.py --check   # what is still missing
python3 tools/fill.py           # apply
grep -c 'class="fill"' public/privacy.html        # expect 0
```

The script refuses to write while a required value is still a `<placeholder>`, backs up both files first, and
`--revert` restores them byte-for-byte. Full instructions and the reasoning behind each field:
**`docs/FILL-IN.md`**.

> **Read the DPO section of that document before filling it in.** As an IT provider serving SMEs you almost
> certainly do not meet a DPO threshold — and naming a DPO you are not required to have creates a real
> obligation (registration within 21 days, dedicated mailbox, formal appointment letter). The script
> handles this automatically: set `meets_dpo_threshold: false` and the notice calls it a *data protection
> contact* and routes the link to `support@`.

Run `fill.py --check` for the live count (6 as of 4 October 2026 — the sentence above goes stale, the command does not). **A `[CONFIRM]` visible on a live page is worse than no page at all** — a privacy notice with placeholders tells a prospect you don't review your own output.

### 2. Add both hostnames to `ALLOWED_ORIGINS`

Your Node server 403s requests whose origin isn't allowlisted. The form posts to `/api/send-email`, so if `https://www.dutaintegra.my` isn't on that list, **every lead is silently lost**. The page has a WhatsApp fallback so the visitor isn't stranded, but you'd never see the enquiry.

```
ALLOWED_ORIGINS=https://dutaintegra.my,https://www.dutaintegra.my
```

Test it after deploying: submit the form yourself and confirm it lands in `ENQUIRY_STORE`.

### 3. Decide where analytics goes

`analytics.js` ships with `transport: 'noop'` — it collects events in the browser (`window.__di_events`) and sends them nowhere. Nothing leaves the visitor's browser until you choose. Edit the `CONFIG` block at the top:

```js
var CONFIG = {
  transport: 'ga4',                 // 'noop' | 'ga4' | 'plausible' | 'cloudflare' | 'endpoint'
  GA4_ID: 'G-XXXXXXXXXX',           // not read here — your gtag snippet uses it
  PLAUSIBLE_DOMAIN: 'dutaintegra.my',
  CF_TOKEN: 'YOUR_CF_BEACON_TOKEN',
  ENDPOINT: '/api/analytics',       // only used when transport is 'endpoint'
  debug: false                      // true = log events to console while testing
};
```

**If you switch on GA4 or any cookie-setting tool, update your privacy notice §11** — right now it says you use no tracking cookies. Keep that sentence true, or change it. You sell PDPA compliance; the gap between your site and your pitch is the one gap that actually costs you deals.

#### Before you change `transport`, read this

The CONFIG value alone does **not** turn a transport on. Each branch calls a global that has to already exist on the page, and if it doesn't the branch no-ops silently — you get zero data and no error.

| Transport | What it needs, in the same commit |
|---|---|
| `ga4` | The Google tag snippet (`gtag.js`) on the page. `GA4_ID` is not read by `analytics.js`. |
| `plausible` | The Plausible snippet with your domain. `PLAUSIBLE_DOMAIN` is not read by `analytics.js`. |
| `cloudflare` | The Cloudflare Web Analytics beacon. `CF_TOKEN` is not read by `analytics.js`. |
| `endpoint` | Two things, both required — see below. |

For `endpoint` specifically:

1. **A route that exists.** Add `POST /api/analytics` to the Node server. Without it every event POSTs into a 404. `fetch` does not reject on a 404 and `analytics.js` ignores the response, so nothing appears in the console either — the events are simply gone while `window.__di_events` still fills up and looks healthy.
2. **Its own rate-limit zone.** The general `/api/` location in `deploy/nginx.conf.example` uses `zone=enquiry rate=10r/m burst=5` for `POST /api/send-email`. A single pageview can emit a dozen events (4× `scroll_depth`, `landed_with_source`, `calc_engage`, `calc_handoff`, each `wa_click`), so analytics must not share the quota the lead form needs. **The nginx half is already drafted**: the exact-match `location = /api/analytics` declares `zone=analytics rate=60r/m`, so copying that file in as-is is enough — no edits needed on the edge side.

`CONFIG.debug: true` only shows the **outgoing** event; it cannot tell you the server accepted it. For `endpoint`, confirm on the server side that a row or log line actually appears, then submit the form yourself and confirm it lands in `ENQUIRY_STORE`. The script's own report is a claim, not evidence — same rule as the fill script.

`node tools/analytics-test.js` runs the event logic against a stub DOM (no browser, no dependencies) and fails if the transport stops shipping as `'noop'`, if `calc_handoff` stops firing on the calculator's WhatsApp click, or if the script starts writing to browser storage — the last of which would falsify privacy.html §11.

`node tools/i18n-test.js` statically checks the EN/BM layer on `index.html`: every `[data-i18n]` key has a BM string and every BM string is used, no nested keys (a parent swap would destroy a child), every `t()`/`tpl()` string used by the script exists in `DYN`, no browser storage, the `?lang=bm` wiring, and that `<option>` values stay pinned to their English text so the WhatsApp and form prefills don't change language. Run it after any edit to `index.html`. `python3 tools/i18n-apply.py --dry` re-checks the same key set against the live markup (it is idempotent; `--dry` writes nothing).

---

## Option A — self-hosted nginx (most likely your setup)

```bash
# 1. Back up first
sudo cp -r /var/www/dutaintegra /var/www/dutaintegra.bak.$(date +%F)

# 2. Copy the new files in (site files live in public/)
sudo cp public/index.html public/privacy.html public/audit-scorecard.html \
        public/og-image.jpg public/robots.txt public/sitemap.xml public/analytics.js \
        /var/www/dutaintegra/

# 3. Install the config (rename to match your setup)
sudo cp deploy/nginx.conf.example /etc/nginx/sites-available/dutaintegra
sudo ln -sf /etc/nginx/sites-available/dutaintegra /etc/nginx/sites-enabled/

# 4. Test BEFORE reloading — always
sudo nginx -t

# 5. Reload
sudo systemctl reload nginx
```

**Be careful with step 3.** If you already have a working nginx config for this domain, don't overwrite it — copy the pieces you need (`location` blocks, `add_header` lines) into your existing file. The example is a starting point, not a drop-in replacement, and it assumes paths (`/var/www/dutaintegra`, `127.0.0.1:3000`) that may not match yours.

Two nginx gotchas already handled in the example, worth knowing because they bite people:

- **`add_header` in a nested `location` replaces the parent's list** rather than merging. That's why the security headers are repeated in the `/assets/` and `/api/` blocks. If you add a new location, copy the full header set in or those headers silently vanish for that path.
- **The SPA catch-all must be last.** The explicit `location = /privacy` blocks come before `location /`, otherwise the React app swallows `/privacy` and renders the empty page again.

## Option B — Cloudflare Pages (current path)

1. Push this repo (`dutaintegra-homepage`). Only `public/` deploys — `config/`,
   `tools/`, `docs/` and friends stay private by construction.
2. Cloudflare dashboard → Workers & Pages → Create → Pages → Connect to Git → select the repo.
3. Build settings: framework **None**, **no build command**, output directory **`public/`**.
   `_headers` and `_redirects` live in `public/` and are read automatically.
   `functions/` stays at repo root (Pages requirement) — do not move it into `public/`.
4. Custom domains: add **both** `dutaintegra.my` and `www.dutaintegra.my`. Apex is canonical (matches the `<link rel="canonical">` tags and `sitemap.xml`).
5. Redirect www → apex: Pages `_redirects` cannot match hostnames, so add a Cloudflare **Bulk Redirect**: `https://www.dutaintegra.my/*` → `https://dutaintegra.my/$1`, 301. Without it you split SEO across two hostnames.
6. DNS: Cloudflare auto-adds the CNAMEs when you attach the domains. SSL: Full (Strict), "Always Use HTTPS" on.

**Lead form on Pages:** `functions/api/send-email.js` is present and implements the form contract, but it needs the Pages environment variables and optional `LEADS` KV binding described at the top of that file. Without `BREVO_API_KEY` and `EMAIL_TO`, the form intentionally degrades to its WhatsApp fallback (`waFallback` in `index.html`) and records `fallback/api_unreachable_or_forbidden` in the client-side event stream. Configure and test the function after deployment; do not copy credentials into the repository.

**Scorecard report gate:** Visitors can complete the `/audit-scorecard` worksheet for free. The print/save report action stays locked until the visitor submits their name, company, work email, and PDPA contact consent through the same Pages Function. Keep `BREVO_API_KEY`, `EMAIL_TO`, `ALLOWED_ORIGINS`, and the `LEADS` binding configured or the report gate will remain locked and show the WhatsApp fallback message. The gate is an intended user-flow control; the worksheet remains static HTML and is not a security boundary against source inspection.

**`_redirects` ordering matters** — the static rewrites for `/privacy` and `/audit-scorecard` must come before the SPA catch-all. It's already ordered correctly; don't re-sort the file.

---

## Verification — does it actually work?

These are the exact tests I ran. All passing on a local nginx serving these files.

```bash
# Pages resolve to the right content, not to the empty SPA shell
for p in / /privacy /audit-scorecard /scorecard /robots.txt /sitemap.xml; do
  printf "%-18s %s\n" "$p" "$(curl -sk -o /dev/null -w '%{http_code} %{size_download}b' https://www.dutaintegra.my$p)"
done
```

Measured results:

| Route | Result |
|---|---|
| `/` | 200 · 82,009 bytes · renders the new homepage |
| `/privacy` | 200 · 35,675 bytes · **was 0 characters of content** |
| `/audit-scorecard` | 200 · 29,426 bytes |
| `/scorecard` | 200 · same file (alias) |
| `/robots.txt`, `/sitemap.xml` | 200, correct content types |

```bash
# Security headers present
curl -skI https://www.dutaintegra.my/ | grep -iE 'strict-transport|x-content-type|referrer-policy|permissions-policy|content-security'

# Redirects behaving
curl -skI https://www.dutaintegra.my/stats      # 301 -> /services
curl -skI https://www.dutaintegra.my/wa         # 302 -> wa.me with prefilled text
curl -skI https://www.dutaintegra.my/             # 301 -> https://dutaintegra.my/
curl -sI  http://www.dutaintegra.my/            # 301 -> https

# Compression (82 KB -> 21.6 KB measured)
curl -skI -H 'Accept-Encoding: gzip' https://www.dutaintegra.my/ | grep -i content-encoding
```

**Canonical host:** the config makes the **apex** canonical and redirects www to it, because that's what your canonical tags and sitemap use. If you'd rather have www as canonical, change it in *three* places — the redirect (nginx block or Cloudflare Bulk Redirect), the `<link rel="canonical">` tags, and `sitemap.xml` — or you'll split your own SEO across two hostnames.

---

## After deploying — the 15-minute check

```
[ ] Submit the contact form yourself. Enquiry arrives AND lands in ENQUIRY_STORE.
[ ] Open a WhatsApp share of dutaintegra.my — preview shows the image, not a grey box.
[ ] Open /privacy on a phone. Both languages present. No [CONFIRM] text visible.
[ ] Print the scorecard to PDF from Chrome. 5 pages, no split rows.
[ ] PageSpeed Insights on / — expect 90+ (it was a 397 KB SPA before).
[ ] Confirm /stats and /insights redirect instead of showing empty pages.
[ ] Set analytics transport and confirm events fire (CONFIG.debug = true).
[ ] Add the SSM number to the footer.
```

---

## Rollback

Every change is a static file. To undo:

```bash
sudo cp -r /var/www/dutaintegra.bak.YYYY-MM-DD/* /var/www/dutaintegra/
sudo nginx -t && sudo systemctl reload nginx
```

Nothing here touches your React app, your API, DNS or the enquiry store. If a page misbehaves, you can revert that one file.

---

## What's still outstanding

| Item | Where |
|---|---|
| `/terms` — service agreement | Not built. Needs a lawyer, not me. |
| `/cases`, `/stats`, `/insights` | Redirected to `/services` for now. Build them when you have content — a dead link is worse than no link. |
| BM localisation of the React routes | `docs/FIX-GUIDE.md` §7 — the toggle currently changes nav labels but not page content |
| 3 untranslated i18n keys | `docs/FIX-GUIDE.md` §3 — exact copy to paste |
| The three empty public GitHub repos | `docs/FIX-GUIDE.md` §0 |

---

## Verification log — actual measured results

Served through local nginx, driven by a real browser at 1440 px and 390 px:

```
PASS  desktop  /                 200   10014 chars  ok
PASS  desktop  /privacy          200   18434 chars  ok
PASS  desktop  /audit-scorecard  200    7811 chars  ok
PASS  desktop  /scorecard        200    7811 chars  ok
PASS  desktop  /robots.txt       200     332 chars  ok
PASS  desktop  /sitemap.xml      200    1406 chars  ok
PASS  mobile   /                 200    9980 chars  ok
PASS  mobile   /privacy          200   18338 chars  ok
PASS  mobile   /audit-scorecard  200    7811 chars  ok
PASS  mobile   /scorecard        200    7811 chars  ok
PASS  mobile   /robots.txt       200     332 chars  ok
( /sitemap.xml on mobile reports "overflow" — that is the browser's XML
  viewer rendering long URLs wider than 390px. Google parses the raw XML.
  Not a real issue; ignore it. )
```

Also verified:

- `nginx -t` → **syntax ok, test successful**
- gzip: 82,009 → **21,657 bytes** (74% smaller)
- Security headers: all six present on `/`
- Redirects: `/stats` → 301 `/services`, `/wa` → 302 wa.me, www → 301 apex, http → 301 https
- Caching: `/og-image.jpg` 7 days, `/assets/*` 1 year immutable
- JSON-LD: 3 blocks (`ProfessionalService`, `ItemList`, `FAQPage`) all parse
- Analytics: 13 events captured across 7 types, correctly attributed by page location
- Scorecard print: clean 5-page A4 PDF, no rows split across pages

---

## Late additions (this batch)

### `/pdpa-checklist` — the public lead magnet

`lead-magnet/pdpa-checklist.html` is deployed alongside the other static pages and served at the clean
route `/pdpa-checklist` via the new `_redirects` rules. It is the top of the PDPA funnel: a complete,
genuinely useful checklist with **no email gate**, ending in a free gap-check CTA.

Verified: 200 at `/pdpa-checklist`, `/pdpa-checklist/`, `/pdpa` and `/compliance`; 8,802 chars desktop /
8,772 mobile; **no horizontal overflow at 1440px or 390px**; zero JS errors; FAQPage structured data
present (5 questions); canonical + og/twitter tags point at the live URL.

**Routing added to `_redirects`:**

```
/pdpa-checklist         /lead-magnet/pdpa-checklist.html   200
/pdpa-checklist/        /lead-magnet/pdpa-checklist.html   200
/pdpa                   /lead-magnet/pdpa-checklist.html   200
/compliance             /lead-magnet/pdpa-checklist.html   200
/pdpa-starter-pack      /pdpa-starter-pack/offer-sheet.html  200
```

**Homepage now links into it** from three places: the nav, a new `#pdpa` section before the FAQ, and the
footer. The new section states the deadline honestly and offers two exits — read the free checklist, or
ask us to check it.

### Sitemap namespace bug — FIXED

`sitemap.xml` declared `xmlns="http://www.sitemap.org/..."` (**sitemap**, singular). The correct namespace
is **`http://www.sitemaps.org/schemas/sitemap/0.9`** (sitemaps, plural). With the wrong namespace, the
file still returns HTTP 200 and looks fine in a browser, but Google parses zero URLs from it — the entire
sitemap is silently discarded.

Fixed and now validated: `xml.etree` parses **9 URLs**.

```bash
python3 -c "import xml.etree.ElementTree as ET; ns='{http://www.sitemaps.org/schemas/sitemap/0.9}'; \
print(len(ET.parse('public/sitemap.xml').getroot().findall(ns+'url')),'URLs')"
# expect: 10 URLs
```

**Verify this after every deploy** — it is the kind of error that produces no visible symptom.

### Late verification run — 14/14 PASS

All routes, both viewports, no overflow, zero JS errors:

| Route | Desktop 1440 | Mobile 390 |
|---|---|---|
| `/` | 200 · 11,029 chars | 200 · 10,990 chars |
| `/pdpa-checklist` | 200 · 8,802 chars | 200 · 8,772 chars |
| `/privacy` | 200 · 18,352 chars | 200 · 18,256 chars |
| `/audit-scorecard` + `/scorecard` | 200 · 7,772 chars | 200 · 7,772 chars |
| `/robots.txt` | 200 · 330 chars | 200 · 330 chars |
| `/sitemap.xml` | 200 · 1,519 chars | 200 · 1,519 chars |
