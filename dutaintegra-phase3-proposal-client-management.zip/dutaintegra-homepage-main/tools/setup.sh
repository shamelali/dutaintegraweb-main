#!/usr/bin/env bash
# Rebuild the browser harness. Run once per session:  bash tools/setup.sh
# deps/ (12 MB) persists across sessions because it is not named node_modules.
# Paths are derived from this script so it works from any checkout, not only
# the machine it was written for.
set -e
T="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "› system libraries"
sudo apt-get update -qq
sudo apt-get install -y -qq libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libatspi2.0-0 \
  libxdamage1 libxkbcommon0 libasound2t64 libcups2 libdrm2 libgbm1 libxcomposite1 libxfixes3 \
  libxrandr2 libpango-1.0-0 libcairo2 poppler-utils >/dev/null
echo "› node packages"
[ -d "$T/deps/node_modules/playwright" ] || (cd "$T/deps" && npm i playwright@1.49.0 >/dev/null)
echo "› chromium (~100 MB, does not persist — that is expected)"
cd "$T/deps" && npx playwright install chromium >/dev/null 2>&1 || true
[ -d "$HOME/.cache/ms-playwright" ] || (cd "$T/deps" && npx playwright install-deps chromium >/dev/null 2>&1 && npx playwright install chromium >/dev/null 2>&1)
echo "› linking modules so tools/*.js can just require('playwright')"
ln -sfn "$T/deps/node_modules" "$T/node_modules"
echo "› python imaging"
python3 -c "import PIL, numpy" 2>/dev/null || pip install --quiet pillow numpy
echo "› verifying"
cd "$T" && node -e "
const{chromium}=require('$T/deps/node_modules/playwright');
chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']})
 .then(async b=>{await b.close();console.log('   LAUNCH OK — harness ready')})
 .catch(e=>{console.log('   FAILED:',e.message.split('\n')[0]);process.exit(1)});
"
