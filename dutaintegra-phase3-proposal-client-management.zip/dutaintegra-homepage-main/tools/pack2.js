const { chromium } = require('playwright');
const D='/home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/';
const files=process.argv.slice(2);
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  for(const f of files){
    const c=await b.newContext({viewport:{width:900,height:1100}});
    const p=await c.newPage(); const errs=[];
    p.on('pageerror',e=>errs.push(e.message));
    p.on('console',m=>{if(m.type()==='error'&&!/net::|Failed to load resource|fonts\.g/.test(m.text()))errs.push('C:'+m.text())});
    await p.goto('file://'+D+f,{waitUntil:'load'});
    await p.waitForTimeout(900);
    const m=await p.evaluate(()=>({
      h1:document.querySelector('h1').textContent.trim(),
      docno:(document.querySelector('.docmeta span')||{}).textContent,
      sections:[...document.querySelectorAll('h2')].map(x=>x.textContent.trim()).length,
      overflow:document.documentElement.scrollWidth>document.documentElement.clientWidth+2,
      notLegal:document.body.innerText.includes('not a law firm'),
      dpoCalc:!!document.getElementById('result'),
      resultTxt:((document.getElementById('result')||{}).textContent||'').slice(0,50)
    }));
    await p.emulateMedia({media:'print'});
    const buf=await p.pdf({format:'A4',printBackground:true,margin:{top:'10mm',bottom:'10mm',left:'10mm',right:'10mm'}});
    const pages=(buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g)||[]).length;
    console.log(`${f}`);
    console.log(`   "${m.h1}" | ${m.docno} | ${m.sections} h2 | ${pages} A4 pages | overflow:${m.overflow}`);
    console.log(`   not-legal-advice: ${m.notLegal?'PASS':'FAIL MISSING'} | DPO calc: ${m.dpoCalc?'PASS — '+m.resultTxt:'n/a'}`);
    if(errs.length)console.log('   errors:',errs.slice(0,2));
    await c.close();
  }
  await b.close();
})();
