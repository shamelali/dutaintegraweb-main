const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const p=await(await b.newContext({viewport:{width:1000,height:1000}})).newPage();
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('file:///home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/09-kickoff-questionnaire.html',{waitUntil:'load'});
  await p.waitForTimeout(600);

  const cases=[[25000,0,'no'],[15000,12000,'no'],[5000,0,'yes'],[5000,0,'maybe'],[400,0,'no']];
  for(const [ds,se,mo] of cases){
    await p.fill('#ds',String(ds)); await p.fill('#sens',String(se)); await p.selectOption('#mon',mo);
    await p.waitForTimeout(150);
    const r=await p.evaluate(()=>{const e=document.getElementById('result');return {t:e.textContent,c:e.className}});
    console.log(`  ds=${String(ds).padEnd(6)} sens=${String(se).padEnd(6)} mon=${mo.padEnd(6)} → [${r.c.replace('r-','').toUpperCase()}] ${r.t.slice(0,72)}`);
  }

  // fill a few fields then test the export
  await p.fill('#kf input[data-q="Registered company name"]','Ahmad Logistics Sdn Bhd');
  await p.fill('#kf textarea[data-q="Customer journey"]','Customer WhatsApps, we quote, details go into AutoCount.');
  await p.check('#syswrap input[value="WhatsApp"]');
  await p.check('#syswrap input[value="Accounting software"]');
  await p.check('#syswrap input[value="Spreadsheets"]');
  await p.fill('#kf input[data-q="Approver"]','Pn. Siti');
  p.on('dialog',async d=>{console.log('  dialog:',d.message().split('\n')[0]); await d.accept();});
  await p.click('button:has-text("Copy answers as text")');
  await p.waitForTimeout(700);
  const dump=await p.evaluate(()=>document.getElementById('dump').value);
  console.log('\n  EXPORT TEST — length',dump.length,'chars');
  console.log('  ──────────────────────────────');
  console.log(dump.split('\n').slice(0,16).map(l=>'  '+l).join('\n'));
  console.log('  ...');
  const tail=dump.split('\n').filter(l=>l.startsWith('DPO ASSESSMENT')||l.includes('Systems')).slice(0,3);
  tail.forEach(l=>console.log('  '+l));
  console.log('  ──────────────────────────────');
  console.log('  JS errors:',errs.length?errs:'none');
  await b.close();
})();
