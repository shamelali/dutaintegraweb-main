/**
 * deploy-test.js — dependency-free checks for the static deploy set.
 *
 * Run: node tools/deploy-test.js
 *
 * This does not contact a hosting provider. It catches repository-only
 * mistakes before a publish: missing deploy artifacts, malformed redirect
 * rules, a misplaced catch-all, sitemap namespace/URL errors, and visible
 * privacy fill markers.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
let pass = 0;
let fail = 0;

function check(name, ok, detail) {
  if (ok) {
    pass++;
    console.log('  ok    ' + name);
  } else {
    fail++;
    console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : ''));
  }
}

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

const required = [
  'public/index.html',
  'public/privacy.html',
  'public/terms.html',
  'public/audit-scorecard.html',
  'public/digital-assessment.html',
  'public/digital-assessment.css',
  'public/digital-assessment.js',
  'public/audit-guide.html',
  'public/lead-magnet/pdpa-checklist.html',
  'public/operations-demo.html',
  'public/operations-demo/index.html',
  'public/operations-demo.css',
  'public/operations-demo.js',
  'public/ask-ai.js',
  'public/ask-ai.css',
  'public/ai-operations.html',
  'public/managed-it.html',
  'public/security-pdpa.html',
  'public/websites.html',
  'public/connect.html',
  'public/connect.css',
  'public/connect-pilot.js',
  'public/connect-rateshop.js',
  'public/rates-engine.js',
  'public/connect-rate-calculator.html',
  'public/rate-calculator.js',
  'public/pricing.html',
  'public/services.css',
  'public/services-i18n.js',
  'public/bm/chrome.js',
  'public/bm/ai-operations.js',
  'public/bm/managed-it.js',
  'public/bm/security-pdpa.js',
  'public/bm/websites.js',
  'public/bm/connect.js',
  'public/bm/connect-rate-calculator.js',
  'public/bm/pricing.js',
  'public/health-check.js',
  'public/fonts/fonts.css',
  'public/fonts/inter-400-latin.woff2',
  'public/fonts/inter-400-latin-ext.woff2',
  'public/fonts/spacegrotesk-500-latin.woff2',
  'public/fonts/spacegrotesk-500-latin-ext.woff2',
  'functions/api/business-health-check.js',
  'public/pdpa-starter-pack/offer-sheet.html',
  'public/analytics.js',
  'public/og-image-v2.jpg',
  'public/404.html',
  'public/robots.txt',
  'public/sitemap.xml',
  'public/_headers',
  'public/_redirects',
];

for (const rel of required) {
  check('deploy artifact exists: ' + rel, fs.existsSync(path.join(root, rel)));
}

/* ---- _redirects ------------------------------------------------------- */
const redirectLines = read('public/_redirects')
  .split(/\r?\n/)
  .map((line) => line.trim())
  .filter((line) => line && !line.startsWith('#'));
const rules = redirectLines.map((line) => line.split(/\s+/));
const statuses = new Set(['200', '301', '302', '303', '307', '308']);
const malformed = rules.filter((rule) => rule.length < 3 || !statuses.has(rule[rule.length - 1]));
check('redirect rules have source, target and valid status', malformed.length === 0, malformed.join('; '));
check('redirect catch-all is absent for static site', !rules.some((rule) => rule[0] === '/*'));
check('workspace route is configured', rules.some((rule) => rule[0] === '/workspace' && rule[1] === '/workspace' && rule[2] === '200'));
check('digital-assessment route is configured', rules.some((rule) => rule[0] === '/digital-assessment' && rule[1] === '/digital-assessment' && rule[2] === '200'));
check('digital-assessment is included in sitemap', /<loc>https:\/\/dutaintegra\.my\/digital-assessment<\/loc>/.test(read('public/sitemap.xml')) && !/name="robots" content="noindex[^"]*"/.test(read('public/digital-assessment.html')));
const extensionLoops = rules.filter((rule) => rule[0] !== '/*' && rule[rule.length - 1] === '200' && /\.html(?:$|\?)/.test(rule[1]));
check('200 rewrites do not target .html paths', extensionLoops.length === 0, extensionLoops.map((r) => r.join(' ')).join('; '));
const sectionRedirects = new Map(rules.filter((rule) => rule.length >= 3).map((rule) => [rule[0], rule]));
// /pricing and /connect are now real standalone pages (200 rewrites to
// public/pricing.html and public/connect.html), so they are NOT legacy anchor
// routes any more. The legacy set is the remaining section-only aliases.
const LEGACY_SECTION_ROUTES = ['/services', '/contact', '/quiz', '/projects'];
check('legacy section routes have explicit redirects', LEGACY_SECTION_ROUTES.every((source) => {
  const rule = sectionRedirects.get(source);
  return rule && rule[rule.length - 1] === '301';
}));
check('real /pricing and /connect routes are served as pages', ['/pricing', '/connect'].every((source) => {
  const rule = sectionRedirects.get(source);
  return rule && rule[rule.length - 1] === '200';
}));

/* ---- internal link hygiene -------------------------------------------- */
const htmlFiles = required.filter((rel) => rel.endsWith('.html'));
// Only genuinely phantom section anchors. /pricing and /connect are real pages.
const phantomHref = /href="\/(?:services|contact|quiz|projects)(?:["#?])/;
const phantomLinks = htmlFiles.filter((rel) => phantomHref.test(read(rel)));
check('HTML does not link to phantom route pages', phantomLinks.length === 0, phantomLinks.join(', '));

/* ---- privacy publish gate -------------------------------------------- */
check('privacy has no visible fill markers', !/class="fill"/.test(read('public/privacy.html')));

/* ---- sitemap ---------------------------------------------------------- */
const sitemap = read('public/sitemap.xml');
const sitemapLocs = [...sitemap.matchAll(/<loc>\s*([^<]+?)\s*<\/loc>/g)].map((m) => m[1]);
check('sitemap uses the sitemaps.org namespace', /xmlns="http:\/\/www\.sitemaps\.org\/schemas\/sitemap\/0\.9"/.test(sitemap));
check(
  'sitemap has unique canonical URLs',
  sitemapLocs.length > 0 && new Set(sitemapLocs).size === sitemapLocs.length && sitemapLocs.every((url) => /^https:\/\/dutaintegra\.my(?:\/|$)/.test(url)),
  sitemapLocs.join(', ')
);
check('sitemap excludes known empty routes', !sitemapLocs.some((url) => /\/(?:cases|stats|insights)$/.test(url)));
check('sitemap excludes the 404 page', !sitemapLocs.some((url) => /\/404(?:\.html)?$/.test(url)), sitemapLocs.filter((url) => /\/404/.test(url)).join(', '));
check('sitemap lastmod dates are valid W3C dates and plausible',
  [...sitemap.matchAll(/<lastmod>([^<]+)<\/lastmod>/g)].every((m) =>
    /^\d{4}-\d{2}-\d{2}$/.test(m[1]) && m[1] >= '2024-01-01' && m[1] <= '2027-12-31'),
  [...sitemap.matchAll(/<lastmod>([^<]+)<\/lastmod>/g)].map((m) => m[1]).join(', '));
check('sitemap includes service pages',
  ['/ai-operations', '/managed-it', '/security-pdpa', '/websites'].every((route) =>
    sitemapLocs.includes('https://dutaintegra.my' + route)));
check('scorecard sitemap entry is indexable',
  /<loc>https:\/\/dutaintegra\.my\/audit-scorecard<\/loc>/.test(sitemap) &&
  !/name="robots" content="noindex[^\"]*"/.test(read('public/audit-scorecard.html')));
const offerSheet = read('public/pdpa-starter-pack/offer-sheet.html');
check('PDPA offer sheet has EN/BM toggle',
  offerSheet.includes('id="btnEn"') && offerSheet.includes('id="btnBm"') &&
  offerSheet.includes("new URLSearchParams(location.search).get('lang') !== 'en'") &&
  offerSheet.includes('document.documentElement.lang = isBm ? \'ms\' : \'en\''));

/* ---- 404 page --------------------------------------------------------- *
 * Without a 404.html in the publish root, Cloudflare Pages has no not-found
 * document to serve and unmatched paths fall through to index.html with a
 * 200. That is not a hypothetical: it shipped for months, which meant every
 * mistyped or dead URL quietly returned a duplicate of the homepage — the
 * exact thing the catch-all rule above is written to prevent at the redirect
 * layer. The file itself is therefore a deploy artifact, not a nice-to-have. */
const notFoundPage = read('public/404.html');
check('404 page is noindex', /name="robots"\s+content="noindex/.test(notFoundPage));
check('404 page has a visible heading', /<h1[\s>]/.test(notFoundPage));

// Every internal link on the 404 must resolve to a file that is actually
// published. A not-found page that itself 404s is worse than no page at all.
const nfHrefs = [...notFoundPage.matchAll(/href="(\/[^"#]*)/g)]
  .map((m) => m[1])
  // Assets, not routes: /favicon.svg, /analytics.js and Cloudflare's own
  // /cdn-cgi/* are not page addresses and must not be resolved as pages.
  .filter((h) => !/\.[a-z0-9]{2,6}$/i.test(h) && !h.startsWith('/cdn-cgi'));
const nfBroken = [...new Set(nfHrefs)].filter((href) => {
  const bare = href.replace(/^\//, '').replace(/\/$/, '');
  if (!bare) return false; // "/"
  return !fs.existsSync(path.join(root, 'public', bare + '.html')) &&
         !fs.existsSync(path.join(root, 'public', bare, 'index.html'));
});
check('404 page links only to published routes', nfBroken.length === 0,
  nfBroken.map((h) => h + ' -> ' + h.slice(1) + '.html missing').join(', '));
check('404 page is not linked from the rest of the site',
  htmlFiles.every((rel) => !/href="\/404(?:\.html)?["#]/.test(read(rel))));

/* ---- self-hosted fonts -------------------------------------------------- *
 * The Google Fonts stylesheet was render-blocking and put two third-party
 * origins in the CSP. Fonts are now vendored in public/fonts/ (refresh with
 * `node tools/fonts-fetch.js`). These checks stop the old pattern creeping
 * back in: no page may reference googleapis/gstatic, and every content page
 * must link the local /fonts/fonts.css. */
const allHtml = [];
(function walk(dir) {
  for (const e of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
    const rel = dir + '/' + e.name;
    if (e.isDirectory()) walk(rel);
    else if (e.name.endsWith('.html')) allHtml.push(rel);
  }
})('public');
const fontRefFiles = allHtml.filter((rel) => /fonts\.googleapis\.com|fonts\.gstatic\.com/.test(read(rel)));
check('no page loads fonts from Google CDN', fontRefFiles.length === 0, fontRefFiles.join(', '));
// The operations-demo/index.html meta-refresh stub has no styling — skip it.
const noLocalFonts = allHtml.filter((rel) => rel !== 'public/operations-demo/index.html' &&
  !/@font-face|\/fonts\/fonts\.css/.test(read(rel)));
check('every styled page uses the self-hosted font sheet', noLocalFonts.length === 0, noLocalFonts.join(', '));
const fontCss = read('public/fonts/fonts.css');
check('self-hosted faces use font-display swap', (fontCss.match(/font-display:swap/g) || []).length >= 8);
check('font woff2 files referenced by fonts.css exist on disk',
  [...new Set([...fontCss.matchAll(/url\('\/fonts\/([^']+)'\)/g)].map((m) => m[1]))]
    .every((f) => fs.existsSync(path.join(root, 'public/fonts', f))));

console.log('');
if (fail) {
  console.log(`FAIL — ${fail} failed, ${pass} passed`);
  process.exit(1);
}
console.log(`ALL PASS — ${pass}/${pass}`);
