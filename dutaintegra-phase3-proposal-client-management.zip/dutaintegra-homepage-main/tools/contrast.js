const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const p=await c.newPage();
  await p.goto('http://127.0.0.1:8080/',{waitUntil:'networkidle'});
  await p.waitForTimeout(1500);
  const r=await p.evaluate(()=>{
    // Parse "rgb(r, g, b)" / "rgba(r, g, b, a)" -> {r,g,b,a} with a defaulting to 1.
    const parse=c=>{
      const n=(c.match(/[\d.]+/g)||[]).map(Number);
      if(n.length<3) return null;
      return {r:n[0],g:n[1],b:n[2],a:n.length>3?n[3]:1};
    };
    // Detect colours that cannot be resolved to a flat RGB by CSS maths.
    const unflat=cs=>{
      const bi=cs.backgroundImage;
      return !!bi && bi!=='none' && (bi.indexOf('gradient')>-1 || bi.indexOf('url(')>-1);
    };
    // Resolve the effective background behind an element by compositing every
    // translucent layer down the ancestor chain. Gradients/images bail out:
    // they need pixel sampling, which this tool does not do.
    const bgOf=el=>{
      const layers=[];   // outermost -> innermost, flattened
      let e=el;
      while(e&&e!==document.documentElement){
        const cs=getComputedStyle(e);
        if(unflat(cs)) return null;                       // gradient/url-backed: unknowable here
        const c=parse(cs.backgroundColor);
        if(c&&c.a>0){
          layers.push(c);
          if(c.a>=1) break;                               // opaque: chain is complete
        }
        // Ancestor opacity dims everything beneath it, so stop at the first one.
        const op=parseFloat(cs.opacity);
        if(!isNaN(op)&&op<1&&e!==el) return null;         // keep the current collapse, flag unflat
        e=e.parentElement;
      }
      if(!layers.length) return {r:255,g:255,b:255,a:1};
      // Composite from the bottom opaque layer upward: over = top*alpha + under*(1-alpha)
      let out=layers[layers.length-1];
      for(let i=layers.length-2;i>=0;i--){
        const t=layers[i], a=t.a;
        out={r:Math.round(t.r*a+out.r*(1-a)),g:Math.round(t.g*a+out.g*(1-a)),b:Math.round(t.b*a+out.b*(1-a)),a:1};
      }
      return out;
    };
    const lum=c=>{const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(c.r)+.7152*f(c.g)+.0722*f(c.b)};
    // Flatten a possibly-translucent foreground over its (already flat) background.
    const flatFg=(fg,bg)=>{const a=fg.a;return {r:Math.round(fg.r*a+bg.r*(1-a)),g:Math.round(fg.g*a+bg.g*(1-a)),b:Math.round(fg.b*a+bg.b*(1-a)),a:1}};
    const ratio=(fg,bg)=>{const a=lum(fg),b=lum(bg);return +(((Math.max(a,b)+.05)/(Math.min(a,b)+.05))).toFixed(2)};
    const rgb=s=>`rgb(${Math.round(s.r)}, ${Math.round(s.g)}, ${Math.round(s.b)})`;
    const out=[];
    document.querySelectorAll('p,span,li,a,small,label,div').forEach(el=>{
      if(el.children.length) return;
      const t=(el.textContent||'').trim(); if(t.length<3) return;
      const cs=getComputedStyle(el);
      if(cs.display==='none'||cs.visibility==='hidden') return;
      const bg=bgOf(el);
      if(!bg){ return; }              // skip gradient/url/opacity-backed: needs pixel sampling, not CSS maths
      const fs=parseFloat(cs.fontSize);
      const need=(fs>=18||(fs>=14&&parseInt(cs.fontWeight)>=700))?3:4.5;
      const fgRaw=parse(cs.color)||{r:0,g:0,b:0,a:1};
      const fg=flatFg(fgRaw,bg);
      const rr=ratio(fg,bg);
      if(rr<need) out.push({txt:t.slice(0,42),ratio:rr,need,fs:Math.round(fs),fg:rgb(fg),bg:rgb(bg)});
    });
    return out;
  });
  console.log('REAL CONTRAST FAILURES (gradient/url/opacity-backed elements excluded):',r.length,'\n');
  const seen=new Set();
  r.forEach(x=>{
    const key=x.ratio+'@'+x.fs;
    if(seen.has(key))return; seen.add(key);
    console.log(`  ${String(x.ratio).padStart(5)} (need ${x.need})  ${String(x.fs).padStart(2)}px  ${x.fg} on ${x.bg}`);
    console.log(`         "${x.txt}"`);
  });
  await b.close();
})();
