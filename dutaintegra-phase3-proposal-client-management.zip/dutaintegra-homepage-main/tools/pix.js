const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:1280,height:900},deviceScaleFactor:2});
  const p=await c.newPage();
  await p.goto('http://127.0.0.1:8080/',{waitUntil:'networkidle'});
  await p.waitForTimeout(1200);
  await p.evaluate(()=>{document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'));});
  await p.waitForTimeout(600);

  const targets=[
    ['[data-i18n="calcRecoverLabel"], .calc .muted, .calc small','calc recover label'],
    ['footer a[href="/privacy"]','footer privacy link'],
    ['footer a[href="/pricing"]','footer pricing link'],
    ['.calc .scope, .calc .fine, .calc p[style*="font-size:.72rem"]','calc footnote'],
  ];
  for(const [sel,label] of targets){
    const el=await p.$(sel);
    if(!el){console.log(`  ${label}: (not found)`);continue;}
    const box=await el.boundingBox();
    if(!box||box.width<4||box.height<4){console.log(`  ${label}: (no box)`);continue;}
    await el.screenshot({path:`/tmp/pix-${label.replace(/\W/g,'_')}.png`});
    console.log(`  ${label}: ${Math.round(box.width)}x${Math.round(box.height)} → /tmp/pix-${label.replace(/\W/g,'_')}.png`);
  }
  await b.close();
})();
