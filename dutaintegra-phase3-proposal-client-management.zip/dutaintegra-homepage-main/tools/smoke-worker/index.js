/**
 * dutaintegra-smoke — scheduled external check of the live site.
 *
 * Why this exists
 * ---------------
 * The soft-404 defect shipped for months: every unknown URL returned HTTP 200
 * with a full copy of the homepage, because there was no 404.html for
 * Cloudflare Pages to serve. No test caught it, because every test in the
 * repository reads files out of `public/` and can only ever answer "is the
 * repository correct?", never "is the site correct?".
 *
 * tools/smoke-check.js closes that gap for a human at a terminal. GitHub
 * Actions was going to close it automatically, but Actions has never
 * successfully run in this repository — 15 recorded runs, 15 startup
 * failures, zero jobs — so that path is dormant until billing is sorted.
 * This Worker is the Cloudflare-native equivalent: same assertions, no
 * dependency on GitHub, and it runs whether or not anyone pushes.
 *
 * Design notes
 * ------------
 * - Deployed separately from the Pages project it watches, so a bad site
 *   cannot disable its own watchdog.
 * - Nothing here is a secret. Alerting is opt-in: if BREVO_API_KEY and
 *   ALERT_TO are set as Worker secrets it emails on failure, otherwise it
 *   logs. The Worker works either way and the repo contains no credentials.
 * - The POST probe deliberately omits the Origin header. The lead Function
 *   rejects that at the origin boundary with a 403 before it reads the body
 *   or touches the mail provider, so the check proves the endpoint is
 *   mounted and the PDPA boundary is closed without sending any mail.
 * - A failing run throws, so the invocation is recorded as failed in the
 *   cron analytics rather than silently logging a red line nobody reads.
 */

const DEFAULT_ORIGIN = "https://dutaintegra.my";
const TIMEOUT_MS = 20_000;

function probe(origin, path, method = "GET") {
  const url = new URL(path, origin);
  return fetch(url, {
    method,
    redirect: "manual",
    signal: AbortSignal.timeout(TIMEOUT_MS),
    headers: { "User-Agent": "dutaintegra-smoke-worker" },
  }).then(async (res) => {
    // Cap what we read. The homepage is ~170 KB; anything much larger is not
    // a document we are trying to identify.
    const text = (await res.text()).slice(0, 400_000);
    return {
      status: res.status,
      type: res.headers.get("content-type") || "",
      body: text,
    };
  }).catch((err) => ({
    status: 0,
    type: "",
    body: "",
    error: err && err.message ? err.message : String(err),
  }));
}

async function runChecks(origin) {
  const results = [];
  const check = (name, ok, detail) => results.push({ name, ok, detail: ok ? "" : String(detail || "") });

  const home = await probe(origin, "/");
  check("homepage responds 200", home.status === 200,
    `status ${home.status}${home.error ? " " + home.error : ""}`);
  check("homepage is the Duta Integra homepage",
    /<title>[^<]*Duta Integra/.test(home.body),
    home.body.slice(0, 120).replace(/\s+/g, " "));
  check("homepage states a live price, not the retired one",
    /RM\s?2,500/.test(home.body) && !/RM\s?799\b/.test(home.body),
    "RM 2,500 missing or the retired RM 799 is back");

  const service = await probe(origin, "/ai-operations");
  check("service page /ai-operations responds 200", service.status === 200,
    `status ${service.status}`);

  // The headline check. Before public/404.html existed this returned 200
  // with a full copy of the homepage.
  const missing = await probe(origin, `/this-path-should-not-exist-${Date.now().toString(36)}`);
  check("unknown path returns 404, not a soft-404", missing.status === 404,
    `status ${missing.status}${missing.status === 200 ? ` — serving ${missing.body.length} bytes, likely index.html` : ""}`);
  check("the 404 body is the not-found page",
    /Halaman tidak dijumpai|Page not found/.test(missing.body),
    missing.body.slice(0, 100).replace(/\s+/g, " "));

  const stray = await probe(origin, `/nope-${Date.now().toString(36)}.txt`);
  check("unknown asset returns 404", stray.status === 404, `status ${stray.status}`);

  // The real invariant is "must not be HTML", not "must 404" — a stale edge
  // cache can legitimately still hold the retired JPEG for a while, and
  // failing on that would cry wolf until the entry expires.
  const retired = await probe(origin, "/og-image.jpg");
  check("retired /og-image.jpg does not serve HTML",
    retired.status === 404 || !/text\/html/.test(retired.type),
    `status ${retired.status} type ${retired.type}` +
    (retired.status === 200 && /text\/html/.test(retired.type)
      ? ` — serving ${retired.body.length} bytes of HTML, likely index.html` : ""));

  const card = await probe(origin, "/og-image-v2.jpg");
  check("social card /og-image-v2.jpg responds 200 as an image",
    card.status === 200 && /^image\//.test(card.type),
    `status ${card.status} type ${card.type}`);

  const sitemap = await probe(origin, "/sitemap.xml");
  check("sitemap responds 200 as XML", sitemap.status === 200 && /<urlset/.test(sitemap.body),
    `status ${sitemap.status}`);

  // No Origin header on purpose — see the note at the top of this file.
  const endpoint = await probe(origin, "/api/send-email", "POST");
  check("lead endpoint mounted and rejects a foreign origin",
    endpoint.status === 403 || endpoint.status === 405,
    `status ${endpoint.status}`);

  return results;
}

function summaryText(origin, results, failed) {
  const stamp = new Date().toISOString();
  if (!failed.length) {
    return {
      subject: `[dutaintegra] smoke check passed — ${results.length}/${results.length}`,
      body: `${stamp}\nAll ${results.length} checks passed against ${origin}.\n\n` +
        results.map((r) => `  ok    ${r.name}`).join("\n") + "\n",
    };
  }
  return {
    subject: `[dutaintegra] SMOKE CHECK FAILED — ${failed.length} of ${results.length}`,
    body: `${stamp}\nThe live site at ${origin} failed ${failed.length} of ${results.length} checks.\n\n` +
      results.map((r) => `  ${r.ok ? "ok  " : "FAIL"}  ${r.name}${r.detail ? `  [${r.detail}]` : ""}`).join("\n") +
      `\n\nReproduce locally with:\n  npm run deploy:check\n`,
  };
}

async function sendAlert(env, subject, textBody) {
  // Opt-in. If the secrets are not configured the Worker still runs and
  // still logs; it just cannot email. Never hard-fail on alerting, or a
  // Brevo outage would mask the real signal.
  if (!env.BREVO_API_KEY || !env.ALERT_TO) return false;
  try {
    const res = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: { "Content-Type": "application/json", "api-key": env.BREVO_API_KEY },
      body: JSON.stringify({
        sender: { email: env.ALERT_FROM || "no-reply@dutaintegra.my", name: "Duta Integra Smoke Check" },
        to: [{ email: env.ALERT_TO }],
        subject,
        textContent: textBody,
      }),
    });
    if (!res.ok) {
      console.error("[smoke] alert email rejected", res.status, (await res.text()).slice(0, 300));
      return false;
    }
    return true;
  } catch (err) {
    console.error("[smoke] alert email unreachable", err && err.message);
    return false;
  }
}

async function perform(origin, env) {
  const results = await runChecks(origin);
  const failed = results.filter((r) => !r.ok);
  const { subject, body } = summaryText(origin, results, failed);

  // One structured line for the log explorer, plus a readable rendering.
  console.log(JSON.stringify({
    event: "dutaintegra_smoke",
    origin,
    checkedAt: new Date().toISOString(),
    total: results.length,
    failed: failed.length,
    failures: failed.map((r) => ({ check: r.name, detail: r.detail })),
  }));
  console.log(body);

  if (failed.length) {
    const sent = await sendAlert(env, subject, body);
    console.log(`[smoke] failure alert ${sent ? "sent" : "not sent (secrets absent or provider refused)"}`);
  }
  return { results, failed, body };
}

export default {
  async scheduled(_event, env, _ctx) {
    const origin = env.SITE_ORIGIN || DEFAULT_ORIGIN;
    const { failed } = await perform(origin, env);
    // Throwing marks the invocation failed in cron analytics. A silent
    // success is exactly how the original defect stayed invisible.
    if (failed.length) {
      throw new Error(`dutaintegra.my failed ${failed.length} smoke check(s): ` +
        failed.map((f) => f.name).join("; "));
    }
  },

  /**
   * Manual trigger and on-demand run.
   *
   *   curl -H "Authorization: Bearer $MANAGE_TOKEN" https://dutaintegra-smoke.<account>.workers.dev/
   *
   * Returns 404 for anything else, including a missing or wrong token, so
   * the endpoint does not advertise itself or leak site status to a passer-by.
   */
  async fetch(request, env) {
    const token = env.MANAGE_TOKEN;
    const auth = request.headers.get("Authorization") || "";
    if (!token || auth !== `Bearer ${token}`) {
      return new Response("Not found", { status: 404 });
    }
    const url = new URL(request.url);
    const origin = url.searchParams.get("origin") || env.SITE_ORIGIN || DEFAULT_ORIGIN;
    const { results, failed, body } = await perform(origin, env);
    return new Response(body, {
      status: failed.length ? 503 : 200,
      headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" },
    });
  },
};
