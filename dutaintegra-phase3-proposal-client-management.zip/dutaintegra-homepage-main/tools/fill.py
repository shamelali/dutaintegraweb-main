#!/usr/bin/env python3
"""
fill.py — apply config/identity.json to the published documents.

  python3 tools/fill.py            apply
  python3 tools/fill.py --check    report what is still missing, change nothing
  python3 tools/fill.py --revert   restore the pre-fill backups

Refuses to write anything if a required value is still a <placeholder>.
Idempotent: safe to run repeatedly.

--check exits 0 only when the notice is actually publishable (every required
value filled AND no instruction boxes left visible in privacy.html), so it can
be used as a gate:  python3 tools/fill.py --check && deploy
"""
import json, re, sys, shutil, pathlib, datetime

def _default_root():
    """The published site directory.

    Repo layout: <repo>/public holds the deployable site, everything else
    (tools/, config/, docs/, …) lives at <repo> root. Older checkouts kept
    the site files directly beside tools/ — still supported as a fallback.
    """
    legacy = pathlib.Path('/home/user/dutaintegra-homepage')
    if legacy.is_dir():
        return legacy
    here = pathlib.Path(__file__).resolve().parent
    pub = here.parent / 'public'
    if (pub / 'index.html').is_file():
        return pub  # current repo layout
    if (here.parent / 'config' / 'identity.json').is_file():
        return here.parent  # tools/ lives inside the site root (old layout)
    derived = here.parent / 'dutaintegra-homepage'
    if derived.is_dir():
        return derived
    return legacy   # nothing better to offer; load() prints a readable error

REPO   = pathlib.Path(__file__).resolve().parent.parent
ROOT   = _default_root()
CONFIG = REPO / 'config' / 'identity.json'
PRIV   = ROOT / 'privacy.html'
SOW    = REPO / 'pdpa-starter-pack' / 'client-pack' / '08-engagement-letter-and-sow.html'
BAK    = REPO / 'config' / '.backup'

GREEN, RED, AMBER, DIM, OFF = '\033[32m', '\033[31m', '\033[33m', '\033[2m', '\033[0m'

def load():
    if not CONFIG.is_file():
        sys.exit(f'\n  {RED}Cannot find {CONFIG}{OFF}\n'
                 f'  Expected the site at {ROOT}\n'
                 f'  (derived from {pathlib.Path(__file__).resolve()})\n')
    return json.loads(CONFIG.read_text(encoding='utf-8'))

def privacy_markers():
    """Instruction boxes still visible in the published notice (must be 0).

    Counts every element carrying class="fill", not just <span> — the two
    processor-list prompts are <p class="fill">, and counting spans only makes
    the publish gate report 0 while those boxes are still on the page.
    """
    if not PRIV.is_file():
        return None
    return len(re.findall(r'class="fill"', PRIV.read_text(encoding='utf-8')))

def unfilled(v):
    """A value is unfilled if it is empty or still wrapped in <angle brackets>."""
    if v is None: return True
    s = str(v).strip()
    return s == '' or (s.startswith('<') and s.endswith('>'))

def g(cfg, *path):
    cur = cfg
    for k in path:
        if not isinstance(cur, dict) or k not in cur: return None
        cur = cur[k]
    return cur

def check(cfg, verbose=True):
    """Return (list_of_missing_keys, list_of_notes)."""
    missing, notes = [], []

    for key, label in [('effective_date.en','effective date (EN)'), ('effective_date.bm','effective date (BM)')]:
        if unfilled(g(cfg,*key.split('.'))): missing.append(label)
    if unfilled(g(cfg,'business_reg_no','value')): missing.append('business registration number')

    dpo = g(cfg,'dpo_or_contact')
    if dpo and dpo.get('meets_dpo_threshold') is True:
        notes.append('DPO threshold declared MEETING — the notice will call this person a DPO.')
    elif dpo and dpo.get('meets_dpo_threshold') is False:
        notes.append('DPO threshold declared NOT met — the notice will call this a data protection contact.')
    else:
        missing.append('dpo_or_contact.meets_dpo_threshold (true or false)')
    if unfilled(g(cfg,'dpo_or_contact','en')): missing.append('DPO / contact name (EN)')
    if unfilled(g(cfg,'dpo_or_contact','bm')): missing.append('DPO / contact name (BM)')

    if unfilled(g(cfg,'dpo_email','address')): missing.append('DPO contact email address')

    if g(cfg,'retention','confirmed') is not True:
        missing.append('retention.confirmed — set true once the retention table matches how you work')

    if unfilled(g(cfg,'cookies','en')): missing.append('cookies description (EN)')
    if unfilled(g(cfg,'cookies','bm')): missing.append('cookies description (BM)')

    if unfilled(g(cfg,'proprietor_name','value')): missing.append('proprietor name (SOW)')

    if verbose:
        print(f'\n  {"─"*62}')
        if missing:
            print(f'  {AMBER}STILL TO FILL: {len(missing)}{OFF}')
            for m in missing: print(f'    · {m}')
        else:
            print(f'  {GREEN}All required values present — ready to apply.{OFF}')
        if notes:
            print(f'\n  {DIM}Decisions recorded:{OFF}')
            for n in notes: print(f'    · {n}')

        # Different bookkeeping from the list above, so report both numbers
        # side by side: this counts what a VISITOR would see, not config keys.
        # They are both 6 today by coincidence — the two sets do not match
        # (privacy.html has two processor-list boxes that identity.json does
        # not know about; identity.json has effective_date.bm and the SOW
        # proprietor name, which have no box in privacy.html).
        markers = privacy_markers()
        if markers is None:
            print(f'\n  {RED}privacy.html not found at {PRIV}{OFF}')
        elif markers:
            print(f'\n  {AMBER}privacy.html: {markers} instruction box(es) visible to the public{OFF}')
            print(f'    · launch gate is 0 — grep -n \'class="fill"\' privacy.html')
            print(f'    · these are not all driven by identity.json; some need a direct edit')
        else:
            print(f'\n  {GREEN}privacy.html: no instruction boxes visible{OFF}')

        print(f'  {"─"*62}')
    return missing, notes

def sub_spans(html, marker_start, replacement):
    """Replace the whole <span class="fill">…marker…</span> whose text begins with marker_start."""
    pat = re.compile(r'<span class="fill">' + re.escape(marker_start) + r'.*?</span>', re.S)
    new, n = pat.subn(replacement, html, count=1)
    if n == 0:
        pat2 = re.compile(r'<span class="fill">\s*' + re.escape(marker_start) + r'.*?</span>', re.S)
        new, n = pat2.subn(replacement, html)
    return new, n

def apply(cfg, partial=False):
    missing, notes = check(cfg, verbose=False)
    if missing and not partial:
        check(cfg, verbose=True)
        print(f'\n  {RED}Not writing anything — {len(missing)} value(s) missing.{OFF}')
        print(f'  {DIM}Edit {CONFIG} and run again, or use --partial to apply only the values you have.{OFF}\n')
        return 1
    if missing:
        print(f'\n  {AMBER}PARTIAL APPLY{OFF} — applying verified values only.')
        print(f'  {DIM}{len(missing)} value(s) still missing; their checkboxes will remain visible.{OFF}')

    # backup once, before the first real write
    BAK.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    for f in (PRIV, SOW):
        b = BAK / f'{f.name}.prefill'
        if not b.exists():
            shutil.copy2(f, b)
            print(f'  {DIM}backed up {b.name}{OFF}')

    changes = []

    # ---------- privacy.html ----------
    h = PRIV.read_text(encoding='utf-8')
    orig_privacy = h
    # class="fill" on any tag: the processor prompts are <p class="fill">, and
    # counting <span> alone let this gate say READY while they were visible.
    before_fills = len(re.findall(r'class="fill"', h))

    eff = g(cfg,'effective_date','en')
    if not unfilled(eff):
        h, n = sub_spans(h, '[CONFIRM: date you publish this', eff.strip()); changes.append(('effective date (EN)', n))
    else:
        changes.append(('effective date (EN)', 0))

    reg = g(cfg,'business_reg_no','value').strip()
    h, n = sub_spans(h, '[CONFIRM: SSM business registration number', reg)
    changes.append(('registration no. (EN)', n))
    h, n = sub_spans(h, '[SAHKAN: nombor pendaftaran perniagaan SSM', reg)
    changes.append(('registration no. (BM)', n))

    meets = g(cfg,'dpo_or_contact','meets_dpo_threshold')
    if meets is not None:
        role_en = 'Data Protection Officer' if meets else 'data protection contact'
        role_bm = 'Pegawai Perlindungan Data (DPO)' if meets else 'pegawai hubungan perlindungan data'
        h = h.replace('Our Data Protection Officer is ', f'Our {role_en} is ')
        h = h.replace('Pegawai Perlindungan Data (DPO) kami ialah ', f'{role_bm[0].upper()+role_bm[1:]} kami ialah ')
        if not meets:
            h = h.replace(f'<a href="mailto:{g(cfg,"dpo_email","address")}">', '<a href="mailto:support@dutaintegra.my">')

    nm_en = g(cfg,'dpo_or_contact','en')
    if not unfilled(nm_en):
        h, n = sub_spans(h, '[CONFIRM: DPO name or job title', nm_en.strip()); changes.append(('contact name (EN)', n))
    else:
        changes.append(('contact name (EN)', 0))
    nm_bm = g(cfg,'dpo_or_contact','bm')
    if not unfilled(nm_bm):
        h, n = sub_spans(h, '[SAHKAN: nama atau jawatan DPO', nm_bm.strip()); changes.append(('contact name (BM)', n))
    else:
        changes.append(('contact name (BM)', 0))

    mail = g(cfg,'dpo_email','address').strip()
    note_en = g(cfg,'dpo_email','en_note').strip()
    note_bm = g(cfg,'dpo_email','bm_note').strip() if g(cfg,'dpo_email','bm_note') else ''
    h, n = sub_spans(h, '[CONFIRM: create this mailbox', f'({note_en})')
    changes.append(('mailbox note (EN)', n))

    # every remaining dpo@ reference must agree with the configured address
    h = h.replace('mailto:dpo@dutaintegra.my">dpo@dutaintegra.my<', f'mailto:{mail}">{mail}<')

    # role wording must agree across the whole notice, not just section 1
    if meets is False:
        n = 0
        for a, b in [('our DPO', 'our data protection contact'),
                     ('DPO kami', 'pegawai hubungan perlindungan data kami')]:
            n += h.count(a)
            h = h.replace(a, b)
        changes.append(('role wording harmonised', n))

    if g(cfg,'retention','confirmed') is True:
        h, n = sub_spans(h, '[CONFIRM: these periods are sensible defaults', '')
        changes.append(('retention prompt removed', n))

    ck = g(cfg,'cookies','en')
    if not unfilled(ck):
        h, n = sub_spans(h, '[CONFIRM: if you add analytics', ck.strip()); changes.append(('cookies (EN)', n))
    else:
        changes.append(('cookies (EN)', 0))
    ck = g(cfg,'cookies','bm')
    if not unfilled(ck):
        h, n = sub_spans(h, '[SAHKAN: jika anda menambah analitik', ck.strip()); changes.append(('cookies (BM)', n))
    else:
        changes.append(('cookies (BM)', 0))

    after_fills = len(re.findall(r'class="fill"', h))
    if h != orig_privacy:
        PRIV.write_text(h, encoding='utf-8')

    # ---------- SOW ----------
    s = SOW.read_text(encoding='utf-8')
    s2 = s.replace('Business registration no. <span class="f">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>',
                   f'Business registration no. <strong>{reg}</strong>')
    prop = g(cfg,'proprietor_name','value')
    if not unfilled(prop):
        s2 = s2.replace('Owner / proprietor: <span class="f">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>',
                        f'Owner / proprietor: <strong>{prop.strip()}</strong>')
    if s2 != s:
        SOW.write_text(s2, encoding='utf-8')
        changes.append(('SOW parties table', 2))

    # ---------- report ----------
    print(f'\n  {"─"*62}')
    for label, n in changes:
        mark = f'{GREEN}✓{OFF}' if n else f'{DIM}·{OFF}'
        print(f'  {mark} {label:<28} {n if n else "already applied"}')
    print(f'  {"─"*62}')
    print(f'\n  privacy.html  {before_fills} → {after_fills} unfilled markers')
    if after_fills == 0:
        print(f'  {GREEN}READY TO PUBLISH{OFF} — no instruction boxes will be shown to the public.\n')
    else:
        print(f'  {AMBER}NOT READY TO PUBLISH{OFF} — {after_fills} instruction box(es) would still be visible.')
        print(f'  {DIM}Run --check for the remaining list.\n{OFF}')
    return 0

def revert():
    if not BAK.exists():
        print('  no backups found'); return 1
    n = 0
    for b in BAK.glob('*.prefill'):
        target = PRIV if b.name.startswith('privacy') else SOW
        shutil.copy2(b, target); n += 1
        print(f'  {GREEN}restored{OFF} {target.name}')
    print(f'\n  {n} file(s) reverted. Backups kept in {BAK}\n')
    return 0

if __name__ == '__main__':
    cfg = load()
    if '--check' in sys.argv:
        missing, _ = check(cfg)
        markers = privacy_markers()
        ready = (not missing) and markers == 0
        if ready:
            print(f'\n  {GREEN}READY TO PUBLISH{OFF} — config complete, no instruction boxes visible.\n')
        else:
            print(f'\n  {AMBER}NOT READY TO PUBLISH{OFF} — '
                  f'{len(missing)} value(s) to fill, '
                  f'{markers if markers is not None else "?"} instruction box(es) visible.\n')
        sys.exit(0 if ready else 1)
    if '--revert' in sys.argv:
        sys.exit(revert())
    sys.exit(apply(cfg, partial='--partial' in sys.argv))
