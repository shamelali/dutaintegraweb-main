const { chromium } = require('playwright');
const routes=['/','/pdpa-checklist','/privacy','/terms','/audit-scorecard','/scorecard','/robots.txt','/sitemap.xml'];
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  let fail=0;
  for(const vp of [{w:1440,h:900,n:'desk'},{w:390,h:844,n:'mob'}]){
    for(const r of routes){
      const c=await b.newContext({viewport:{width:vp.w,height:vp.h}});
      const p=await c.newPage(); const errs=[];
      p.on('pageerror',e=>errs.push(e.message));
      let st=0;
      try{ st=(await p.goto('http://127.0.0.1:8080'+r,{waitUntil:'load',timeout:15000})).status(); }catch(e){ st='ERR'; }
      await p.waitForTimeout(350);
      const m=await p.evaluate(()=>({chars:(document.body.innerText||'').replace(/\s+/g,' ').trim().length,
        over:document.documentElement.scrollWidth>document.documentElement.clientWidth+2}));
      const isXML=r.includes('.')&&!r.includes('privacy');
      const ok = st===200 && !errs.length && (isXML || (!m.over && m.chars>200));
      if(!ok) fail++;
      console.log(`${ok?'PASS':'FAIL'} [${vp.n}] ${r.padEnd(17)} ${st} | ${m.chars} chars${(m.over&&!isXML)?' | ⚠OVERFLOW':''}${errs.length?' | ⚠'+errs[0].slice(0,50):''}`);
      await c.close();
    }
  }
  const total = routes.length * 2;   // two viewports per route
  console.log(fail?`\n${fail} FAILURES`:`\nALL PASS — ${total}/${total}`);
  await b.close();
})();
