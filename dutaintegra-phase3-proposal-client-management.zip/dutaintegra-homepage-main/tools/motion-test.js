#!/usr/bin/env node
/** Verify the motion additions actually run in a real browser. */
'use strict';
const { chromium } = require('/media/shamelali/Data/projects/dutaintegra_homepage/tools/deps/node_modules/playwright');
const URL = 'http://127.0.0.1:8788/';

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  let bad = 0;
  const ok = (n, c, d) => { console.log((c ? '  ok   ' : '  FAIL ') + n + (c ? '' : '  [' + d + ']')); if (!c) bad++; };

  /* CSS transitions are sampled asynchronously, so an exact-equality check on
     a computed transform is a race. Poll until the value stops moving. */
  async function settled(page, selector, pseudo) {
    let last = null, stable = 0;
    for (let i = 0; i < 60; i++) {
      const v = await page.$eval(selector, (el, p) =>
        p ? getComputedStyle(el, p).transform : getComputedStyle(el).transform, pseudo || null);
      if (v === last) { if (++stable >= 3) return v; } else { stable = 0; last = v; }
      await page.waitForTimeout(50);
    }
    return last;
  }
  /* translateY / scaleX still a hair away from the end state */
  const nearIdentity = (m, tol) => {
    const n = m.match(/-?\d+(\.\d+)?/g);
    if (!n) return m === 'none';
    const a = n.map(Number);
    if (a.length < 6) return true;
    return Math.abs(a[5]) < tol && a[0] > 0.999;
  };

  /* ---- normal motion ---- */
  let page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1800);

  console.log('\nhero + journey');
  ok('no JS errors', errs.length === 0, errs.join(' | '));
  ok('both hero lines revealed', await page.$$eval('.hero h1 .rl.in', (n) => n.length) === 2);
  const masked = await settled(page, '.hero h1 .rl > span');
  ok('revealed line settles at the top of its mask', nearIdentity(masked, 0.5), masked);
  ok('h1 has 2 masked lines', await page.$$eval('.hero h1 .rl', (n) => n.length) === 2);

  await page.$eval('#journey', (el) => el.scrollIntoView({ block: 'center' }));
  await page.waitForTimeout(1600);
  ok('journey rail drew in', await page.$eval('#journey', (el) => el.classList.contains('in')));
  ok('journey has 4 steps', await page.$$eval('#journey .jstep', (n) => n.length) === 4);
  ok('journey has 3 connectors', await page.$$eval('#journey .jline', (n) => n.length) === 3);
  const scale = await settled(page, '#journey .jline', '::after');
  ok('connector settles fully drawn', nearIdentity(scale, 0.01), scale);

  console.log('\nprices');
  const prices = await page.$$eval('.price .num', (n) => n.map((x) => x.textContent));
  ok('three tier prices counted', prices.length === 3, prices.join('|'));
  ok('prices land exactly', prices.join(',') === '2,500,7,500,12,000', prices.join(','));
  ok('RM prefix preserved', (await page.$eval('.price .cur', (e) => e.textContent)).trim() === 'RM');
  const suffix = (await page.$eval('.price small', (e) => e.textContent)).trim();
  ok('per-month suffix intact', suffix === '/month' || suffix === '/bulan', suffix);

  console.log('\nnav');
  /* Nothing is marked above the first tracked section, and each tracked
     section marks its OWN link once it is the one being read. This used to
     assert only that one link was marked, which passed even when the mark
     was stale on the previous section — an IntersectionObserver spy never
     fired for sections the page cannot scroll far enough to reach.
     Scrolling is forced instant so the assertion cannot race the smooth
     scroll animation and read a mid-flight position. */
  const markNow = () => page.$$eval('.nav a[aria-current="true"]', (n) => n.map((x) => x.textContent.trim()));
  const scrollTo = (id) => page.evaluate((i) => {
    document.documentElement.style.scrollBehavior = 'auto';
    const el = document.getElementById(i);
    window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY, behavior: 'auto' });
  }, id);

  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'auto' }));
  await page.waitForTimeout(400);
  ok('no nav link marked above the first section',
    (await markNow()).length === 0, (await markNow()).join('|'));

  /* Labels resolve from the nav itself, not hardcoded strings: BM is the
     site default, so the same assertion must hold whichever language the
     page rendered. The spy must mark the link POINTING AT the section. */
  for (const id of ['health-check', 'pricing', 'faq']) {
    await scrollTo(id);
    await page.waitForTimeout(450);
    const cur = await markNow();
    const expected = await page.$eval(`.nav a[href="#${id}"]`, (e) => e.textContent.trim());
    ok(`reading #${id} marks exactly one link`, cur.length === 1, cur.join('|'));
    ok(`reading #${id} marks its own link (${expected})`, cur[0] === expected, cur.join('|'));
  }
  const cur = await markNow();
  await page.hover('.nav-group .nav-trigger');
  await page.waitForTimeout(300);
  const panel = await page.$eval('.nav-group[data-open="true"] .nav-panel', (el) => getComputedStyle(el).opacity);
  ok('dropdown opens on hover', panel === '1', panel);
  await page.click('.nav-group .nav-trigger');
  await page.waitForTimeout(250);
  ok('click after hover does not slam it shut',
     await page.$eval('.nav-group .nav-trigger', (el) => el.closest('.nav-group').getAttribute('data-open')) === 'true');
  ok('aria-expanded stays true after that click',
     await page.$eval('.nav-group .nav-trigger', (el) => el.getAttribute('aria-expanded')) === 'true');
  await page.close();

  /* ---- reduced motion: everything must be final state ---- */
  console.log('\nprefers-reduced-motion');
  page = await browser.newPage({ viewport: { width: 1280, height: 900 }, reducedMotion: 'reduce' });
  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.waitForTimeout(700);
  const rmHero = await page.$eval('.hero h1 .rl > span', (el) => getComputedStyle(el).transform);
  ok('hero not translated under reduce', rmHero === 'none', rmHero);
  await page.$eval('#pricing', (el) => el.scrollIntoView());
  await page.waitForTimeout(1200);
  const rmPrices = await page.$$eval('.price .num', (n) => n.map((x) => x.textContent));
  ok('prices show final value immediately', rmPrices.join(',') === '2,500,7,500,12,000', rmPrices.join(','));
  const rmScale = await page.$eval('#journey .jline', (el) => getComputedStyle(el, '::after').transform);
  ok('connector already drawn under reduce', rmScale === 'matrix(1, 0, 0, 1, 0, 0)' || rmScale === 'none', rmScale);
  await page.close();

  /* ---- no JS: content must still be present ---- */
  console.log('\nJavaScript disabled');
  const ctx = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 1280, height: 900 } });
  page = await ctx.newPage();
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  const noJs = await page.$$eval('.price .num', (n) => n.map((x) => x.textContent));
  ok('prices readable without JS', noJs.join(',') === '2,500,7,500,12,000', noJs.join(','));
  const noJsH1 = await page.$eval('.hero h1', (el) => getComputedStyle(el).opacity);
  ok('hero visible without JS', noJsH1 === '1', noJsH1);
  await page.close();

  /* ---- BM ---- */
  console.log('\nBahasa Malaysia');
  page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  await page.goto(URL + '?lang=bm', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const jrn = await page.$$eval('#journey .jlabel', (n) => n.map((x) => x.textContent));
  ok('journey labels translated', jrn.join(',') === 'Laman web,IT terurus,Automasi,Ejen AI', jrn.join(','));
  ok('html lang switched to ms', await page.$eval('html', (e) => e.lang) === 'ms');
  await page.close();

  await browser.close();
  console.log(bad ? '\n' + bad + ' FAILED' : '\nall motion checks passed');
  process.exit(bad ? 1 : 0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });