#!/usr/bin/env node
/**
 * i18n-test.js — static checks for the EN/BM layer on index.html.
 *
 * Run:  node tools/i18n-test.js     (exit 0 = all pass)
 *
 * Guards the things that are invisible to the other suites:
 *   1. document integrity (the batch tool once duplicated the file)
 *   2. every [data-i18n] key exists in the BM dictionary
 *   3. every BM dictionary key is actually used by the markup
 *   4. no nested data-i18n (a parent swap would destroy the child key)
 *   5. every t()/tpl() key exists in DYN (JS-written strings)
 *   6. privacy §11 still holds: no cookie, localStorage or sessionStorage
 *   7. BM-default wiring (?lang=en opts out) + documentElement.lang swap + pinned <option> values
 */
'use strict';

const fs = require('fs');
const path = require('path');

const FILE = [
  path.join(__dirname, '..', 'public', 'index.html'),              // current repo layout
  path.join(__dirname, '..', 'index.html'),                        // tools/ inside site root
  path.join(__dirname, '..', 'dutaintegra-homepage', 'index.html'), // tools/ beside site dir
].find(p => fs.existsSync(p));
const html = fs.readFileSync(FILE, 'utf8');

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

/* ---- 1. document integrity ------------------------------------------ */
check('single doctype', (html.match(/<!doctype html>/gi) || []).length === 1);
check('single </html>', (html.match(/<\/html>/g) || []).length === 1);
check('single <body', (html.match(/<body[ >]/g) || []).length === 1);
check('file size sane (< 250 KB)', html.length < 250_000, html.length + ' bytes');

/* ---- strip comments + script/style bodies for tag scanning ---------- */
let scan = html.replace(/<!--[\s\S]*?-->/g, '');
scan = scan.replace(/(<script\b[^>]*>)([\s\S]*?)(<\/script>)/gi, '$1$3');
scan = scan.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi, '$1$3');

/* ---- collect markup keys + nesting ---------------------------------- */
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
  'link', 'meta', 'param', 'source', 'track', 'wbr', 'use', 'path', 'circle',
  'rect', 'line', 'polygon', 'polyline', 'stop']);
const markupKeys = [];
let nesting = [];
const stack = [];   // [{tag, key}]
const tagRe = /<(\/?)([a-zA-Z][\w-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/g;
let m;
while ((m = tagRe.exec(scan)) !== null) {
  const closing = m[1] === '/', tag = m[2].toLowerCase(), attrs = m[3];
  if (closing) {
    for (let i = stack.length - 1; i >= 0; i--) {
      if (stack[i].tag === tag) { stack.length = i; break; }
    }
    continue;
  }
  const km = attrs.match(/\bdata-i18n="([^"]+)"/);
  const key = km ? km[1] : null;
  if (key) {
    markupKeys.push(key);
    // only an innerHTML swap can destroy a child key; data-i18n-attr
    // elements (aria-label, placeholder) rewrite an attribute instead
    const parent = stack[stack.length - 1];
    const parentAttr = /\bdata-i18n-attr=/.test(parent && parent.rawAttrs || '');
    if (parent && parent.key && !parentAttr) nesting.push(key + ' inside ' + parent.key);
  }
  const selfClose = /\/\s*$/.test(attrs) || VOID.has(tag);
  if (!selfClose) stack.push({ tag, key, rawAttrs: attrs });
}

/* ---- 2/3. markup keys vs BM dict ------------------------------------ */
const dictBlock = (html.match(/^\s{2}var BM = \{([\s\S]*?)^\s{2}\};/m) || [])[1] || '';
const dictKeys = [...dictBlock.matchAll(/^\s{4}([A-Za-z0-9_]+):/gm)].map(x => x[1]);
const dictSet = new Set(dictKeys), markupSet = new Set(markupKeys);

const missingInDict = [...markupSet].filter(k => !dictSet.has(k));
const unusedInHtml = [...dictSet].filter(k => !markupSet.has(k));
check('every [data-i18n] key has BM copy (' + markupSet.size + ' keys)',
  missingInDict.length === 0, missingInDict.join(', '));
check('every BM key is used by the markup (' + dictKeys.length + ' keys)',
  unusedInHtml.length === 0, unusedInHtml.join(', '));
check('no duplicate BM keys', dictKeys.length === dictSet.size);
check('no nested data-i18n', nesting.length === 0, nesting.join('; '));

/* A stray CJK / Hangul / Cyrillic character is always a generation accident,
   never valid Bahasa Malaysia. This caught a Korean syllable that had slipped
   into pr3b7 and would otherwise have shipped to every BM visitor. */
const FOREIGN = /[\u3000-\u9fff\uac00-\ud7af\u0400-\u04ff]/;
const foreignInDict = [];
for (const m of dictBlock.matchAll(/^\s{4}([A-Za-z0-9_]+):'((?:[^'\\]|\\.)*)'/gm)) {
  if (FOREIGN.test(m[2])) foreignInDict.push(m[1]);
}
check('no CJK/Hangul/Cyrillic in BM strings', foreignInDict.length === 0, foreignInDict.join(', '));
check('no CJK/Hangul/Cyrillic in visible markup', !FOREIGN.test(scan),
  (scan.match(FOREIGN) || []).slice(0, 3).join(' '));

/* ---- 4. DYN keys used by the script --------------------------------- */
const dynBlock = (html.match(/var DYN = \{([\s\S]*?)\n  \};/) || [])[1] || '';
const dynKeys = new Set([...dynBlock.matchAll(/^\s{4}([A-Za-z0-9_]+):\s*\{/gm)].map(x => x[1]));
const used = new Set([
  ...[...html.matchAll(/\bt\('([A-Za-z0-9_]+)'\)/g)].map(x => x[1]),
  ...[...html.matchAll(/\btpl\('([A-Za-z0-9_]+)'/g)].map(x => x[1]),
]);
// t('…') inside DYN itself would be a false positive; DYN uses no t()
const unknownDyn = [...used].filter(k => !dynKeys.has(k));
check('every t()/tpl() key exists in DYN (' + used.size + ' used, ' + dynKeys.size + ' defined)',
  unknownDyn.length === 0, unknownDyn.join(', '));
const dynNoEn = [...dynKeys].filter(k => !new RegExp('^\\s{4}' + k + ':\\s*\\{\\s*en:', 'm').test(html));
check('every DYN entry has an en string', dynNoEn.length === 0, dynNoEn.join(', '));

/* ---- 5. privacy §11: nothing stored ---------------------------------
   Usage patterns only: comments are allowed to name the APIs. */
check('no localStorage use', !/localStorage\s*[\.\[]/.test(html));
check('no sessionStorage use', !/sessionStorage\s*[\.\[]/.test(html));
check('no document.cookie', !/document\.cookie/.test(html));

/* ---- 6. wiring ------------------------------------------------------- */
check('BM default on init; ?lang=en opts out', /URLSearchParams\(location\.search\)\.get\('lang'\) !== 'en'/.test(html));
check('language choice written via replaceState', /history\.replaceState/.test(html));
check('documentElement.lang swapped', /documentElement\.lang = bm \? 'ms' : 'en'/.test(html));
check('attribute swap via data-i18n-attr', /data-i18n-attr/.test(html));
check('setLang defined', /function setLang\(bm\)/.test(html));

/* ---- 7. <option> values pinned (payload stays stable in BM) ---------- */
const opts = [...scan.matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/gi)];
const unpinned = opts.filter(o => !/\bvalue="/.test(o[1]));
check('all <option> elements pin value=' + opts.length, unpinned.length === 0,
  unpinned.map(o => o[2].trim().slice(0, 30)).join(', '));

console.log('');
if (fail) { console.log('FAIL — ' + fail + ' failed, ' + pass + ' passed'); process.exit(1); }
console.log('ALL PASS — ' + pass + '/' + pass);
