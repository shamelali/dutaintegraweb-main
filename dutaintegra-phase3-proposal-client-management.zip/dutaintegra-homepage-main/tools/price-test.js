#!/usr/bin/env node
/**
 * price-test.js — one place that knows the published prices.
 *
 * Prices are the highest-drift copy on this site. They are currently encoded
 * in 11 files for Foundation alone, and this repo has been bitten three times
 * in a single session: index.html metadata kept the withdrawn RM 799 Starter,
 * terms.html and ask-ai.js kept it in both languages, and a deploy left a
 * stale social card advertising it.
 *
 * This test is the guard. It does not generate the markup - the site is
 * hand-maintained static HTML with no build step - but it fails the build if
 * any surface disagrees with the figures below, or if a withdrawn price or
 * tier name reappears anywhere in the deployable output.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const PUBLIC = path.join(__dirname, '..', 'public');

/* ---- the single source of truth. Change a price here first, then fix the
   surfaces, then run npm test. ---- */
const TIERS = [
  { name: 'Starter', monthly: 799, label: 'RM 799' },
  { name: 'Foundation', monthly: 2500, label: 'RM 2,500' },
  { name: 'Enterprise', monthly: null, label: 'Custom' },
];
const PROJECTS = [
  { name: 'AI integration / website', from: 2500 },
  { name: 'AI chatbot', from: 3500 },
  { name: 'Cloud migration', from: 4000 },
  { name: 'Process automation', from: 5000 },
  { name: 'ML model', from: 8000 },
];
const PDPA_PACKS = [599, 1999, 3999];

/* Retired. Any reappearance is a regression: these were withdrawn when the
   tiers were restructured back to the Starter/Foundation/Enterprise model. */
const RETIRED = [
  { pattern: /RM\s?12,000\b/, label: 'retired RM 12,000 price' },
  { pattern: /RM\s?7,500\b/, label: 'retired RM 7,500 price' },
  { pattern: />AI Partner</, label: 'retired AI Partner tier' },
  { pattern: />Growth</, label: 'retired Growth tier' },
];

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

/* Walk the deployable output. Skips internal docs and backups, which are not
   published and are allowed to mention historical prices. */
const SKIP_DIRS = new Set(['pdpa-starter-pack', 'operations-demo', 'lead-magnet']);
function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      walk(full, out);
    } else if (/\.(html|js)$/.test(entry.name)) {
      out.push(full);
    }
  }
  return out;
}
const files = walk(PUBLIC);
const rel = (f) => path.relative(path.join(__dirname, '..'), f);

console.log('retired figures must not appear in published output');
const retiredHits = [];
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const r of RETIRED) {
    if (r.pattern.test(src)) retiredHits.push(rel(f) + ' (' + r.label + ')');
  }
}
check('no retired price or tier name in ' + files.length + ' published files',
  retiredHits.length === 0, retiredHits.join(', '));

/* The two surfaces that actually publish the tier table. Other pages may
   mention a tier by name in prose without listing a price for it - the
   Managed IT page says "AI Partner adds dedicated strategy time" and
   correctly does not repeat every price - so only these two are asserted. */
const PRICING_SURFACES = ['public/index.html', 'public/pricing.html'];

/* Prices are written as `RM <span>7,500</span>` on some pages and `RM 7,500`
   on others, so a literal substring match misses half of them. Strip tags and
   collapse whitespace before looking for a figure. */
const flat = (src) => src
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
  .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&nbsp;/g, ' ')
  .replace(/\s+/g, ' ');

console.log('\neach pricing surface pairs every tier with its canonical price');
for (const surface of PRICING_SURFACES) {
  const src = fs.readFileSync(path.join(PUBLIC, path.basename(surface)), 'utf8');
  const text = flat(src);
  for (const tier of TIERS) {
    /* Search every occurrence rather than the first: "Foundation" also
       appears in the ROI calculator copy, well above the pricing table, so
       first-match would pair the name with the wrong text. Require at least
       one place where the price sits close behind its own tier name. */
    let paired = false, seen = '';
    let from = 0, at;
    while ((at = text.indexOf(tier.label, from)) > -1) {
      const before = text.slice(Math.max(0, at - 300), at);
      if (before.includes(tier.name)) { paired = true; break; }
      if (!seen) seen = text.slice(Math.max(0, at - 60), at + 40);
      from = at + 1;
    }
    check(surface + ': ' + tier.name + ' shows ' + tier.label, paired,
      paired ? '' : (tier.name + ' not found next to its price; nearest price context: "' + seen.trim() + '"'));
  }
}

/* Card-level check: every rendered tier card must show its own tier's price.
   The "at least one pairing" rule above is too weak - a card can drift while
   a sentence elsewhere still states the old figure and the page looks
   internally consistent to a substring search. Both pricing surfaces render
   the same markup (an h3 tier name followed by a .price block), so the cards
   can be compared directly. */
console.log('\nevery rendered tier card shows its own tier\'s price');
for (const surface of PRICING_SURFACES) {
  const src = fs.readFileSync(path.join(PUBLIC, path.basename(surface)), 'utf8');
  const bad = [];
  const cardRe = /<h3[^>]*>\s*(Starter|Foundation|Enterprise)\s*<\/h3>([\s\S]{0,1400}?)class="price"[^>]*>/g;
  let m;
  while ((m = cardRe.exec(src)) !== null) {
    const tierName = m[1];
    const canonical = TIERS.find((t) => t.name === tierName);
    /* Take the markup AFTER the .price opening tag: on these pages the figure
       lives in a child span, so a window that stops at the tag sees nothing. */
    const tail = src.slice(m.index + m[0].length, m.index + m[0].length + 320);
    const figs = [...flat(tail).matchAll(/RM\s?([\d,]{3,})/g)].map((x) => Number(x[1].replace(/,/g, '')));
    if (!figs.length) {
      if (canonical.monthly === null) continue; /* Custom has no numeric price */
      bad.push(surface + ': ' + tierName + ' card has no readable price'); continue;
    }
    if (canonical.monthly !== null && figs[0] !== canonical.monthly) {
      bad.push(surface + ': ' + tierName + ' card shows ' + figs[0] + ', expected ' + canonical.monthly);
    }
  }
  check(surface + ': all tier cards priced correctly', bad.length === 0, bad.join(' | '));
}

/* Deliberately NOT asserted: "no tier name appears next to another tier's
   price". Real copy does that legitimately - the AI Operations page says
   "Foundation at RM 2,500 and Growth at RM 7,500 are available if you want to
   start smaller" - so the heuristic flagged correct prose as drift. A guard
   that fires on correct content trains people to ignore it. What is checked
   instead is the pairing on the two canonical pricing surfaces, plus the
   retired-figure sweep, which is unambiguous. */

console.log('\nstructured data must not contradict the visible page');
const index = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
for (const tier of TIERS) {
  if (tier.monthly === null) continue; /* Custom has no numeric offer price */
  const offerRe = new RegExp(
    '"name"\\s*:\\s*"[^"]*' + tier.name + '[^"]*"[^}]*?"price"\\s*:\\s*"(\\d+)"', 'i');
  const m = index.match(offerRe);
  if (!m) {
    // the offer block may use a different key order; fall back to a proximity check
    const near = new RegExp('"' + tier.name + '[^"\\n]{0,80}\\n[^\\n]{0,80}?"price"\\s*:\\s*"(\\d+)"', 'i');
    const m2 = index.match(near);
    check('JSON-LD offer for ' + tier.name + ' = ' + tier.monthly,
      m2 ? Number(m2[1]) === tier.monthly : false, m2 ? m2[1] : 'offer not found');
  } else {
    check('JSON-LD offer for ' + tier.name + ' = ' + tier.monthly, Number(m[1]) === tier.monthly, m[1]);
  }
}

console.log('\nmetadata must not advertise a withdrawn figure');
const title = (index.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
check('title states a live starting price', /RM\s?799/.test(title), title.slice(0, 80));
for (const name of ['og:title', 'twitter:title']) {
  const re = new RegExp('"' + name + '"\\s+content="([^"]*)"');
  const m = index.match(re);
  check(name + ' states a live starting price', m ? /RM\s?799/.test(m[1]) : false,
    m ? m[1].slice(0, 80) : 'not found');
}
check('no page still links the retired og-image.jpg',
  files.every((f) => !fs.readFileSync(f, 'utf8').includes('/og-image.jpg"')),
  files.filter((f) => fs.readFileSync(f, 'utf8').includes('/og-image.jpg"')).map(rel).join(', '));

console.log('\nproject and pack prices');
for (const p of PROJECTS) {
  const pretty = 'RM ' + p.from.toLocaleString('en-US');
  const found = files.some((f) => flat(fs.readFileSync(f, 'utf8')).includes(pretty));
  check(p.name + ' ' + pretty + ' is published', found, 'not found');
}
for (const v of PDPA_PACKS) {
  const pretty = 'RM ' + v.toLocaleString('en-US');
  check('PDPA pack ' + pretty + ' still published',
    files.some((f) => fs.readFileSync(f, 'utf8').includes(pretty)), 'not found');
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);