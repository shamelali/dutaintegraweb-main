/* Dependency-free checks for the public Ask AI answer helper and browser guardrails. */
const fs = require('fs');
const path = require('path');

const sourcePath = path.join(__dirname, '..', 'public', 'ask-ai.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const homepage = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const answerFor = require(sourcePath);

const ok = (condition, message) => {
  if (!condition) throw new Error(`FAIL ${message}`);
  console.log(`ok    ${message}`);
};

ok(typeof answerFor === 'function', 'CommonJS export is the pure answerFor function');
const guide = answerFor('How do I use the audit scorecard?');
ok(guide.answer.includes('not an interactive calculator'), 'scorecard guide describes the worksheet as non-interactive');
ok(guide.answer.includes('25 lines') && guide.answer.includes('0 No') && guide.answer.includes('4 Proven'), 'scorecard guide matches the 25 manual 0–4 lines');
ok(guide.answer.includes('80–100 Strong') && guide.answer.includes('0–39 Critical'), 'scorecard guide includes the actual priority bands');
ok(guide.links.some((link) => link[1] === '/audit-scorecard'), 'scorecard guide links to the actual scorecard page');

const gap = answerFor('What is the free PDPA gap check?');
ok(gap.links.some((link) => link[1] === '/#pdpa'), 'gap answer links to the homepage PDPA section');
const audit = answerFor('What is the free IT audit?');
ok(audit.answer.includes('infrastructure') && audit.answer.includes('backups'), 'audit answer reflects the published audit scope');
ok(answerFor('something unrelated').links[0][1] === '/#audit', 'unknown questions receive the audit fallback');

ok(source.includes('if (!global || !global.document) return;'), 'browser DOM work is guarded for Node');
ok(source.includes('MAX_MESSAGES = 24') && source.includes('MAX_QUESTION_LENGTH = 240'), 'message history and question length are bounded');
ok(source.includes("event.key === 'Escape'") && source.includes('focusOpener'), 'Escape closes and returns focus');
ok(source.includes("event.key === 'Tab'") && source.includes('focusableSelector'), 'dialog traps keyboard focus');
ok(source.includes('textContent') && !source.includes('innerHTML'), 'rendering uses safe textContent only');
ok(source.includes('data-ask-language-option') && source.includes('setLanguage'), 'language must be selected before the question UI is enabled');
ok(source.includes("if (!selectedLanguage) return"), 'questions are blocked until a language is selected');
ok(source.includes('bmAnswers') && source.includes("selectedLanguage !== 'bm'"), 'Bahasa Malaysia answers are available');
ok(homepage.includes('data-ask-language-option="en"') && homepage.includes('data-ask-language-option="bm"'), 'homepage renders the two language choices');
ok(homepage.includes('data-ask-content hidden'), 'question interface starts hidden behind language selection');
ok(!source.includes('fetch(') && !source.includes('localStorage') && !source.includes('sessionStorage'), 'helper uses no network or browser storage');

console.log('\nALL PASS — Ask AI contract');
