#!/usr/bin/env python3
"""Batch-apply BM (Bahasa Malaysia) strings to index.html.

For every spec it finds the element by tag + normalised text prefix, asserts
how many matched, then either
  * inserts  data-i18n="key"                 (mode='attr')
  * inserts  data-i18n="key" data-i18n-attr  (mode='aria')
  * wraps the element's bare text node in <span data-i18n="key"> (mode='wrap')
and finally rewrites the inline `var BM = { ... }` dict from the same spec.

Spec: (key, tag, en_prefix, bm, mode)
  mode: 'attr' | 'aria' | 'wrap' | 'skip'   ('skip' = key already in BM dict,
        used to carry over strings that need no HTML change)

  --dry   report matches only, touch nothing
"""
import re, sys, json, os, shutil
from html.parser import HTMLParser

def _site_file(name):
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, '..', 'public', name),          # current repo layout
                 os.path.join(here, '..', name),                    # tools/ inside site root
                 os.path.join(here, '..', 'dutaintegra-homepage', name)):  # tools/ beside site dir
        if os.path.isfile(cand):
            return os.path.normpath(cand)
    return os.path.normpath(os.path.join(here, '..', 'public', name))

PATH = _site_file('index.html')
DRY = '--dry' in sys.argv
ONLY = [a for a in sys.argv[1:] if not a.startswith('--')]

# --------------------------------------------------------------------------
# Batch A — header, hero, calculator, trust strip (existing 18 keys carried
# over verbatim so regenerating the dict does not lose them).
# --------------------------------------------------------------------------
SPECS = [
    # --- already in the file: keys kept, BM text kept as written -----------
    ('ann', 'span', 'Free IT audit.', '<b>Audit IT percuma.</b> Sebut harga tetap dalam 3 hari bekerja. Bulan-ke-bulan — tiada ikatan kontrak.', 'attr'),
    ('annLink', 'a', 'Start here', 'Mula di sini', 'attr'),
    ('navServices', 'a', 'Services', 'Perkhidmatan', 'attr'),
    ('navChecklist', 'a', 'Free checklist', 'Senarai semak percuma', 'attr'),
    ('navPricing', 'a', 'Pricing', 'Harga', 'attr'),
    ('navWhy', 'a', 'Why us', 'Kenapa kami', 'attr'),
    ('navFaq', 'a', 'FAQ', 'Soalan Lazim', 'attr'),
    ('navCta', 'a', 'Free IT audit', 'Audit IT percuma', 'attr'),
    ('pill', 'span', 'AI + managed IT for Malaysian SMEs', 'AI + IT terurus untuk PKS Malaysia · Cyberjaya', 'attr'),
    ('h1a', 'span', 'Your IT, fully managed.', 'IT anda, terurus sepenuhnya.', 'attr'),
    ('h1b', 'span', 'Your busywork, automated.', 'Kerja berulang, diautomasikan.', 'attr'),
    ('sub', 'p', 'One team for your infrastructure', 'Satu pasukan untuk infrastruktur, keselamatan dan automasi anda — supaya anda berhenti menjadi helpdesk sendiri dan berhenti membayar orang untuk melakukan kerja yang sepatutnya ditangani perisian. <b>Dari RM 799 sebulan, bulan-ke-bulan.</b>', 'attr'),
    ('ctaMain', 'span', 'Book my free IT audit', 'Tempah audit IT percuma', 'attr'),
    ('ctaWa', 'span', 'WhatsApp us now', 'WhatsApp kami sekarang', 'attr'),
    ('note', 'p', 'No obligation. No sales pressure.', 'Tiada paksaan. Tiada tekanan jualan. Kami balas dalam satu hari bekerja.', 'attr'),
    ('a1', 'span', 'Fixed-price proposal in 3 working days', 'Sebut harga tetap dalam 3 hari bekerja — atau kami beritahu mengapa tidak', 'attr'),
    ('a2', 'span', 'Cancel any month. No lock-in contracts', 'Batal bila-bila masa. Tiada kontrak panjang, tiada caj penamatan', 'attr'),
    ('a3', 'span', "If the audit finds nothing worth fixing", 'Jika audit mendapati tiada masalah besar untuk dibetulkan, kami akan kata begitu', 'attr'),
    ('calcForm', 'span', 'Or request the free audit instead', 'Atau mohon audit IT percuma', 'attr'),

    # --- new: skip link / aria ---------------------------------------------
    ('skipLink', 'a', 'Skip to content', 'Langkau ke kandungan', 'attr'),
    ('ariaMain', 'nav', 'Main', 'Menu utama', 'attr:aria-label'),
    ('ariaLang', 'div', 'Language', 'Bahasa', 'attr:aria-label'),
    ('ariaBurger', 'button', 'Open menu', 'Buka menu', 'attr:aria-label'),

    # --- new: hero free-checklist card -------------------------------------
    ('ffTag', 'span', 'Free · No signup', 'Percuma · Tiada pendaftaran', 'attr'),
    ('ffH', 'span', 'Is your privacy notice actually compliant?', 'Adakah notis privasi anda benar-benar mematuhi undang-undang?', 'attr'),
    ('ffP', 'span', 'Section 7(3) of the PDPA requires it in', 'Perkara 7(3) PDPA memerlukannya dalam <strong>Bahasa Malaysia dan Inggeris</strong>. Kebanyakan notis privasi PKS Malaysia hanya dalam bahasa Inggeris. Semak notis anda dalam lima minit dengan senarai semak percuma kami.', 'attr'),
    ('ffL', 'span', 'Open the free PDPA checklist', 'Buka senarai semak PDPA percuma', 'wrap'),

    # --- new: calculator ----------------------------------------------------
    ('live', 'span', 'Live estimate', 'Anggaran langsung', 'wrap'),
    ('calcH2', 'h2', 'What is manual work costing you?', 'Apakah kos kerja manual bagi anda?', 'attr'),
    ('calcSub', 'p', 'Most SMEs we audit are losing', 'Kebanyakan PKS yang kami audit kehilangan 20–30% jam pentadbiran kepada kerja yang boleh dilakukan perisian. Gerakkan penunjuk untuk melihat angka anda.', 'attr'),
    ('lblStaff', 'label', 'Staff doing repetitive admin', 'Kakitangan yang buat kerja pentadbiran berulang', 'wrap'),
    ('lblHours', 'label', 'Hours each loses per week', 'Jam seorang hilang setiap minggu', 'wrap'),
    ('lblSalary', 'label', 'Average monthly salary', 'Gaji bulanan purata', 'wrap'),
    ('calcK', 'div', 'Cost of repetitive work, per year', 'Kos kerja berulang, setahun', 'attr'),
    ('splitL1', 'div', 'Realistically recoverable per month', 'Benar-benar boleh dipulihkan sebulan (60% daripada jumlah jam)', 'attr'),
    ('splitL2', 'div', 'Managed IT, all-in', 'IT terurus, semua termasuk — kurang daripada yang anda boleh pulihkan', 'attr'),
    ('perMo', 'span', '/mo', '/bulan', 'attr'),
    ('waCalcBtn', 'a', 'Send me this breakdown on WhatsApp', 'Hantar pecahan ini kepada kami di WhatsApp', 'wrap'),
    ('calcFoot', 'p', 'Estimate only. Assumes 173 working hours', 'Anggaran sahaja. Andaian 173 jam bekerja seorang sebulan dan kira-kira 60% daripada jam berulang boleh diautomasikan. Audit percuma menggantikan ini dengan angka sebenar anda — dan memberitahu anda jika jawapannya ialah "jangan diautomasikan dulu".', 'attr'),

    # --- new: trust strip ---------------------------------------------------
    ('trust1', 'li', '100% Malaysian-owned', '100% milik Malaysia · Cyberjaya', 'wrap'),
    ('trust2', 'li', 'Month-to-month, no lock-in', 'Bulan-ke-bulan, tiada ikatan kontrak', 'wrap'),
    ('trust3', 'li', 'Support Mon', 'Sokongan Isnin–Jumaat, 9 pagi–6 petang MYT', 'wrap'),
    ('trust4', 'li', 'PDPA-aware by default', 'Prihatin PDPA secara lalai', 'wrap'),
    ('trust5', 'li', 'Fixed price, quoted up front', 'Harga tetap, dinyatakan sebelum mula', 'wrap'),

    # --- pre-edited in HTML (wrapped by hand): key must still reach the dict
    ('perMonth', 'span', 'per month', 'sebulan', 'attr'),
    ('perHours', 'span', 'hours lost monthly', 'jam hilang sebulan', 'attr'),
    ('biDash', 'span', 'Business Intelligence dashboards', 'Papan pemuka Business Intelligence', 'attr'),
    ('rights', 'span', 'Duta Integra Solutions. All rights reserved.', 'Duta Integra Solutions. Hak cipta terpelihara.', 'attr'),
    ('owned', 'span', '100% Malaysian-owned', '100% milik Malaysia', 'attr'),

    # ======================================================================
    # Batch B — SERVICES
    # ======================================================================
    ('svcEyebrow', 'p', 'What we do', 'Apa yang kami lakukan', 'attr'),
    ('svcH2', 'h2', 'Two pillars. One team to blame.', 'Dua tonggak. Satu pasukan yang bertanggungjawab.', 'attr'),
    ('svcLede', 'p', 'Most SMEs juggle an IT guy',
     'Kebanyakan PKS bergelut dengan seorang pekerja IT, satu agensi web, dan seorang "perunding awan" yang tidak pernah menjawab. '
     'Kami meliputi keseluruhan timbunan — infrastruktur dan automasi anda — di bawah satu bumbung yang bertanggungjawab. '
     'Setiap harga di bawah ialah titik permulaan sebenar, bukan "minta sebut harga".', 'attr'),

    ('svc1T', 'h3', 'Managed IT Services', 'Perkhidmatan IT Terurus', 'attr'),
    ('svc1D', 'p', 'We take ownership of your infrastructure',
     'Kami mengambil alih infrastruktur anda supaya anda berhenti menjadi jabatan IT secara tidak sengaja.', 'attr'),
    ('svc1b1', 'li', 'Helpdesk for your team', 'Helpdesk untuk pasukan anda, jarak jauh dahulu', 'wrap'),
    ('svc1b2', 'li', 'Monitoring, backups & patching', 'Monitoring, sandaran &amp; patching', 'wrap'),
    ('svc1b3', 'li', 'Monthly health report', 'Laporan kesihatan bulanan yang anda benar-benar boleh baca', 'wrap'),
    ('svc1Month', 'small', 'per month', 'sebulan', 'attr'),

    ('svc2T', 'h3', 'AI Software & Automation', 'Perisian &amp; Automasi AI', 'attr'),
    ('svc2D', 'p', 'We automate the specific tasks',
     'Kami automatikkan tugas khusus yang pasukan anda ulang setiap minggu — bukan satu "strategi AI" yang kabur.', 'attr'),
    ('svc2b1', 'li', 'Chatbots on your site or WhatsApp', 'Chatbot di laman anda atau WhatsApp, dilatih pada data anda', 'wrap'),
    ('svc2b2', 'li', 'Approvals, invoicing & data entry', 'Aliran kerja kelulusan, invois &amp; kemasukan data', 'wrap'),
    ('svc2b3', 'li', 'AI wired into the tools', 'AI disambungkan ke alat yang sudah anda guna', 'wrap'),
    ('svcFromProj', 'small', 'from, per project', 'bermula, setiap projek', 'attr'),

    ('svc3T', 'h3', 'Cloud Migration', 'Migrasi Awan', 'attr'),
    ('svc3D', 'p', 'Move to AWS, Azure or Google Cloud',
     'Pindah ke AWS, Azure atau Google Cloud tanpa seminggu gangguan atau bil yang mengejutkan.', 'attr'),
    ('svc3b1', 'li', 'Readiness assessment', 'Penilaian kesediaan &amp; pelan migrasi', 'wrap'),
    ('svc3b2', 'li', 'Cutover scheduled outside', 'Peralihan dijadualkan di luar waktu perniagaan anda', 'wrap'),
    ('svc3b3', 'li', 'Cost optimisation after', 'Pengoptimuman kos selepas anda berpindah', 'wrap'),

    ('svc4T', 'h3', 'Security & PDPA Compliance', 'Keselamatan &amp; Pematuhan PDPA', 'attr'),
    ('svc4D', 'p', 'Know what personal data you hold',
     'Tahukan data peribadi yang anda simpan, di mana ia disimpan, dan apa yang perlu dilakukan apabila sesuatu berlaku.', 'attr'),
    ('svc4b1', 'li', 'Free gap check: where you stand', 'Semakan jurang percuma: kedudukan anda hari ini', 'wrap'),
    ('svc4b2', 'li', 'Privacy notice in BM and English, consent wording', 'Notis privasi dalam BM dan Inggeris, perkataan persetujuan', 'wrap'),
    ('svc4b3', 'li', 'Breach response plan and data inventory', 'Pelan tindak balas pelanggaran dan inventori data', 'wrap'),
    ('svc4Fixed', 'small', 'fixed, Starter Pack', 'harga tetap, Starter Pack', 'attr'),
    ('svc4Scope', 'span', 'Free check first · no retainer', 'Semakan percuma dahulu · tiada retainer', 'attr'),
    ('biSoon', 'span', 'Launching next', 'Akan dilancarkan', 'attr'),
    ('biTell', 'a', 'Tell me when it', 'Beri tahu saya apabila ia sedia', 'attr'),

    # ======================================================================
    # Batch B — PRICING
    # ======================================================================
    ('prEyebrow', 'p', 'Pricing', 'Harga', 'attr'),
    ('prH2', 'h2', 'The price is on the page.', 'Harga ada di halaman ini. Itu memang sengaja.', 'attr'),
    ('prLede', 'p', '"Contact us for pricing" wastes your time and ours',
     '"Hubungi kami untuk harga" membazir masa anda dan kami. Berikut kos IT terurus, dan kos sesebuah projek untuk bermula. '
     'Sebut harga tepat anda diberikan secara bertulis dalam 3 hari bekerja.', 'attr'),

    ('pr1T', 'h3', 'Starter', 'Pemula', 'attr'),
    ('pr1Who', 'p', 'Small teams getting IT properly handled',
     'Pasukan kecil yang mula mengurus IT dengan betul buat kali pertama.', 'attr'),
    ('pr2T', 'h3', 'Business', 'Perniagaan', 'attr'),
    ('pr2Who', 'p', 'Growing SMEs that can',
     'PKS yang berkembang dan tidak mampu kehilangan sehari akibat downtime.', 'attr'),
    ('pr3T', 'h3', 'Enterprise', 'Korporat', 'attr'),
    ('pr3Who', 'p', 'Larger or multi-branch operations',
     'Operasi besar atau berbilang cawangan dengan keperluan pematuhan yang serius.', 'attr'),
    ('prTag', 'span', 'Recommended', 'Disyorkan', 'attr'),
    ('prMonth', 'small', '/month', '/bulan', 'attr'),
    ('prCustom', 'div', 'Custom', 'Tersuai', 'attr'),

    ('pr1b1', 'li', 'Up to 5 users supported', 'Sehingga 5 pengguna disokong', 'wrap'),
    ('pr1b2', 'li', 'Remote helpdesk, business hours', 'Helpdesk jarak jauh, waktu perniagaan', 'wrap'),
    ('pr1b3', 'li', 'Monthly system health check', 'Semakan kesihatan sistem bulanan', 'wrap'),
    ('pr1b4', 'li', 'Antivirus & endpoint protection', 'Perlindungan antivirus &amp; endpoint', 'wrap'),
    ('pr1b5', 'li', 'Email & network monitoring', 'Monitoring emel &amp; rangkaian', 'wrap'),
    ('pr1b6', 'li', '24/7 monitoring & dedicated manager', 'Monitoring 24/7 &amp; pengurus khusus', 'wrap'),
    ('pr2b1', 'li', 'Up to 20 users supported', 'Sehingga 20 pengguna disokong', 'wrap'),
    ('pr2b2', 'li', 'Remote helpdesk, extended hours', 'Helpdesk jarak jauh, waktu lanjutan', 'wrap'),
    ('pr2b3', 'li', '24/7 monitoring & alerts', 'Monitoring &amp; amaran 24/7', 'wrap'),
    ('pr2b4', 'li', 'Cloud backup & disaster recovery', 'Sandaran awan &amp; pemulihan bencana', 'wrap'),
    ('pr2b5', 'li', 'Monthly performance reports', 'Laporan prestasi bulanan', 'wrap'),
    ('pr2b6', 'li', 'Dedicated account manager', 'Pengurus akaun khusus &amp; sokongan PDPA', 'wrap'),
    ('pr3b1', 'li', 'Unlimited users', 'Pengguna tanpa had', 'wrap'),
    ('pr3b2', 'li', '24/7 helpdesk & on-site support', 'Helpdesk 24/7 &amp; sokongan di lokasi', 'wrap'),
    ('pr3b3', 'li', 'Full network & server management', 'Pengurusan rangkaian &amp; pelayan penuh', 'wrap'),
    ('pr3b4', 'li', 'PDPA & compliance full audit', 'Audit penuh PDPA &amp; pematuhan', 'wrap'),
    ('pr3b5', 'li', 'Custom SLA & priority response', 'SLA tersuai &amp; respons keutamaan', 'wrap'),
    ('pr3b6', 'li', 'Quarterly business IT reviews', 'Semakan IT perniagaan setiap suku tahun', 'wrap'),
    ('prBtn', 'a', 'Start with a free audit', 'Mula dengan audit percuma', 'attr'),
    ('pr3Btn', 'a', 'Request a scoped quote', 'Minta sebut harga dengan skop', 'attr'),
    ('prNote', 'p', 'Every plan includes the free initial IT audit',
     'Setiap pelan merangkumi audit IT awal percuma. Kontrak bulan-ke-bulan — batal bila-bila masa.', 'attr'),

    ('pjN1', 'div', 'AI Chatbot', 'Chatbot AI', 'attr'),
    ('pjP1', 'div', 'From RM 3,500', 'Dari RM 3,500', 'attr'),
    ('pjT1', 'div', 'Trained on your data', 'Dilatih pada data anda, untuk laman, WhatsApp atau kegunaan dalaman.', 'attr'),
    ('pjN2', 'div', 'Process Automation', 'Automasi Proses', 'attr'),
    ('pjP2', 'div', 'From RM 5,000', 'Dari RM 5,000', 'attr'),
    ('pjT2', 'div', 'Data entry, approvals, reporting', 'Kemasukan data, kelulusan, pelaporan — rutin mingguan, dibuang.', 'attr'),
    ('pjN3', 'div', 'ML Model', 'Model ML', 'attr'),
    ('pjP3', 'div', 'From RM 8,000', 'Dari RM 8,000', 'attr'),
    ('pjT3', 'div', 'Prediction, classification or recommendation', 'Ramalan, klasifikasi atau syor dibina atas data anda sendiri.', 'attr'),
    ('pjN4', 'div', 'AI Integration', 'Integrasi AI', 'attr'),
    ('pjP4', 'div', 'From RM 2,500', 'Dari RM 2,500', 'attr'),
    ('pjT4', 'div', 'Wire AI into the systems', 'Sambungkan AI ke sistem yang sudah anda jalankan. Titik permulaan biasa.', 'attr'),
    ('pjN5', 'div', 'Cloud Migration', 'Migrasi Awan', 'attr'),
    ('pjP5', 'div', 'From RM 4,000', 'Dari RM 4,000', 'attr'),
    ('pjT5', 'div', 'Planning, execution and post-migration', 'Perancangan, pelaksanaan dan sokongan selepas migrasi termasuk.', 'attr'),
    ('pjN6', 'div', 'PDPA Gap Check', 'Semakan Jurang PDPA', 'attr'),
    ('pjP6', 'div', 'Free', 'Percuma', 'attr', True),
    ('pjT6', 'div', 'Where your privacy notice and consent capture fall short',
     'Di mana notis privasi dan tangkapan persetujuan anda kurang — ringkasan bertulis, tanpa caj.', 'attr'),
    ('prCta', 'a', 'Get my exact price', 'Dapatkan harga tepat saya', 'wrap'),

    # ======================================================================
    # Batch C — WHY US
    # ======================================================================
    ('whyEyebrow', 'p', 'Why us', 'Kenapa kami', 'attr'),
    ('whyH2', 'h2', 'Four promises you can hold us to.', 'Empat janji yang boleh anda tuntut daripada kami.', 'attr'),
    ('whyLede', 'p', "We're building this on trust we can earn",
     'Kami membina ini atas kepercayaan yang boleh kami peroleh, bukan logo yang boleh kami pinjam. '
     'Anda mungkin pernah terpaksa berdepan perkara ini sebelum ini: kontrak panjang, invois yang tidak pernah dijelaskan, '
     'pembekal yang hilang selepas lancar. Jadi berikut empat komitmen sebaliknya — setiap satu sesuatu yang boleh anda semak.', 'attr'),
    ('g1h', 'h3', 'A real price, in writing, in 3 working days', 'Harga sebenar, secara bertulis, dalam 3 hari bekerja', 'attr'),
    ('g1p', 'p', 'You get a fixed scope and a fixed figure.',
     'Anda mendapat skop tetap dan angka tetap. Jika kami tidak dapat mengekalkan harga, kami beritahu sebelum mula — bukan pada invois.', 'attr'),
    ('g2h', 'h3', 'Month-to-month. Cancel any month.', 'Bulan-ke-bulan. Batal bila-bila masa.', 'attr'),
    ('g2p', 'p', 'No lock-in, no notice period traps, no exit fees.',
     'Tiada ikatan, tiada perangkap tempoh notis, tiada caj keluar. Kami mengekalkan perniagaan anda dengan menjadi berguna, '
     'bukan dengan membuat anda sukar keluar.', 'attr'),
    ('g3h', 'h3', "We'll tell you if you don't need us", 'Kami akan beritahu jika anda tidak perlukan kami', 'attr'),
    ('g3p', 'p', 'If the audit shows your setup is sound',
     'Jika audit menunjukkan susun atur anda baik, anda akan menerimanya secara bertulis beserta senarai semak untuk mengekalkannya. '
     'Kami lebih suka dipercayai daripada dibayar sekali.', 'attr'),
    ('g4h', 'h3', 'The person who scoped it is there when it ships', 'Orang yang menyusun skop turut ada semasa ia dilancarkan', 'attr'),
    ('g4p', 'p', 'Cyberjaya-based, Malaysian-owned, support 9am',
     'Berasas di Cyberjaya, milik Malaysia, sokongan 9 pagi–6 petang MYT. Tiada antrean luar negara, '
     'tiada pengurus akaun yang tidak pernah melihat rangkaian anda.', 'attr'),
    ('fQuote', 'blockquote', '"I spent years watching capable Malaysian businesses',
     '"Saya bertahun-tahun memerhatikan perniagaan Malaysia yang berkeupayaan kehilangan masa dan wang kerana teknologi '
     'yang dipilih untuk mereka dan bukan bersama mereka. Jadi kami membina rakan kongsi yang kami harapkan wujud — '
     'yang menerangkan pertimbangan, memadankan skala penyelesaian, dan kekal bertanggungjawab selepas lancar."', 'attr'),
    ('fAttrib', 'p', 'Shamel', '<b>Shamel</b> — Pengasas &amp; CEO, Duta Integra Solutions', 'attr'),

    # ======================================================================
    # Batch C — PROCESS
    # ======================================================================
    ('prcEyebrow', 'p', 'How it works', 'Bagaimana ia berfungsi', 'attr'),
    ('prcH2', 'h2', 'Four steps, and you can stop after step two.', 'Empat langkah, dan anda boleh berhenti selepas langkah kedua.', 'attr'),
    ('prcLede', 'p', 'The first two steps are free and non-committal.',
     'Dua langkah pertama percuma dan tanpa komitmen. Ramai perniagaan mengambil audit dan sebut harga, '
     'kemudian memutuskan untuk menunggu satu suku tahun. Itu hasil yang baik.', 'attr'),
    ('st1h', 'h3', 'Free audit', 'Audit percuma', 'attr'),
    ('st1p', 'p', 'We look at your setup or your workflows',
     'Kami melihat susun atur atau aliran kerja anda dan memberitahu apa yang perlu dibetulkan dahulu, '
     'serta anggaran kasarnya. Tiada paksaan.', 'attr'),
    ('st1w', 'div', 'Within a few days of first contact', 'Dalam beberapa hari selepas hubungan pertama', 'attr'),
    ('st2h', 'h3', 'Fixed-price proposal', 'Sebut harga tetap', 'attr'),
    ('st2p', 'p', 'Scope, timeline and price in writing.',
     'Skop, garis masa dan harga secara bertulis. Anda juga akan tahu apa yang kami sengaja biarkan buat masa ini.', 'attr'),
    ('st2w', 'div', '3 working days', '3 hari bekerja', 'attr'),
    ('st3h', 'h3', 'Delivery', 'Penyampaian', 'attr'),
    ('st3p', 'p', 'We execute with weekly check-ins',
     'Kami laksanakan dengan semakan mingguan, kerja yang menghormati waktu perniagaan anda, dan tiada jargon dalam kemas kini.', 'attr'),
    ('st3w', 'div', 'Weekly check-ins', 'Semakan mingguan', 'attr'),
    ('st4h', 'h3', 'Support that stays', 'Sokongan yang kekal', 'attr'),
    ('st4p', 'p', 'Ongoing monitoring, helpdesk and reporting.',
     'Monitoring berterusan, helpdesk dan pelaporan. Jika sesuatu yang kami bina berhenti berfungsi, '
     'membaikinya adalah tugas kami — bukan penemuan anda.', 'attr'),
    ('st4w', 'div', 'Month-to-month, cancel anytime', 'Bulan-ke-bulan, bila-bila masa', 'attr'),

    # ======================================================================
    # Batch C — PDPA
    # ======================================================================
    ('pdEyebrow', 'p', "Malaysia's rules changed", 'Peraturan Malaysia telah berubah', 'attr'),
    ('pdH2', 'h2', 'Your privacy notice is probably out of date.', 'Notis privasi anda mungkin sudah lapuk.', 'attr'),
    ('pdLede1', 'p', 'Since 1 June 2025 the amended PDPA has required',
     'Sejak 1 Jun 2025, PDPA pindaan telah memerlukan notis pelanggaran dalam 72 jam, seorang Pegawai Perlindungan Data '
     'untuk organisasi yang layak, dan keterpindahan data. Manakala Perkara 7(3) sejak dahulu lagi memerlukan notis privasi anda '
     'dalam <strong>Bahasa Malaysia <em>dan</em> Inggeris</strong> — itulah jurang yang paling kerap kami jumpai.', 'attr'),
    ('pdLede2', 'p', 'Most SMEs we check are missing two or three specific things.',
     'Kebanyakan PKS yang kami semak ketinggalan dua atau tiga perkara khusus. Membaikinya mengambil hari, bukan bulan — '
     'dan ia perkara pertama yang pelanggan besar akan tanya sebelum mereka menandatangani.', 'attr'),
    ('pdBtn1', 'a', 'See the free checklist', 'Lihat senarai semak percuma', 'wrap'),
    ('pdBtn2', 'a', 'Ask us to check it', 'Minta kami semaknya', 'attr'),
    ('pdPackP', 'p', 'Everything you need, delivered in two weeks',
     'Semua yang anda perlukan, disampaikan dalam dua minggu pada harga tetap.', 'attr'),
    ('pdB1', 'span', 'Privacy notice in BM and English', 'Notis privasi dalam BM <em>dan</em> Inggeris', 'attr', True),
    ('pdB2', 'li', 'Consent wording you can actually evidence', 'Perkataan persetujuan yang benar-benar boleh dibuktikan', 'wrap'),
    ('pdB3', 'li', 'Data inventory and retention schedule', 'Inventori data dan jadual pengekalan', 'wrap'),
    ('pdB4', 'li', 'Breach response plan for the 72-hour clock', 'Pelan tindak balas pelanggaran untuk jam 72 jam', 'wrap'),
    ('pdB5', 'li', 'Staff one-pager and DPO pack', 'Satu muka surat kakitangan dan pakej DPO jika perlu', 'wrap'),
    ('pdFrom', 'span', 'From RM 1,800', 'Dari RM 1,800', 'wrap'),
    ('pdFromNote', 'small', 'fixed price', 'harga tetap', 'attr'),
    ('pdScope', 'span', 'No retainer. No lock-in.', 'Tiada retainer. Tiada ikatan kontrak.', 'attr'),
    ('pdBtn3', 'a', 'Start with the free gap check', 'Mula dengan semakan jurang percuma', 'attr'),
    ('pdFine', 'p', '30 minutes, no charge.',
     '30 minit, tanpa caj. Anda akan menerima ringkasan bertulis tentang jurang yang ada — '
     'dan jika anda sudah dalam keadaan baik, kami akan beritahu anda begitu.', 'attr'),

    # ======================================================================
    # Batch D — FAQ
    # ======================================================================
    ('faqEyebrow', 'p', 'Straight answers', 'Jawapan yang terus', 'attr'),
    ('faqH2', 'h2', "The questions you'd ask on the call", 'Soalan yang anda akan tanya semasa panggilan', 'attr'),
    ('faqLede', 'p', 'Including the awkward ones about price',
     'Termasuk soalan yang janggal tentang harga, gangguan, dan sama ada AI benar-benar relevan untuk anda lagi.', 'attr'),

    ('faqQ1', 'summary', 'How much does this actually cost?', 'Berapa kosnya yang sebenar?', 'wrap'),
    ('faqA1a', 'p', 'Managed IT starts at',
     'IT terurus bermula pada <b>RM 799/sebulan</b> untuk sehingga 5 pengguna dan <b>RM 1,899/sebulan</b> untuk sehingga 20. '
     'Projek bermula pada RM 2,500 (integrasi AI), RM 4,000 (migrasi awan), RM 5,000 (automasi proses) '
     'dan RM 1,800 tetap untuk PDPA Starter Pack. Semakan jurang PDPA adalah percuma.', 'attr'),
    ('faqA1b', 'p', 'Your exact figure comes in the written proposal',
     'Angka tepat anda datang dalam sebut harga bertulis — tetap, dengan skop dinyatakan. '
     'Jika kerja ternyata lebih kecil daripada yang kami sangka, invois juga lebih kecil.', 'attr'),
    ('faqQ2', 'summary', 'Am I signing into a long contract?', 'Adakah saya menandatangani kontrak panjang?', 'wrap'),
    ('faqA2', 'p', 'No. Retainers are month-to-month',
     'Tidak. Retainer adalah bulan-ke-bulan dan anda boleh berhenti bila-bila masa. '
     'Kerja projek dikenakan harga setiap penglibatan dengan skop tetap, jadi tiada komitmen berterusan selepas penyampaian.', 'attr'),
    ('faqQ3', 'summary', 'We already have an internal IT person.', 'Kami sudah ada orang IT dalaman.', 'wrap'),
    ('faqA3a', 'p', 'Keep them',
     'Kekalkan mereka — biasanya merekalah yang paling kenal perniagaan anda. Kami biasanya mengambil alih bahagian '
     'yang memakan minggu mereka: monitoring, patching, sandaran, keselamatan dan mengejar pembekal, '
     'serta menjadi lapisan eskalasi mereka apabila sesuatu melebihi satu pasangan tangan.', 'attr'),
    ('faqA3b', 'p', 'The result is normally',
     'Hasilnya biasanya orang IT dalaman anda dapat bekerja pada projek dan bukan pada tiket.', 'attr'),
    ('faqQ4', 'summary', 'Will migration or new systems disrupt our daily work?',
     'Adakah migrasi atau sistem baharu mengganggu kerja harian kami?', 'wrap'),
    ('faqA4', 'p', "That's what the plan is for",
     'Itulah tujuannya pelan. Peralihan dijadualkan di luar waktu perniagaan anda, kami bersetuju dengan kedudukan rollback '
     'sebelum menyentuh apa-apa, dan anda mendapat semakan mingguan semasa penyampaian supaya tiada kejutan pada Isnin pagi.', 'attr'),
    ('faqQ5', 'summary', 'How do you handle our data, and PDPA?', 'Bagaimana anda kendalikan data kami, dan PDPA?', 'wrap'),
    ('faqA5a', 'p', "PDPA compliance isn't a side service",
     'Pematuhan PDPA bukan perkhidmatan sampingan bagi kami — ia salah satu daripada empat penawaran kami, dan kami '
     'memegang diri kami padanya. Secara praktikal: kami bekerja dalam akaun dan sistem yang anda miliki, kami ambil '
     'akses minimum yang diperlukan untuk melakukan kerja, dan kami mendokumen apa yang kami sentuh.', 'attr'),
    ('faqA5b', 'p', 'If you want the full picture',
     'Jika anda mahu gambaran penuh, semakan jurang percuma menunjukkan di mana notis privasi dan tangkapan persetujuan anda '
     'kurang — dan Starter Pack dari RM 1,800 membaikinya, termasuk notis dalam Bahasa Malaysia dan Inggeris.', 'attr'),
    ('faqQ6', 'summary', "We're curious about AI, but I don't think we're ready.",
     'Kami berminat dengan AI, tetapi fikir kami belum bersedia.', 'wrap'),
    ('faqA6a', 'p', "You don't need an AI strategy",
     'Anda tidak perlukan strategi AI untuk bermula, dan "belum lagi" ialah jawapan yang sah. '
     'Kebanyakan pelanggan bermula dengan audit IT atau satu automasi khusus — aliran kerja invois, '
     'chatbot pertanyaan pelanggan, atau kerja pelaporan yang seseorang buat setiap Jumaat.', 'attr'),
    ('faqA6b', 'p', 'If we think AI is the wrong tool',
     'Jika kami fikir AI adalah alat yang salah untuk masalah anda, kami akan kata begitu dan mencadangkan pembaikan biasa sebaliknya.', 'attr'),
    ('faqQ7', 'summary', 'What happens after I submit the form?', 'Apa yang berlaku selepas saya hantar borang?', 'wrap'),
    ('faqA7a', 'p', 'You get a reply within one business day',
     'Anda mendapat balasan dalam satu hari bekerja, daripada seorang manusia, dalam bahasa mudah. '
     'Kami akan bertanya beberapa soalan untuk memahami susun atur anda, kemudian menempah panggilan pendek '
     'atau kembali dengan skop audit.', 'attr'),
    ('faqA7b', 'p', "If we're not the right fit",
     'Jika kami bukan yang tepat, kami akan beritahu awal daripada membazir masa anda.', 'attr'),

    # ======================================================================
    # Batch D — CTA BAND
    # ======================================================================
    ('bandH2', 'h2', 'Two ways to start. Both free.', 'Dua cara untuk bermula. Kedua-duanya percuma.', 'attr'),
    ('bandP', 'p', 'WhatsApp gets you a reply fastest',
     'WhatsApp memberi anda balasan paling pantas dan tidak memerlukan apa-apa selain satu mesej. '
     'Atau hantar borang di bawah dan kami akan kembali dalam satu hari bekerja dengan jawapan yang terus.', 'attr'),
    ('bandBtn', 'a', 'Send the form instead', 'Hantar borang sebaliknya', 'wrap'),

    # ======================================================================
    # Batch D — CONTACT / LEAD FORM
    # ======================================================================
    ('auEyebrow', 'p', 'Free IT audit', 'Audit IT percuma', 'attr'),
    ('auH2', 'h2', "Tell us what's actually going wrong.", 'Beritahu kami apa yang sebenarnya sedang salah.', 'attr'),
    ('auLede', 'p', 'Six fields, one business day to a reply.',
     'Enam medan, satu hari bekerja untuk balasan. Anda akan mendapat bacaan jujur tentang apa yang perlu '
     'dibetulkan dahulu — dan apa yang perlu dibiarkan.', 'attr'),
    ('lblName', 'label', 'Your name', 'Nama anda', 'wrap'),
    ('lblCompany', 'label', 'Company', 'Syarikat', 'attr'),
    ('lblEmail', 'label', 'Work email', 'Emel pekerjaan', 'wrap'),
    ('lblPhone', 'label', 'WhatsApp number', 'Nombor WhatsApp', 'attr'),
    ('lblService', 'label', 'What do you need most right now?', 'Apakah yang anda paling perlukan sekarang?', 'wrap'),
    ('lblMsg', 'label', "What's the problem you're trying to solve?",
     'Apakah masalah yang anda cuba selesaikan?', 'wrap'),
    ('phCompany', 'input', 'Syarikat Sdn Bhd / Enterprise', 'Syarikat Sdn Bhd / Perusahaan', 'attr:placeholder'),
    ('phMsg', 'textarea',
     'e.g. Our server drops out a few times a month and nobody knows why. Also three staff spend most of Friday compiling reports by hand.',
     'contoh: Pelayan kami terputus beberapa kali sebulan dan tiada siapa tahu mengapa. Tiga kakitangan pula '
     'menghabiskan sebahagian besar hari Jumaat mengumpul laporan secara manual.', 'attr:placeholder'),
    ('optPlease', 'option', 'Please choose…', 'Sila pilih…', 'attr'),
    ('optManaged', 'option', 'Managed IT — we need ongoing support', 'IT terurus — kami perlukan sokongan berterusan', 'attr'),
    ('optAi', 'option', 'AI / automation — we want to stop manual work', 'AI / automasi — kami mahu menghentikan kerja manual', 'attr'),
    ('optCloud', 'option', 'Cloud migration', 'Migrasi awan', 'attr'),
    ('optPdpa', 'option', 'PDPA compliance or security audit', 'Pematuhan PDPA atau audit keselamatan', 'attr'),
    ('optUnsure', 'option', 'Not sure — help me work it out', 'Tidak pasti — bantu saya fahamkannya', 'attr'),
    ('consent', 'span', 'I agree to Duta Integra contacting me',
     'Saya bersetuju Duta Integra menghubungi saya mengenai pertanyaan ini. Saya telah membaca '
     '<a href="/privacy" target="_blank" rel="noopener">notis privasi</a> dan memahami butiran saya hanya '
     'digunakan untuk membalas permintaan ini, selaras dengan PDPA Malaysia. <span class="req">*</span>', 'attr'),

    # ======================================================================
    # Batch D — CONTACT SIDEBAR
    # ======================================================================
    ('altK1', 'div', 'WhatsApp — fastest', 'WhatsApp — paling pantas', 'attr'),
    ('altK2', 'div', 'Email', 'Emel', 'attr'),
    ('altK3', 'div', 'Business hours', 'Waktu perniagaan', 'attr'),
    ('altK4', 'div', 'Where we are', 'Di mana kami berada', 'attr'),
    ('altV1', 'div', 'Usually replies the same business day.', 'Biasanya membalas pada hari bekerja yang sama.', 'wrap'),
    ('altV2', 'div', 'Best for detailed specs or RFPs.', 'Terbaik untuk spesifikasi terperinci atau RFP.', 'wrap'),
    ('altV3', 'div', 'Monday–Friday, 9am–6pm MYT',
     'Isnin–Jumaat, 9 pagi–6 petang MYT<br>Klien terurus sedia ada: pemantauan &amp; amaran 24/7.', 'attr'),
    ('altV4', 'div', 'F2-22-15, Tamarind Suites',
     'F2-22-15, Tamarind Suites, Tamarind Square, Persiaran Multimedia, Cyber 11, 63000 Cyberjaya, Selangor<br>'
     'Kunjungan ke lokasi di seluruh Lembah Klang; sokongan jarak jauh ke seluruh negara.', 'attr'),
    ('suH3', 'h3', 'What we do with your details', 'Apa kami lakukan dengan butiran anda', 'attr'),
    ('suP', 'p', 'We use them to answer this enquiry and nothing else',
     'Kami gunakannya untuk menjawab pertanyaan ini dan tiada yang lain — tiada senarai pemasaran, tiada jualan semula, '
     'tiada "tawaran rakan kongsi". Mintanya dipadam pada bila-bila masa dan ia selesai.', 'attr'),

    # ======================================================================
    # Batch D — FOOTER
    # ======================================================================
    ('fDesc', 'p', 'The AI-first IT partner for Malaysian SMEs.',
     'Rakan IT AI-first untuk PKS Malaysia. Infrastruktur, keselamatan dan automasi di bawah satu bumbung '
     'yang bertanggungjawab. Cyberjaya, Selangor.', 'attr'),
    ('fH4a', 'h4', 'Services', 'Perkhidmatan', 'attr'),
    ('fH4b', 'h4', 'Company', 'Syarikat', 'attr'),
    ('fH4c', 'h4', 'Talk to us', 'Bercakap dengan kami', 'attr'),
    ('fL1', 'a', 'Managed IT Services', 'Perkhidmatan IT Terurus', 'attr'),
    ('fL2', 'a', 'AI Software & Automation', 'Perisian &amp; Automasi AI', 'attr'),
    ('fL3', 'a', 'Cloud Migration', 'Migrasi Awan', 'attr'),
    ('fL4', 'a', 'Security & PDPA Compliance', 'Keselamatan &amp; Pematuhan PDPA', 'attr'),
    ('fL5', 'a', 'PDPA checklist (free)', 'Senarai semak PDPA (percuma)', 'attr'),
    ('fL6', 'a', 'How we work', 'Cara kami bekerja', 'attr'),
    ('fHours', 'li', 'Mon–Fri, 9am–6pm MYT', 'Isnin–Jumaat, 9 pagi–6 petang MYT', 'attr'),
    ('fPrivacy', 'a', 'Privacy notice', 'Notis privasi', 'attr'),
    ('fTerms', 'a', 'Terms', 'Syarat penggunaan', 'attr'),
]

# --------------------------------------------------------------------------
# parser: element tree with source spans + normalised subtree text
# --------------------------------------------------------------------------
SRC = open(PATH, encoding='utf-8').read()

def norm(s):
    return re.sub(r'\s+', ' ', s).strip()

line_starts = [0]
for i, ch in enumerate(SRC):
    if ch == '\n':
        line_starts.append(i + 1)

def offset(pos):                      # (line, col) from getpos -> absolute
    ln, col = pos
    return line_starts[ln - 1] + col

class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.nodes = []
        self.stack = []
        self.chunks = []            # (abs_offset, text) in document order

    def _node(self, tag, attrs, start):
        n = {'tag': tag, 'attrs': dict(attrs), 'start': start, 'end': None,
             'parent': self.stack[-1] if self.stack else None, 'kids': [], 'text': []}
        self.nodes.append(n)
        if self.stack:
            self.stack[-1]['kids'].append(n)
        return n

    def handle_starttag(self, tag, attrs):
        n = self._node(tag, attrs, offset(self.getpos()))
        # start tag ends at the '>' that closes it
        gt = SRC.find('>', n['start'])
        n['send'] = gt + 1
        if tag in ('br', 'img', 'input', 'hr', 'meta', 'link', 'source', 'use'):
            n['end'] = gt + 1
        else:
            self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        n = self._node(tag, attrs, offset(self.getpos()))
        n['send'] = SRC.find('>', n['start']) + 1
        n['end'] = n['send']

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i]['tag'] == tag:
                self.stack[i]['end'] = offset(self.getpos()) + len(tag) + 3  # </tag>
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self.stack:
            self.stack[-1]['text'].append(data)
            self.chunks.append((offset(self.getpos()), data))

    def close(self):
        super().close()
        for n in self.stack:
            n['end'] = len(SRC)

p = P()
p.feed(SRC)
p.close()

def subtree(n):
    """All descendant text in *document order* (own text interleaved with
    children, e.g. <span>…<b>…</b>…)."""
    return norm(''.join(t for (o, t) in p.chunks if n['start'] <= o <= n['end']))

def is_desc(node, ancestor):
    par = node['parent']
    while par is not None:
        if par is ancestor:
            return True
        par = par['parent']
    return False

def innermost(cands):
    """Drop a match when one of its descendants matched too — we always want
    the innermost element (a wrapper's text starts with its first child's)."""
    if len(cands) < 2:
        return cands
    return [c for c in cands
            if not any(k is not c and is_desc(k, c) for k in cands)]

def cls_of(n):
    return (n['attrs'].get('class') or '').split()

def insert_attr(n, text):
    """Replacement for the element's start tag [start, send) with `text`
    inserted just before its '>'. Must slice to send — SRC[end:] would be the
    rest of the file and duplicate it on every edit."""
    end = n['send'] - 1                      # index of '>'
    return SRC[n['start']:end] + text + SRC[end:n['send']]

edits = []          # (abs_start, abs_end, replacement, key)
report = []
fail = []
matched = []        # (key, mode, node, en_text, bm)

def add_edit(a, b, rep, key=''):
    edits.append((a, b, rep, key))

def has_key(n, key):
    """True when n or any descendant already carries this key (re-run safety)."""
    st = list(n['kids'])
    while st:
        k = st.pop()
        if k['attrs'].get('data-i18n') == key:
            return True
        st.extend(k['kids'])
    return False

for spec in SPECS:
    key, tag, en, bm, mode = spec[:5]
    exact = len(spec) > 5 and spec[5]
    # mode 'attr:X' targets an ATTRIBUTE value (placeholder, aria-label …)
    if mode.startswith('attr:'):
        at = mode.split(':', 1)[1]
        cands = [n for n in p.nodes
                 if n['tag'] == tag
                 and n['attrs'].get(at) == en
                 and n['attrs'].get('data-i18n') in (None, key)]
    else:
        cands = [n for n in p.nodes
                 if n['tag'] == tag
                 and (n['attrs'].get('data-i18n') in (None, key))
                 and ((subtree(n) == en) if exact
                      else subtree(n).startswith(en)
                           or (mode == 'wrap' and any(
                               t.strip().startswith(en) for t in n['text'] if t.strip())))]

    if len(cands) > 1:
        cands = innermost(cands)
    if not cands:
        # re-run safety: the key may already sit on an element we can no
        # longer text-match (wrap mode moved the text into an inner <span>)
        if any(n['attrs'].get('data-i18n') == key for n in p.nodes):
            report.append((key, mode, 1))
            continue
        hint = []
        if mode == 'attr' and en:
            hint = [f'"{subtree(n)[:60]}"' for n in p.nodes
                    if n['tag'] == tag and en in subtree(n)][:3]
        fail.append(f'NO MATCH  {key}  <{tag}> "{en[:60]}"'
                    + (f'   [substring lives in: {hint}]' if hint else ''))
        continue

    for n in cands:
        have = n['attrs'].get('data-i18n')
        if have and have != key:
            fail.append(f'KEY CLASH {key}: element already data-i18n="{have}" for "{en[:50]}"')
            continue
        matched.append((key, mode, n, subtree(n), bm))
        if mode.startswith('attr:'):
            if have:
                continue
            at = mode.split(':', 1)[1]
            add_edit(n['start'], n['send'],
                     insert_attr(n, f' data-i18n="{key}" data-i18n-attr="{at}"'), key)
        elif mode == 'attr':
            if have:
                continue
            add_edit(n['start'], n['send'], insert_attr(n, f' data-i18n="{key}"'), key)
        elif mode == 'wrap':
            if have or has_key(n, key):          # re-run: span already inserted
                continue
            texts = [t for t in n['text'] if t.strip()]
            if len(texts) != 1:
                fail.append(f'WRAP?    {key}: {len(texts)} text nodes in <{tag}> "{en[:50]}" — handle manually')
                continue
            if have:
                continue
            core = next(t for t in n['text'] if t.strip()).strip()
            anchor = n['send']
            # the source may hold entities (&amp;) that arrived decoded
            variants = [core, core.replace('&', '&amp;'),
                        core.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')]
            pos, used = -1, None
            for v in variants:
                p0 = SRC.find(v, anchor)
                if 0 <= p0 <= n['end']:
                    pos, used = p0, v
                    break
            if pos < 0:
                fail.append(f'WRAPPOS  {key}: text node not found for "{core[:40]}"')
                continue
            add_edit(pos, pos + len(used), f'<span data-i18n="{key}">{used}</span>', key)
    report.append((key, mode, len(cands)))

# ---------- sanity warnings (never fatal, but read every one) -------------
warn = []
for key, mode, n, entext, bm in matched:
    plain = re.sub(r'<[^>]+>', '', bm)
    if mode == 'attr' and entext and (len(plain) < len(entext) * .45 or len(plain) > len(entext) * 2.2):
        warn.append(f'SIZE  {key}: EN {len(entext):4d}c -> BM {len(plain):4d}c   '
                    f'<{n["tag"]}> "{entext[:48]}"')
    if mode == 'attr':                    # attr:swap rewrites innerHTML wholesale
        stack = list(n['kids'])
        while stack:
            k = stack.pop()
            if k['tag'] == 'svg' or k['attrs'].get('id'):
                warn.append(f'ATTR  {key}: rewrites child <{k["tag"]} '
                            f'{k["attrs"].get("id","")}> — BM string must keep it')
            stack.extend(k['kids'])

# ---------- apply ----------------------------------------------------------
# Safety rules (a bad range once duplicated the whole document):
#   * every range must satisfy 0 <= a < b <= len(SRC)
#   * ranges must not overlap (descending splice is only correct when disjoint)
#   * the spliced result must keep the same number of </html> markers
#   * total growth is bounded by the markup we insert
# Nothing is written unless every rule holds, and the write is atomic.
if not DRY and not fail:
    END_MARKS = SRC.count('</html>')
    orign = len(SRC)

    bad = [(k, a, b) for (a, b, _r, k) in edits if not (0 <= a < b <= len(SRC))]
    if bad:
        print('REFUSING TO WRITE — invalid edit ranges:')
        for k, a, b in bad[:20]:
            print(f'  {k:14} a={a} b={b} (len={len(SRC)})')
        sys.exit(2)

    ordered = sorted(edits, key=lambda e: -e[0])
    for prev, cur in zip(ordered, ordered[1:]):          # prev has the higher a
        if cur[1] > prev[0]:                             # overlap
            print(f'REFUSING TO WRITE — overlapping edits: {cur[3]} {cur[0]}:{cur[1]}'
                  f' vs {prev[3]} {prev[0]}:{prev[1]}')
            sys.exit(2)

    for a, b, rep, k in ordered:
        SRC = SRC[:a] + rep + SRC[b:]
        if SRC.count('</html>') != END_MARKS or len(SRC) > orign + 120_000:
            print(f'REFUSING TO WRITE — document duplicated/corrupted by edit '
                  f'{k!r} [{a}:{b}] (</html> {END_MARKS} -> {SRC.count("</html>")})')
            sys.exit(2)

    # regenerate the BM dict
    lines = ['  var BM = {']
    for i, spec in enumerate(SPECS):
        key, tag, en, bm, mode = spec[:5]
        esc = bm.replace('\\', '\\\\').replace("'", "\\'")
        lines.append(f"    {key}:'{esc}'" + (',' if i < len(SPECS) - 1 else ''))
    lines.append('  };')
    new_block = '\n'.join(lines)
    m = re.search(r'^  var BM = \{.*?^\  \};', SRC, re.S | re.M)
    if not m:
        fail.append('BM DICT BLOCK NOT FOUND')
    else:
        SRC = SRC[:m.start()] + new_block + SRC[m.end():]
        # atomic replace: write a sibling temp file, verify it, then swap it in
        tmp = PATH + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(SRC)
        back = open(tmp, encoding='utf-8').read()
        if back.count('</html>') != END_MARKS or not back.rstrip().endswith('</html>'):
            print('REFUSING TO WRITE — temp file failed verification')
            sys.exit(2)
        shutil.copy2(PATH, PATH + '.bak')
        os.replace(tmp, PATH)

# ---------- nested-key check ---------------------------------------------
def nested_check(text):
    global line_starts
    keep = line_starts
    ls = [0]                                   # line_starts must match THIS text
    for i, ch in enumerate(text):
        if ch == '\n':
            ls.append(i + 1)
    line_starts = ls
    try:
        pp = P()
        pp.feed(text)
        pp.close()
        bad = []
        for n in pp.nodes:
            # only an innerHTML swap can destroy a descendant key; elements
            # with data-i18n-attr (aria-label, placeholder) rewrite an
            # attribute and leave their subtree alone
            if n['attrs'].get('data-i18n') and not n['attrs'].get('data-i18n-attr'):
                par = n['parent']
                while par is not None:
                    if (par['attrs'].get('data-i18n')
                            and not par['attrs'].get('data-i18n-attr')):
                        bad.append(f"<{n['tag']} {n['attrs'].get('data-i18n')}> inside <{par['tag']} {par['attrs'].get('data-i18n')}>")
                        break
                    par = par['parent']
        return bad
    finally:
        line_starts = keep

print('=== matches (key, mode, count) ===')
for key, mode, c in report:
    print(f'  {key:14} {mode:16} x{c}')
if warn:
    print(f'\n=== WARNINGS ({len(warn)}) ===')
    for w in warn:
        print('  ' + w)
if fail:
    print('\n=== FAILURES ===')
    for f in fail:
        print('  ' + f)
elif DRY:
    print('\n(dry run — nothing written)')
else:
    nb = nested_check(SRC)
    print(f'\nWROTE index.html  ({len(edits)} html edits, {len(SPECS)} dict keys)')
    if nb:
        print('NESTED data-i18n (must be empty):')
        for x in nb:
            print('  ' + x)
        sys.exit(1)
    print('no nested data-i18n ✓')
