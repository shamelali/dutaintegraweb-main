#!/usr/bin/env node
/**
 * smoke-check.js — verify what the hosting actually serves.
 *
 * Run:  node tools/smoke-check.js                      # production
 *       node tools/smoke-check.js --origin https://x.dutaintegra.pages.dev
 *
 * Every other test in this repo reads files out of `public/`. That is the
 * right default — it is fast and needs no network — but it can only ever
 * answer "is the repository correct?", never "is the site correct?". Those
 * come apart: this project shipped a deployment whose every path returned
 * 404, and a build that only reads the repository will call that a success.
 *
 * So this one makes real requests. It is the only test that would have
 * caught the soft-404 defect, because the cause was not in any file — the
 * repository was fine the whole time. There was simply no 404.html for
 * Cloudflare Pages to serve, so unmatched paths fell through to the
 * homepage with a 200 and search engines indexed duplicate copies of it.
 *
 * Dependency-free: node's https only, no npm install, so it can run in CI.
 */
'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');

let origin = 'https://dutaintegra.my';
const originFlag = process.argv.indexOf('--origin');
if (originFlag > -1 && process.argv[originFlag + 1]) {
  origin = process.argv[originFlag + 1].replace(/\/+$/, '');
}

let pass = 0;
let fail = 0;

function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

/* One request, no redirect following — a redirect is itself a finding here. */
function probe(path, method = 'GET') {
  const url = new URL(path, origin);
  const lib = url.protocol === 'http:' ? http : https;
  return new Promise((resolve) => {
    const req = lib.request(url, { method, timeout: 20000, headers: { 'User-Agent': 'dutaintegra-smoke-check' } }, (res) => {
      const chunks = [];
      res.on('data', (c) => { if (chunks.reduce((n, b) => n + b.length, 0) < 400000) chunks.push(c); });
      res.on('end', () => resolve({
        status: res.statusCode,
        type: res.headers['content-type'] || '',
        cache: res.headers['cf-cache-status'] || '',
        body: Buffer.concat(chunks).toString('utf8'),
      }));
    });
    req.on('error', (e) => resolve({ status: 0, type: '', cache: '', body: '', error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ status: 0, type: '', cache: '', body: '', error: 'timeout' }); });
    req.end();
  });
}

(async () => {
  console.log(`smoke-check → ${origin}\n`);

  const home = await probe('/');
  check('homepage responds 200', home.status === 200, 'status ' + home.status + (home.error ? ' ' + home.error : ''));
  check('homepage is the Duta Integra homepage',
    /<title>[^<]*Duta Integra/.test(home.body), home.body.slice(0, 120).replace(/\s+/g, ' '));
  check('homepage states a live price, not the retired one',
    /RM\s?2,500/.test(home.body) && !/RM\s?799\b/.test(home.body));

  // A real page that only exists because of the repositioning work.
  const service = await probe('/ai-operations');
  check('service page /ai-operations responds 200', service.status === 200, 'status ' + service.status);

  // THE check. Before public/404.html existed this returned 200 with a full
  // copy of the homepage, and nothing else in the toolchain could see it.
  const missing = await probe('/this-path-should-not-exist-' + Date.now().toString(36));
  check('unknown path returns 404, not a soft-404',
    missing.status === 404, 'status ' + missing.status + (missing.status === 200 ? ' — serving ' + missing.body.length + ' bytes, likely index.html' : ''));
  check('the 404 body is the not-found page',
    /404/.test(missing.body) && /Halaman tidak dijumpai|Page not found/.test(missing.body),
    missing.body.slice(0, 100).replace(/\s+/g, ' '));

  // A file with an extension, which is the shape that most reliably exposed
  // the defect: extensions should never be answered with HTML.
  const strayAsset = await probe('/nope-' + Date.now().toString(36) + '.txt');
  check('unknown asset returns 404', strayAsset.status === 404, 'status ' + strayAsset.status);

  // The retired social card. The defect worth guarding is that it answered
  // with text/html — a soft-404 handing back a copy of the homepage. A stale
  // edge cache entry can legitimately still hold the old JPEG for a while
  // after the file is gone, and nothing references this path any more, so
  // requiring a hard 404 would make this assertion cry wolf on cache state
  // rather than on a real regression.
  const retiredCard = await probe('/og-image.jpg');
  check('retired /og-image.jpg does not serve HTML',
    retiredCard.status === 404 || !/text\/html/.test(retiredCard.type),
    'status ' + retiredCard.status + ' type ' + retiredCard.type +
    (retiredCard.status === 200 && /text\/html/.test(retiredCard.type)
      ? ' — serving ' + retiredCard.body.length + ' bytes of HTML, likely index.html'
      : ''));

  const card = await probe('/og-image-v2.jpg');
  check('social card /og-image-v2.jpg responds 200 as an image',
    card.status === 200 && /^image\//.test(card.type), 'status ' + card.status + ' type ' + card.type);

  const sitemap = await probe('/sitemap.xml');
  check('sitemap responds 200 as XML',
    sitemap.status === 200 && /<urlset/.test(sitemap.body), 'status ' + sitemap.status);

  // The lead endpoint must answer, and must refuse a foreign origin. Both
  // prove the Functions are mounted; the second proves the PDPA origin
  // boundary is not accidentally wide open. No mail is sent either way.
  const badOrigin = await probe('/api/send-email', 'POST');
  check('lead endpoint is mounted and rejects a foreign origin',
    badOrigin.status === 403 || badOrigin.status === 405, 'status ' + badOrigin.status);

  console.log('');
  if (fail) {
    console.log(`FAIL — ${fail} failed, ${pass} passed`);
    process.exit(1);
  }
  console.log(`ALL PASS — ${pass}/${pass}`);
})();
