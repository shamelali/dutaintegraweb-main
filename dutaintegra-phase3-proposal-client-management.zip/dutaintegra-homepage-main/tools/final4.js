const { chromium } = require('playwright');
const D='/home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/';
const docs=['02-privacy-notice-TEMPLATE.html','03-breach-response-plan.html','04-data-subject-rights-procedure.html',
            '05-dpo-appointment-pack.html','06-staff-one-pager.html','08-engagement-letter-and-sow.html','09-kickoff-questionnaire.html'];
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  let fail=0;
  console.log('  FILE                                    PAGES  DISCLAIMER  ERRORS');
  console.log('  '+'─'.repeat(66));
  for(const f of docs){
    const c=await b.newContext({viewport:{width:900,height:1100}});
    const p=await c.newPage(); const errs=[];
    p.on('pageerror',e=>errs.push(e.message));
    p.on('console',m=>{if(m.type()==='error'&&!/net::|Failed to load|fonts\.g/.test(m.text()))errs.push(m.text())});
    await p.goto('file://'+D+f,{waitUntil:'load'});
    await p.waitForTimeout(700);
    const txt=await p.evaluate(()=>document.body.innerText);
    const hasDisc=/not a law firm|bukan firma guaman|not legal advice/i.test(txt);
    const leftover=(txt.match(/\[\[/g)||[]).length;
    const marks=(txt.match(/NEEDS CLIENT INPUT/g)||[]).length;
    await p.emulateMedia({media:'print'});
    await p.waitForTimeout(200);
    const buf=await p.pdf({format:'A4',printBackground:true});
    const pages=(buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g)||[]).length;
    const ok=pages>0 && errs.length===0;
    if(!ok) fail++;
    console.log(`  ${f.padEnd(38)} ${String(pages).padStart(2)}     ${(hasDisc?'yes':'— ').padEnd(10)} ${errs.length?('⚠ '+errs[0].slice(0,30)):'0'}${marks?'   ['+marks+' client-input markers]':''}`);
    await c.close();
  }
  console.log('  '+'─'.repeat(66));
  console.log(fail?`  ${fail} FAILURES`:'  ALL DOCS RENDER CLEAN');
  await b.close();
})();
