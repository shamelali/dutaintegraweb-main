/**
 * terms-check.js — static checks for the bilingual terms.html.
 *
 * Run:  node tools/terms-check.js     (exit 0 = all pass)
 *
 * Guards the things that break a bilingual legal page silently:
 *   1. document halves (EN + lang="ms" BM) exist and balance h2/h3
 *   2. every BM heading is real text, and the BM half reads as Malay
 *   3. the jump-toggle works both ways (buttons, cross-links, script, hashes)
 *   4. hygiene: no placeholders, no old phone, apex canonical, analytics wired
 *
 * The bilingual approach here is STATIC (both halves in the DOM, buttons
 * jump) — unlike index.html's JS dictionary. Check 20 pins that: a data-i18n
 * attribute on this page would be dead code.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const FILE = [
  path.join(__dirname, '..', 'public', 'terms.html'),              // current repo layout
  path.join(__dirname, '..', 'terms.html'),                        // tools/ inside site root
  path.join(__dirname, '..', 'dutaintegra-homepage', 'terms.html'), // tools/ beside site dir
].find(p => fs.existsSync(p));
const html = fs.readFileSync(FILE, 'utf8');

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

const count = (re) => (html.match(re) || []).length;
/* Halves are extracted by section id, not position: BM is the site default
   and leads the page, so the old "everything before lang=ms" split would
   put the header in the EN half and both sections in the BM half. */
const enStart = html.indexOf('id="en-terms"');
const bmStart = html.indexOf('id="bm-terms"');
const enHalf = enStart === -1 ? '' : html.slice(enStart, html.indexOf('</section>', enStart));
const bmHalf = bmStart === -1 ? '' : html.slice(bmStart, html.indexOf('</section>', bmStart));
const h2s = (s) => [...s.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/g)].map(m => m[1].replace(/<[^>]+>/g, '').trim());

/* ---- 1. document halves ---------------------------------------------- */
check('file has <html lang="en"> root', /<html[^>]*lang="en"/.test(html));
check('exactly one lang="ms" region', count(/lang="ms"/g) === 1, count(/lang="ms"/g) + ' found');
check('#en-terms section with data-lang="en"', /id="en-terms"[^>]*data-lang="en"|data-lang="en"[^>]*id="en-terms"/.test(html));
check('#bm-terms section with data-lang="bm" + lang="ms"', /id="bm-terms"[^>]*lang="ms"|lang="ms"[^>]*id="bm-terms"/.test(html) &&
  /data-lang="bm"/.test(html));

/* ---- 2. section balance ----------------------------------------------- */
const enH2 = h2s(enHalf), bmH2 = h2s(bmHalf);
check('h2 parity EN==BM and non-empty', enH2.length > 0 && enH2.length === bmH2.length,
  `EN ${enH2.length} / BM ${bmH2.length}`);
check('h3 parity EN==BM', count(/<h3/g) > 0 &&
  (enHalf.match(/<h3/g) || []).length === (bmHalf.match(/<h3/g) || []).length);
check('every BM h2 is real text (10+ chars)', bmH2.length > 0 && bmH2.every(t => t.length >= 10));

/* ---- 3. jump-toggle both ways ------------------------------------------ */
check('btnEn + btnBm exist', html.includes('id="btnEn"') && html.includes('id="btnBm"'));
check('initial aria-pressed en=false bm=true (BM is the site default)',
  /id="btnEn"[^>]*aria-pressed="false"/.test(html) && /id="btnBm"[^>]*aria-pressed="true"/.test(html));
check('cross-links both directions', html.includes('data-jump="bm"') && html.includes('data-jump="en"') &&
  html.includes('#bm-terms') && html.includes('#en-terms'));
check('script swaps documentElement.lang', /documentElement\.lang\s*=\s*isBm\s*\?\s*['"]ms['"]/.test(html));
check('script replaceState both hashes', html.includes("'#bm-terms'") && html.includes("'#en-terms'"));
check('script resolves both sections', html.includes("getElementById('en-terms')") &&
  html.includes("getElementById('bm-terms')"));

/* ---- 4. hygiene ---------------------------------------------------------- */
check('no placeholders (fill/CONFIRM/TODO/lorem)',
  !/class="fill"|\[CONFIRM\]|\bTODO\b|\bFIXME\b|lorem/i.test(html.replace(/placeholder=/gi, '')));
check('no old phone, no www refs', !html.includes('601137633788') && !html.includes('3763') &&
  !html.includes('www.dutaintegra.my'));
check('canonical + og:url apex /terms',
  html.includes('<link rel="canonical" href="https://dutaintegra.my/terms">') &&
  html.includes('<meta property="og:url" content="https://dutaintegra.my/terms">'));
check('footer: support@ + new number',
  html.includes('support@dutaintegra.my') && html.includes('+60 11-5403 4051'));
check('BM half reads as Malay (function words present)',
  ['\\bdan\\b', '\\byang\\b', '\\buntuk\\b', '\\bdengan\\b', '\\bkami\\b'].every(re => new RegExp(re, 'i').test(bmHalf)));
check('no data-i18n (static bilingual by design)', !html.includes('data-i18n'));
check('analytics.js wired', html.includes('src="/analytics.js"'));
check('version + dates match across halves (1.0, EN/BM dates present)',
  /version 1\.0, effective \d{1,2} \w+ \d{4}/.test(enHalf) &&
  /versi 1\.0, berkuat kuasa \d{1,2} \w+ \d{4}/.test(bmHalf));

console.log(fail === 0 ? `\nALL PASS — ${pass}/${pass}` : `\n${fail} FAILURES`);
process.exit(fail ? 1 : 0);
