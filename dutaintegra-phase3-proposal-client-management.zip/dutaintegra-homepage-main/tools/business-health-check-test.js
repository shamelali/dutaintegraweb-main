/* Dependency-free contract checks for the public business health check. */
'use strict';

const fs = require('fs');
const path = require('path');

const apiPath = path.join(__dirname, '..', 'functions', 'api', 'business-health-check.js');
const clientPath = path.join(__dirname, '..', 'public', 'health-check.js');
const api = fs.readFileSync(apiPath, 'utf8');
const client = fs.readFileSync(clientPath, 'utf8');

const ok = (condition, message) => {
  if (!condition) throw new Error(`FAIL ${message}`);
  console.log(`ok    ${message}`);
};

ok(api.includes("request.method !== 'POST'"), 'API rejects non-POST requests');
ok(api.includes('ALLOWED_ORIGINS') && api.includes('Forbidden origin'), 'API has a fail-closed origin boundary');
ok(api.includes('429') && api.includes('Retry-After'), 'API reports rate limiting with a retry hint');
ok(api.includes('MAX_BODY_BYTES') && api.includes('Request body too large'), 'API bounds request size');
ok(api.includes('MAX_REDIRECTS') && api.includes("next.origin !== origin"), 'crawler bounds and pins same-origin redirects');
ok(api.includes('localhost') && api.includes('169\\.254\\.'), 'crawler rejects common local and link-local targets');
ok(api.includes('AbortSignal.timeout(8000)'), 'crawler has a per-page timeout');
ok(api.includes('sources: pages.map((page) => page.url)'), 'rule-based report returns public source URLs');
ok(api.includes('AI_API_KEY') && api.includes('AI_MODEL'), 'AI provider is opt-in through environment variables');
ok(api.includes('allowedSources.has(source)'), 'AI source output is restricted to crawled public URLs');
ok(api.includes('registrationNumber'), 'API accepts an optional company registration number');
ok(client.includes("fetch('/api/business-health-check'"), 'client posts to the health-check endpoint');
ok(client.includes('company') && client.includes('registrationNumber') && client.includes('website'), 'client sends minimal company identity fields');
ok(client.includes("document.documentElement.lang === 'ms'"), 'client follows the homepage language selection');
ok(client.includes('textContent') && !client.includes('innerHTML'), 'result rendering uses safe textContent');

console.log('\nALL PASS — Business Health Check contract');
