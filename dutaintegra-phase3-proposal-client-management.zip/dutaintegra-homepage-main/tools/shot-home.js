const { chromium } = require('playwright');
const path = require('path');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:1280,height:900},deviceScaleFactor:1});
  const p=await c.newPage();
  await p.goto('http://127.0.0.1:8080/',{waitUntil:'networkidle'});
  await p.waitForTimeout(1200);
  await p.evaluate(()=>{document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'));});
  await p.waitForTimeout(800);
  const h=await p.evaluate(()=>document.body.scrollHeight);
  const out=path.resolve(__dirname,'..','dutaintegra-homepage','previews','review-full.png');
  await p.screenshot({path:out,fullPage:true});
  console.log('height',h,'->',out);
  await b.close();
})();
