#!/usr/bin/env node
/**
 * services-test.js — static checks for the four service pages.
 *
 *   node tools/services-test.js      (exit 0 = all pass)
 *
 * Covers the things that are easy to break and invisible in the browser:
 *   1. every page file exists and is a single, complete document
 *   2. every [data-i18n] key on a page exists in that page's BM dictionary
 *      (page dict + the shared chrome dict)
 *   3. every BM key a page ships is actually used in that page's markup
 *   4. no nested data-i18n, and no key reused with data-i18n-attr by mistake
 *   5. no CJK / Cyrillic characters in BM strings (catches mojibake and
 *      accidental translation into a third language)
 *   6. internal links point at routes that exist (_redirects + sitemap aware)
 *   7. canonical + meta description present, lang="en" markup, BM-default wiring
 */
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');

const PAGES = [
  { slug: 'ai-operations', dict: 'bm/ai-operations.js' },
  { slug: 'managed-it', dict: 'bm/managed-it.js' },
  { slug: 'security-pdpa', dict: 'bm/security-pdpa.js' },
  { slug: 'websites', dict: 'bm/websites.js' },
];

const VOID = new Set(['area','base','br','col','embed','hr','img','input',
  'link','meta','param','source','track','wbr','use','path','circle',
  'rect','line','polygon','polyline','stop']);

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

/* ---------- load the dictionaries (they are window.X = {...} literals) ---------- */
function loadDict(rel) {
  const p = path.join(PUBLIC, rel);
  if (!fs.existsSync(p)) return null;
  const src = fs.readFileSync(p, 'utf8');
  const sandbox = { window: {} };
  // These files are plain `window.X = { ... }` literals; a Function sandbox is
  // enough and avoids pulling in a browser or a dependency.
  new Function('window', src)(sandbox.window);
  const w = sandbox.window;
  return w.DI_CHROME_BM || w.DI_PAGE_BM || null;
}

const chrome = loadDict('bm/chrome.js') || {};

/* ---------- routes that actually exist ---------- */
const redirects = fs.readFileSync(path.join(PUBLIC, '_redirects'), 'utf8');
const knownRoutes = new Set(['/']);
for (const line of redirects.split('\n')) {
  const t = line.trim();
  if (!t.startsWith('/') || t.startsWith('/#')) continue;
  const parts = t.split(/\s+/);
  if (parts.includes('200')) knownRoutes.add(parts[0].replace(/\/$/, '') || '/');
}
// Files in public/ that Pages serves at their extensionless path
for (const f of fs.readdirSync(PUBLIC)) {
  if (f.endsWith('.html')) knownRoutes.add('/' + f.replace(/\.html$/, ''));
}
for (const d of fs.readdirSync(PUBLIC, { withFileTypes: true })) {
  if (d.isDirectory() && fs.existsSync(path.join(PUBLIC, d.name, 'index.html'))) {
    knownRoutes.add('/' + d.name);
  }
}

for (const page of PAGES) {
  console.log('\n' + page.slug);
  const file = path.join(PUBLIC, page.slug + '.html');
  if (!fs.existsSync(file)) { check('page exists', false, 'public/' + page.slug + '.html'); continue; }
  check('page exists', true);

  const html = fs.readFileSync(file, 'utf8');
  check('single <html> and doctype',
    (html.match(/<!doctype html>/gi) || []).length === 1 &&
    (html.match(/<\/html>/g) || []).length === 1);
  check('lang="en" on <html>', /<html lang="en">/.test(html));
  check('canonical url', html.includes('https://dutaintegra.my/' + page.slug));
  check('meta description', /<meta name="description" content="[^"]{40,}"/.test(html));
  check('loads /services.css', html.includes('/services.css'));
  check('loads /bm/chrome.js then /services-i18n.js',
    html.indexOf('/bm/chrome.js') > -1 &&
    html.indexOf('/bm/' + path.basename(page.dict)) > -1 &&
    html.indexOf('/services-i18n.js') > html.indexOf('/bm/' + path.basename(page.dict)),
    'BM dict must load before services-i18n.js so the merge finds it');
  check('no storage used', !/localStorage|sessionStorage|document\.cookie/.test(html));

  const dict = loadDict(page.dict);
  if (!dict) { check('page BM dictionary parses', false, page.dict); continue; }
  const dictKeys = new Set(Object.keys(dict));
  const BM = Object.assign({}, chrome, dict);

  /* markup keys (comments and script bodies stripped) */
  let scan = html.replace(/<!--[\s\S]*?-->/g, '');
  scan = scan.replace(/(<script\b[^>]*>)([\s\S]*?)(<\/script>)/gi, '$1$3');
  const markupKeys = [];
  const tagRe = /<(\/?)([a-zA-Z][\w-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/g;
  const stack = [];
  let m, nesting = 0;
  const nestOffenders = [];
  while ((m = tagRe.exec(scan)) !== null) {
    const closing = m[1] === '/', tag = m[2].toLowerCase(), attrs = m[3];
    const km = attrs.match(/data-i18n="([^"]+)"/);
    if (closing) {
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) { stack.length = i; break; }
      }
      continue;
    }
    if (km) {
      markupKeys.push(km[1]);
      // A localisable element inside another localisable element would have its
      // own key wiped when the parent swaps innerHTML.
      // data-i18n-attr swaps an attribute (aria-label, placeholder) rather
      // than innerHTML, so nesting inside one of those is harmless.
      const parent = stack.find(s => s.key && s.swapsInner);
      if (parent) nesting++, nestOffenders.push(km[1] + ' inside ' + parent.key);
    }
    if (!VOID.has(tag)) stack.push({ tag, key: km ? km[1] : null, swapsInner: !/data-i18n-attr=/.test(attrs) });
  }

  const missing = [...new Set(markupKeys)].filter(k => !BM[k]);
  check('every data-i18n key has a BM value', missing.length === 0, missing.join(', '));
  check('no nested data-i18n', nesting === 0, nestOffenders.slice(0, 6).join('; '));

  const chromeUnused = Object.keys(chrome).filter(k => !markupKeys.includes(k));
  check('shared chrome dictionary is fully used', chromeUnused.length === 0, chromeUnused.join(', '));

  const pageUnused = [...dictKeys].filter(k => !markupKeys.includes(k));
  check('page BM dictionary is fully used', pageUnused.length === 0, pageUnused.join(', '));

  /* third-language / mojibake guard */
  const offenders = [];
  for (const [k, v] of Object.entries(BM)) {
    if (!markupKeys.includes(k)) continue;
    if (/[\u3000-\u9fff\uac00-\ud7af\u0400-\u04ff]/.test(v)) offenders.push(k);
  }
  check('no CJK/Cyrillic in BM strings', offenders.length === 0, offenders.join(', '));

  /* Leftover-English guard. Bahasa Malaysia copy does not use these function
     words, so their presence means a fragment of the English string survived
     into the dictionary (the failure mode when a translation is edited). */
  const leak = [];
  for (const [k, v] of Object.entries(BM)) {
    if (!markupKeys.includes(k)) continue;
    if (/\b(the|and|with|your|that|from|this|should|would|there|about)\b/i.test(v)) leak.push(k);
  }
  check('no English fragments left in BM strings', leak.length === 0, leak.join(', '));

  /* internal links must resolve. Asset files (.css/.svg/.js/.jpg) live in
     public/ too, so only routes are checked here. */
  const bad = [];
  for (const lm of html.matchAll(/href="(\/[^"#?]*)/g)) {
    const href = lm[1].replace(/\/$/, '') || '/';
    if (/\.(css|js|svg|jpg|png|webp|xml|txt|ico)$/i.test(href)) continue;
    if (!knownRoutes.has(href)) bad.push(href);
  }
  check('internal links resolve to a real route', bad.length === 0, [...new Set(bad)].join(', '));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);