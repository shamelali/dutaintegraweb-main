const { chromium } = require('playwright');
const path=require('path'), fs=require('fs');
const D='/home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/';
const files=process.argv.slice(2);
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  for(const f of files){
    const c=await b.newContext({viewport:{width:900,height:1100}});
    const p=await c.newPage();
    await p.goto('file://'+D+f,{waitUntil:'load'});
    await p.waitForTimeout(1200);
    await p.emulateMedia({media:'print'});
    await p.waitForTimeout(300);
    const out=D+f.replace('.html','.pdf');
    await p.pdf({path:out,format:'A4',printBackground:true});
    const kb=Math.round(fs.statSync(out).size/1024);
    console.log(`  ${f.padEnd(42)} → ${path.basename(out).padEnd(42)} ${String(kb).padStart(4)} KB`);
    await c.close();
  }
  await b.close();
})();
