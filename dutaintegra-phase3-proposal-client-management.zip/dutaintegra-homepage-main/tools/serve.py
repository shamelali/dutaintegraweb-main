#!/usr/bin/env python3
"""Local preview server that honours the site's _redirects map.

Start with:  python3 tools/serve.py &
Then verify: node tools/routes.js
             node tools/shot-home.js

If require('playwright') fails, run `bash tools/setup.sh` once: it installs
playwright into tools/deps/ and links tools/node_modules so tools/*.js work
unmodified. (Snapshot stripping removes anything named node_modules, so the
link may need recreating each session; `NODE_PATH=tools/deps/node_modules
node tools/routes.js` is the fallback when you would rather not link.)

Mirrors what is deployed: exact 200 rewrites, 301/302 redirects, and the
`/* /index.html 200` SPA catch-all. /api/ is deliberately a dead end — there
is no Node backend here, and a fake 200 would make the lead form claim success
without sending anything (its WhatsApp fallback only triggers on a failure).
"""
import http.server, socketserver, os, pathlib

def _root():
    """Return the publish directory for both historical and current layouts."""
    legacy = pathlib.Path('/home/user/dutaintegra-homepage')
    derived = pathlib.Path(__file__).resolve().parent.parent
    candidates = [
        legacy / 'public', legacy,
        derived / 'dutaintegra-homepage' / 'public', derived / 'dutaintegra-homepage',
        # Flat layout: this repository IS the publish root (tools/ and public/
        # sit directly inside it).
        derived / 'public', derived,
    ]
    for candidate in candidates:
        if (candidate / '_redirects').is_file() and (candidate / 'index.html').is_file():
            return candidate
    tried = ', '.join(str(candidate) for candidate in candidates)
    raise SystemExit(f'site not found: tried {tried}')

ROOT = str(_root())

REWRITE = {}   # 200 rewrites:  /privacy -> /privacy.html
REDIRECT = {}  # 301 / 302:     /wa -> https://wa.me/...

with open(os.path.join(ROOT, '_redirects'), encoding='utf-8') as fh:
    for line in fh:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        p = line.split()
        # Rules with '*' or ':' are expressions and are handled by the host.
        if len(p) != 3 or any(c in p[0] for c in '*:'):
            continue
        key = p[0].rstrip('/') or '/'
        if p[2] == '200' and p[1].startswith('/'):
            REWRITE[key] = p[1]
        elif p[2] in ('301', '302'):
            REDIRECT[key] = (p[1], int(p[2]))

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)

    def do_GET(self):
        path = self.path.split('?')[0].split('#')[0].rstrip('/') or '/'
        if path in REDIRECT:
            target, code = REDIRECT[path]
            self.send_response(code)
            self.send_header('Location', target)
            self.end_headers()
            return
        super().do_GET()

    def translate_path(self, path):
        orig = path.split('?')[0].split('#')[0]
        clean = orig
        if clean in REWRITE:
            clean = REWRITE[clean]
        elif clean.rstrip('/') in REWRITE:
            clean = REWRITE[clean.rstrip('/')]
        # No backend in preview: keep /api/ a 404 instead of letting it fall
        # through to a static file.
        if clean.startswith('/api/'):
            return os.path.join(ROOT, '__no_backend_here__')

        # Cloudflare Pages clean URLs resolve an extensionless HTML file. Do
        # the same locally, but leave unknown paths as 404s rather than
        # disguising them as the homepage.
        p = os.path.join(ROOT, clean.lstrip('/'))
        if clean == '/':
            p = os.path.join(ROOT, 'index.html')
        elif '.' not in os.path.basename(clean):
            if os.path.isdir(p):
                p = os.path.join(p, 'index.html')
            elif os.path.isfile(p + '.html'):
                p += '.html'
            else:
                p = os.path.join(p, 'index.html')
        return p

    def log_message(self, *a):
        pass

socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(('127.0.0.1', 8080), H) as s:
    s.serve_forever()
