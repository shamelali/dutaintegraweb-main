const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:2});
  const p=await c.newPage();
  await p.goto('http://127.0.0.1:8080/',{waitUntil:'networkidle'});
  await p.waitForTimeout(1500);
  await p.evaluate(()=>{document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'));});
  await p.waitForTimeout(500);
  await p.screenshot({path:'/tmp/mob-hero.png'});
  const m=await p.evaluate(()=>{
    const sticky=document.querySelector('.sticky-bar,.mobile-bar,[class*=sticky]');
    const r=sticky?sticky.getBoundingClientRect():null;
    // does the sticky bar cover the submit button?
    const btn=document.querySelector('form button[type=submit],form .btn-primary');
    const br=btn?btn.getBoundingClientRect():null;
    return {
      docW:document.documentElement.scrollWidth, winW:document.documentElement.clientWidth,
      sticky:r?{h:Math.round(r.height),pos:getComputedStyle(sticky).position}:null,
      heroCols:getComputedStyle(document.querySelector('.hero .wrap')).gridTemplateColumns||'n/a',
      pageH:document.body.scrollHeight
    };
  });
  console.log('  viewport 390 · scrollWidth',m.docW,'vs client',m.winW,m.docW<=m.winW+2?'✓ no overflow':'⚠ OVERFLOW');
  console.log('  page height:',m.pageH,'px =',(m.pageH/844).toFixed(1),'screens');
  console.log('  sticky element:',JSON.stringify(m.sticky));
  await b.close();
})();
