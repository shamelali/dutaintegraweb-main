const { chromium } = require('playwright');
const { execSync } = require('child_process');
const fs=require('fs');
const D='/home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/';
const files=process.argv.slice(2);
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  for(const f of files){
    const c=await b.newContext({viewport:{width:900,height:1100}});
    const p=await c.newPage();
    await p.goto('file://'+D+f,{waitUntil:'load'});
    await p.waitForTimeout(800);
    await p.emulateMedia({media:'print'});
    const out='/tmp/'+f.replace('.html','.pdf');
    await p.pdf({path:out,format:'A4',printBackground:true,margin:{top:'10mm',bottom:'10mm',left:'10mm',right:'10mm'}});
    await c.close();
    // rasterise + measure lowest non-white row per page
    execSync(`rm -f /tmp/fp-*.png && pdftoppm -r 70 -png ${out} /tmp/fp`);
    const pngs=fs.readdirSync('/tmp').filter(x=>x.startsWith('fp-')).sort();
    console.log(`${f}  →  ${pngs.length} pages`);
    pngs.forEach((png,i)=>{
      const r=execSync(`python3 -c "
from PIL import Image
import numpy as np
im=Image.open('/tmp/${png}').convert('L')
a=np.array(im)
rows=np.where((a<245).sum(axis=1)>2)[0]
h=a.shape[0]
last=rows.max() if len(rows) else 0
print(f'{100*last/h:.0f}')"`).toString().trim();
      const bar='█'.repeat(Math.round(parseInt(r)*0.4));
      console.log(`   p${i+1}: ${r.padStart(3)}% fill  ${bar}`);
    });
    // ctx closed per file
  }
  await b.close();
})();
