/** Dependency-free contract checks for the local operations walkthrough. */
'use strict';

const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const demo = require(path.join(root, 'public/operations-demo.js'));
let pass = 0;
let fail = 0;

function check(name, ok) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name); }
}

const html = fs.readFileSync(path.join(root, 'public/operations-demo.html'), 'utf8');
const script = fs.readFileSync(path.join(root, 'public/operations-demo.js'), 'utf8');
check('demo assets are self-contained',
  !/<script[^>]+src="https?:|<link[^>]+rel="stylesheet"[^>]+href="https?:/.test(html));
check('demo declares simulation-only boundary', /Always simulation only/.test(html) && /no external action/.test(script));
check('demo has no network or browser storage APIs', !/\b(fetch|XMLHttpRequest|localStorage|sessionStorage)\b/.test(script));
check('state flow gates approval', demo.transitionState({ state: demo.STATES.MONITORING }, 'APPROVE') === demo.STATES.MONITORING && demo.transitionState({ state: demo.STATES.AWAITING_APPROVAL }, 'APPROVE') === demo.STATES.RECOVERING);
const draft = demo.buildDraftText({ hardwareQuantity: '2', hardwareUnitCost: '1,250.00', laborHours: '3', laborRate: '100.00', slaMonthly: '799.00', slaMonths: '12' });
check('proposal uses exact integer cents', draft.ok && draft.totals.totalCents === 1238800 && draft.json.includes('"commitment": false'));
const invalid = demo.buildDraftText({ hardwareQuantity: '2.5', hardwareUnitCost: '1,250.00', laborHours: '3', laborRate: '100.00', slaMonthly: '799.00', slaMonths: '12' });
check('proposal rejects fractional whole units', !invalid.ok && Boolean(invalid.errors.hardwareQuantity));
if (fail) { console.log(`FAIL — ${fail} failed, ${pass} passed`); process.exit(1); }
console.log(`ALL PASS — ${pass}/${pass}`);
