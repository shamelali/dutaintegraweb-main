/* Dependency-free contract checks for the scorecard contact gate. */
const fs = require('fs');

const html = fs.readFileSync('public/audit-scorecard.html', 'utf8');
const ok = (condition, message) => {
  if (!condition) throw new Error(`FAIL ${message}`);
  console.log(`ok    ${message}`);
};

ok((html.match(/<div class="row">/g) || []).length === 25, 'scorecard has 25 assessment rows');
ok(html.includes('id="reportGateForm"'), 'contact gate form exists');
ok(html.includes('id="gateName"') && html.includes('id="gateCompany"'), 'name and company fields exist');
ok(html.includes('id="gateEmail"') && html.includes('id="gateConsent"'), 'email and consent fields exist');
ok(html.includes('id="printBtn" type="button" hidden'), 'report print action starts locked');
ok(html.includes("service: 'Free IT audit scorecard'"), 'scorecard lead has a stable service value');
ok(html.includes("source: 'scorecard'"), 'scorecard lead has a stable source value');
ok(html.includes("if (!response.ok) throw new Error('unlock_failed');"), 'failed API responses keep the report locked');
ok(html.includes("printBtn.hidden = false;"), 'successful API response unlocks the print action');
ok(html.includes("if (!unlocked) return;"), 'print handler checks unlock state');
ok(!html.includes('localStorage') && !html.includes('sessionStorage'), 'gate does not persist contact state in browser storage');

console.log('\nALL PASS — scorecard gate contract');
