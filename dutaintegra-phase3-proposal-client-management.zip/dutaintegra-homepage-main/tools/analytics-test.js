/* analytics-test.js — regression test for dutaintegra-homepage/analytics.js
 *
 *   node tools/analytics-test.js        (no browser, no dependencies)
 *
 * Runs the file against a stub DOM in a vm sandbox and asserts the behaviour
 * the homepage and the privacy notice depend on. Guards, in particular:
 *
 *   - transport ships as 'noop': no fetch() must be issued at all
 *   - calc_handoff fires on the #waCalc click, once — NOT on the sliders'
 *     'change' event, which fires on every mouse-up and reported slider
 *     fiddling as a qualified lead
 *   - attribution reads the URL and writes nothing: privacy.html §11 says the
 *     script "stores nothing in your browser", so no storage API may be used
 *   - no form field values appear in any event
 *
 * Exit code 0 = all assertions hold.
 */
'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');

const SRC = [
  path.resolve(__dirname, '..', 'public', 'analytics.js'),              // current repo layout
  path.resolve(__dirname, '..', 'analytics.js'),                        // tools/ inside site root
  path.resolve(__dirname, '..', 'dutaintegra-homepage', 'analytics.js'), // tools/ beside site dir
].find(p => fs.existsSync(p));

let fetchCalls = 0;
const results = [];
function assert(name, cond, detail) {
  results.push({ name, ok: !!cond, detail });
}

function el(tag, attrs) {
  const listeners = {};
  return Object.assign(
    {
      tagName: tag,
      listeners,
      value: '',
      textContent: '',
      classList: { contains: () => false },
      addEventListener(type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
      dispatch(type, ev) { (listeners[type] || []).forEach((fn) => fn(ev || { target: this })); },
      getAttribute(k) { return (attrs && attrs[k]) || null; },
      closest(sel) { return (attrs && attrs['data-matches'] && attrs['data-matches'].includes(sel)) ? this : null; }
    },
    attrs || {}
  );
}

const byId = {};
const rStaff = el('input', {});
const rHours = el('input', {});
const rSalary = el('input', {});
rStaff.value = '6'; rHours.value = '8'; rSalary.value = '3200';
const calculator = {
  querySelector: (sel) => ({ '#rStaff': rStaff, '#rHours': rHours, '#rSalary': rSalary }[sel] || null)
};
const waCalc = el('a', {});
byId.calculator = calculator;
byId.waCalc = waCalc;
byId.rStaff = rStaff; byId.rHours = rHours; byId.rSalary = rSalary;

const docListeners = {};
const documentStub = {
  addEventListener(type, fn) { (docListeners[type] = docListeners[type] || []).push(fn); },
  getElementById: (id) => byId[id] || null,
  querySelector: () => null,
  documentElement: { scrollHeight: 1000 }
};

const winListeners = {};
const sandbox = {
  document: documentStub,
  location: { pathname: '/index.html', search: '?ref=linkedin&utm_medium=social' },
  console,
  URLSearchParams,
  Object,
  Date,
  Math,
  setTimeout,
  clearTimeout,
  // Must never be called while transport is 'noop'.
  fetch: () => { fetchCalls++; return { catch() {} }; }
};
sandbox.window = Object.assign(sandbox, {
  innerHeight: 500,
  scrollY: 0,
  addEventListener(type, fn) { (winListeners[type] = winListeners[type] || []).push(fn); }
});
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(SRC, 'utf8'), sandbox, { filename: 'analytics.js' });

const events = () => sandbox.__di_events;
const click = docListeners.click[0];

function anchor(href, label) {
  const a = el('a', { href, 'data-matches': ['a[href]'] });
  a.textContent = label;
  return a;
}

(async () => {
  assert('window.__di_events exposed', Array.isArray(events()));

  // --- transport ---
  click({ target: anchor('https://wa.me/601154034051?text=Hi%20there', 'Book my audit') });
  assert('transport noop: no fetch() issued', fetchCalls === 0, `fetch calls = ${fetchCalls}`);

  // --- link classification ---
  let e = events();
  const wa = e[e.length - 1];
  assert('wa_click recorded', wa.event === 'wa_click', JSON.stringify(wa));
  assert('wa_click has prefilled message', wa.has_prefilled_message === true && wa.prefilled_length > 0, JSON.stringify(wa));

  click({ target: anchor('mailto:support@dutaintegra.my', 'Email us') });
  const last = events()[events().length - 1];
  assert('email_click recorded with address', last.event === 'email_click' && last.address === 'support@dutaintegra.my', JSON.stringify(last));

  // --- calc_engage: once per session ---
  rStaff.dispatch('input');
  rHours.dispatch('input');
  const engages = events().filter((x) => x.event === 'calc_engage');
  assert('calc_engage fires once across two sliders', engages.length === 1, `count = ${engages.length}`);
  assert('calc_engage names the first field', engages[0] && engages[0].first_field === '#rStaff', JSON.stringify(engages[0]));

  // --- the regression this file exists for ---
  rStaff.dispatch('change');
  rHours.dispatch('change');
  rSalary.dispatch('change');
  assert('slider change does not emit calc_handoff', events().filter((x) => x.event === 'calc_handoff').length === 0);

  waCalc.dispatch('click');
  waCalc.dispatch('click');
  const handoffs = events().filter((x) => x.event === 'calc_handoff');
  assert('calc_handoff fires on #waCalc click, deduped', handoffs.length === 1, `count = ${handoffs.length}`);
  assert(
    'calc_handoff carries calculator values',
    handoffs[0] && handoffs[0].staff === '6' && handoffs[0].hours_per_week === '8' && handoffs[0].salary === '3200',
    JSON.stringify(handoffs[0])
  );

  // --- attribution: read-only ---
  assert('__di_attribution() from URL', sandbox.__di_attribution() === 'linkedin', sandbox.__di_attribution());
  const storageKeys = Object.getOwnPropertyNames(sandbox).filter((k) => /storage/i.test(k));
  assert('no storage API touched', storageKeys.length === 0, storageKeys.join(','));

  const landed = events().filter((x) => x.event === 'landed_with_source');
  assert('landed_with_source recorded', landed.length === 1 && landed[0].source === 'linkedin', JSON.stringify(landed[0]));

  // --- form outcomes ---
  sandbox.__di_trackForm('success', { service: 'Managed IT' });
  sandbox.__di_trackForm('fallback', { reason: 'api_unreachable_or_forbidden' });
  sandbox.__di_trackForm('error', { reason: 'Please tell us your name.' });
  const forms = events().filter((x) => /^form_/.test(x.event)).map((x) => x.event);
  assert(
    'form outcomes map correctly',
    JSON.stringify(forms) === JSON.stringify(['form_submit', 'form_fallback', 'form_error']),
    JSON.stringify(forms)
  );

  // --- scroll depth ---
  sandbox.scrollY = 250; // 250/500 = 50%
  (winListeners.scroll || []).forEach((fn) => fn({}));
  await new Promise((r) => setTimeout(r, 400));
  const depths = events().filter((x) => x.event === 'scroll_depth').map((x) => x.depth);
  assert('scroll_depth crosses 25 and 50 in order, once each', JSON.stringify(depths) === JSON.stringify([25, 50]), JSON.stringify(depths));

  sandbox.scrollY = 500;
  (winListeners.scroll || []).forEach((fn) => fn({}));
  await new Promise((r) => setTimeout(r, 400));
  const depths2 = events().filter((x) => x.event === 'scroll_depth').map((x) => x.depth);
  assert('scroll_depth reaches 100 with no repeats', JSON.stringify(depths2) === JSON.stringify([25, 50, 75, 100]), JSON.stringify(depths2));

  // --- no PII leaves the page ---
  const bad = events().filter((x) => 'name' in x || 'email' in x || 'message' in x);
  assert('no form field values in any event', bad.length === 0, JSON.stringify(bad));

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.ok ? '' : '  → ' + r.detail}`);
  }
  console.log(failed ? `\n${failed} FAILURES` : `\nALL PASS — ${results.length}/${results.length}`);
  process.exit(failed ? 1 : 0);
})();
