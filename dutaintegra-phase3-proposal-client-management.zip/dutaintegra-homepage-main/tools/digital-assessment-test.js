'use strict';
const fs=require('fs');const path=require('path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'public','digital-assessment.html'),'utf8');
const js=fs.readFileSync(path.join(root,'public','digital-assessment.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public','digital-assessment.css'),'utf8');
const redirects=fs.readFileSync(path.join(root,'public','_redirects'),'utf8');
function ok(v,m){if(!v)throw new Error('FAIL '+m);console.log('ok    '+m);}
ok(html.includes('id="assessment-form"'),'assessment page includes a semantic form');
ok(js.includes("questions.length*4"),'score is normalised to 100');
ok(js.includes('Please rate all 8 statements'),'all questions must be answered');
ok(js.includes('escapeHtml(d.friction)'),'free-text business context is HTML-escaped');
ok(js.includes('window.print()'),'brief supports print / save as PDF');
ok(html.includes('Your answers are processed in this page'),'privacy boundary is disclosed');
ok(js.includes('wa.me/601154034051'),'proposal CTA links to Duta Integra WhatsApp');
ok(css.includes('@media print')&&css.includes('@media(max-width:640px)'),'print and mobile layouts are defined');
ok(redirects.includes('/digital-assessment       /digital-assessment       200'),'clean assessment route is configured');
console.log('\nALL PASS — Digital Assessment contract');
