/**
 * send-email-test.js — contract tests for functions/api/send-email.js.
 *
 * Run:  node tools/send-email-test.js     (exit 0 = all pass, no network)
 *
 * Guards the things that lose leads silently:
 *   1. method guard (405 on non-POST, matching the old backend)
 *   2. origin allowlist (403 on foreign Origin)
 *   3. server-side validation (400 on missing/invalid fields, consent hard-required)
 *   4. 503 when BREVO_API_KEY is absent (form falls back to WhatsApp, never hangs)
 *   5. Brevo request shape snapshot: endpoint, api-key header, sender/to/replyTo,
 *      PDPA consent timestamp, HTML-escaped user input (XSS probe)
 *   6. store-before-send ordering: KV put happens before the Brevo call
 *
 * The function is ESM (`export`) while this repo is CJS, so the test copies it
 * to a temp .mjs file and imports that — the tested bytes are the shipped file.
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

async function main() {
  const src = path.join(__dirname, '..', 'functions', 'api', 'send-email.js');
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'se-test-')), 'send-email.mjs');
  fs.copyFileSync(src, tmp);
  const { onRequest } = await import(pathToFileURL(tmp).href);

  const order = [];
  let calls = [];
  global.fetch = async (url, opts) => {
    order.push('fetch'); calls.push({ url, opts }); return { ok: true };
  };
  const kv = {
    put: async (key) => {
      // A successful request writes rate-limit state and then the lead.
      // Keep both writes visible so ordering checks target lead storage.
      order.push(key && key.startsWith('lead:') ? 'lead-kv' : 'rate-kv');
    },
  };
  const req = (method, body, origin, contentLength) => ({
    method,
    headers: { get: (k) => {
      if (k.toLowerCase() === 'origin') return origin === undefined ? 'https://dutaintegra.my' : origin;
      if (k.toLowerCase() === 'content-length') return contentLength == null ? null : String(contentLength);
      return null;
    } },
    json: async () => { if (body instanceof Error) throw body; return body; },
  });
  const env = {
    ALLOWED_ORIGINS: 'https://dutaintegra.my,https://www.dutaintegra.my',
    BREVO_API_KEY: 'xkeysib-TESTKEY',
    EMAIL_TO: 'support@dutaintegra.my',
    LEADS: kv,
  };
  const good = {
    name: 'Aina', email: 'aina@contoh.my', company: 'Contoh Sdn Bhd',
    phone: '012-3456789', service: 'Managed IT',
    message: 'Hello <script>alert(1)</script>', consent: true,
    source: 'direct', page: 'https://dutaintegra.my/',
  };

  /* ---- 1. method guard ---- */
  let r = await onRequest({ request: req('GET', null), env });
  check('GET -> 405', r.status === 405);
  check('405 body shape', (await r.json()).error === 'Method not allowed');

  /* ---- 2. origin allowlist ---- */
  r = await onRequest({ request: req('POST', good, 'https://evil.test'), env });
  check('foreign origin -> 403', r.status === 403);
  r = await onRequest({ request: req('POST', good, undefined), env: { ...env, ALLOWED_ORIGINS: '' } });
  check('empty origin allowlist -> 403', r.status === 403);
  r = await onRequest({ request: req('POST', good, null), env });
  check('missing Origin -> 403', r.status === 403);
  r = await onRequest({ request: req('POST', good, 'https://dutaintegra.my', 17 * 1024), env });
  check('oversized body -> 413', r.status === 413);
  r = await onRequest({ request: req('POST', good, 'https://www.dutaintegra.my'), env });
  check('apex + www origins pass gate', r.status === 200);

  /* ---- 3. validation ---- */
  const bad = [
    ['missing name', { ...good, name: '  ' }],
    ['bad email', { ...good, email: 'not-an-email' }],
    ['missing service', { ...good, service: '' }],
    ['missing message', { ...good, message: '' }],
    ['name too long', { ...good, name: 'A'.repeat(121) }],
    ['consent false', { ...good, consent: false }],
    ['consent absent', (({ consent, ...rest }) => rest)(good)],
    ['bad JSON', new Error('nope')],
  ];
  for (const [label, body] of bad) {
    r = await onRequest({ request: req('POST', body), env });
    check('400: ' + label, r.status === 400, 'got ' + r.status);
  }

  /* ---- 4. no key -> 503 ---- */
  r = await onRequest({ request: req('POST', good), env: { ...env, BREVO_API_KEY: '' } });
  check('missing key -> 503 (form falls back)', r.status === 503);

  /* ---- 5 + 6. snapshot + ordering ---- */
  calls = []; order.length = 0;
  r = await onRequest({ request: req('POST', good), env });
  check('happy path -> 200 {ok:true}', r.status === 200 && (await r.json()).ok === true);
  check('exactly one Brevo call', calls.length === 1);
  const sent = calls[0];
  check('Brevo endpoint', sent.url === 'https://api.brevo.com/v3/smtp/email');
  check('api-key header', sent.opts.headers['api-key'] === 'xkeysib-TESTKEY');
  const payload = JSON.parse(sent.opts.body);
  check('snapshot keys', JSON.stringify(Object.keys(payload).sort()) ===
    JSON.stringify(['htmlContent', 'replyTo', 'sender', 'subject', 'textContent', 'to']));
  check('to = EMAIL_TO', payload.to.length === 1 && payload.to[0].email === 'support@dutaintegra.my');
  check('replyTo = visitor', payload.replyTo.email === 'aina@contoh.my' && payload.replyTo.name === 'Aina');
  check('subject carries service + name',
    payload.subject.includes('Managed IT') && payload.subject.includes('Aina'));
  check('XSS escaped in html, raw in nothing',
    payload.htmlContent.includes('&lt;script&gt;') && !payload.htmlContent.includes('<script>'));
  check('consent timestamp recorded',
    /PDPA consent: yes \(.+\)/.test(payload.textContent));
  const leadStore = order.indexOf('lead-kv');
  const mailSend = order.indexOf('fetch');
  check(
    'lead stored BEFORE Brevo call',
    leadStore !== -1 && mailSend !== -1 && leadStore < mailSend,
    JSON.stringify(order)
  );

  console.log(fail === 0 ? `\nALL PASS — ${pass}/${pass}` : `\n${fail} FAILURES`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error('HARNESS ERROR', e); process.exit(1); });
