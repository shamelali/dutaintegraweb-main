/** Dependency-free checks for the client portal handoff. */
'use strict';
const fs = require('fs'); const path = require('path');
const root = path.resolve(__dirname, '..'); const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const html=read('public/client-portal.html'), css=read('public/client-portal.css'), redirects=read('public/_redirects'), headers=read('public/_headers'), homepage=read('public/index.html');
let pass=0,fail=0; function check(name,ok){if(ok){pass++;console.log('  ok    '+name)}else{fail++;console.log('  FAIL  '+name)}}
check('client portal page exists',fs.existsSync(path.join(root,'public/client-portal.html')));
check('portal excluded from indexing',/name="robots" content="noindex, nofollow"/.test(html));
check('portal has labelled main landmark',/<main id="main-content"/.test(html)&&/aria-labelledby="portal-title"/.test(html));
check('portal clearly explains Access-controlled sign-in',/secure sign-in policy/.test(html)&&/Open secure workspace/.test(html));
check('portal no longer pretends to send magic links',!/Email me a sign-in link/.test(html)&&!/<form id="portal-access-form"/.test(html));
check('portal does not collect credentials',!/<input[^>]+type="password"/i.test(html));
check('portal has support contact and legal links',/support@dutaintegra\.my/.test(html)&&/href="\/privacy"/.test(html)&&/href="\/terms"/.test(html));
check('portal clean route configured',/\/client-portal\s+\/client-portal\s+200/.test(redirects));
check('private workspace route configured',/\/workspace\s+\/workspace\s+200/.test(redirects));
check('portal and workspace are no-store/noindex',/\/client-portal[ \t]*\r?\n[ \t]+Cache-Control: no-store[ \t]*\r?\n[ \t]+X-Robots-Tag: noindex/.test(headers)&&/\/workspace[ \t]*\r?\n[ \t]+Cache-Control: no-store[ \t]*\r?\n[ \t]+X-Robots-Tag: noindex/.test(headers));
check('homepage links to client portal', (homepage.match(/href="\/client-portal"/g)||[]).length>=2);
check('portal stylesheet supports reduced motion',/prefers-reduced-motion: reduce/.test(css));
check('portal stylesheet has mobile layout',/@media \(max-width: 560px\)/.test(css));
console.log(''); if(fail){console.log(`FAIL — ${fail} failed, ${pass} passed`);process.exit(1)} console.log(`ALL PASS — ${pass}/${pass}`);
