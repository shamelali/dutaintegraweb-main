const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:703,height:1031}});
  const p=await c.newPage();
  await p.goto('file:///home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/'+process.argv[2],{waitUntil:'load'});
  await p.waitForTimeout(700); await p.emulateMedia({media:'print'}); await p.waitForTimeout(300);
  const m=await p.evaluate(()=>{
    const H=1031;
    const out=[];
    document.querySelectorAll('h2,h3,.sign,.foot,.note,.plain,table,.clock').forEach(e=>{
      const r=e.getBoundingClientRect();
      const top=Math.round(r.top+window.scrollY), bot=Math.round(r.bottom+window.scrollY);
      out.push({top,bot,pg:Math.floor(top/H)+1,endpg:Math.floor(bot/H)+1,
        tag:e.tagName.toLowerCase()+(e.className?'.'+String(e.className).split(' ')[0]:''),
        h:Math.round(r.height), txt:(e.textContent||'').trim().replace(/\s+/g,' ').slice(0,44)});
    });
    return out;
  });
  // show items whose height causes a page cross, plus the page 3-4 region
  m.forEach(r=>{
    if(r.endpg>r.pg) console.log(`  ⚠ SPANS p${r.pg}→p${r.endpg}  y=${r.top}  h=${r.h}  ${r.tag.padEnd(12)} ${r.txt}`);
  });
  console.log('\n  blocks in the p3/p4 boundary region (y 1900-3300):');
  m.filter(r=>r.top>1900&&r.top<3300).forEach(r=>{
    console.log(`    p${r.pg}  y=${String(r.top).padStart(5)} h=${String(r.h).padStart(4)}  ${r.tag.padEnd(12)} ${r.txt}`);
  });
  await b.close();
})();
