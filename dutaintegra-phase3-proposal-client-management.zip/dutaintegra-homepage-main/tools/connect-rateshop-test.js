#!/usr/bin/env node
/**
 * connect-rateshop-test.js — contract + drift checks for the /connect
 * rate-shopping widget.
 *
 * Run:  node tools/connect-rateshop-test.js     (exit 0 = all pass)
 *
 * Guards four things that are easy to break silently:
 *   1. the markup ships a no-JS fallback (server-rendered rows), so the
 *      section is still usable with JavaScript disabled
 *   2. every data-i18n key on /connect resolves to a BM value
 *   3. the illustrative rates in connect-rateshop.js match the canonical
 *      RATE_TABLE / ZONE_SURCHARGE in the DutaOS reference service
 *      (dutaos/repo/connect.py). The page and the API must never disagree
 *      about what "cheapest" means.
 *   4. the inline STR literals in connect-rateshop.js / rate-calculator.js
 *      keep EN/MS parity and basic BM hygiene — they sit outside every
 *      dictionary, so no other check sees them.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log('  ok    ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '  [' + detail + ']' : '')); }
}

const html = read('public/connect.html');
const js = read('public/connect-rateshop.js');
const engine = read('public/rates-engine.js');
const bmPage = read('public/bm/connect.js');
const bmChrome = read('public/bm/chrome.js');

/* ---- 1. progressive enhancement: a no-JS fallback must exist ------- */
const table = (html.match(/<div class="rs-table" id="rsTable">([\s\S]*?)<\/div>\s*<\/div>/) || [])[1] || '';
check('rate table has server-rendered fallback rows', (table.match(/rs-row/g) || []).length >= 5,
  (table.match(/rs-row/g) || []).length + ' rows');
check('fallback is not empty (usable without JS)', /Ninja Van/.test(table));
check('fallback shows RM figures', /RM\s*5\.85/.test(table) && /RM\s*9\.30/.test(table));
check('fallback outcome sentence present', /rsFallbackOut/.test(html));

/* ---- 2. honesty: must not present seeded data as live quotes ------ */
check('page labels the rates as illustrative', /rsDisclaimer/.test(html));
check('disclaimer says not live quotes', /not live quotes from the couriers/.test(html));
check('JS carries the same warning in a comment', /NOT LIVE CARRIER QUOTES/.test(engine));
check('rate logic is shared, not duplicated per page',
  /window\.DIRates/.test(js) && !/base:\s*4\.00/.test(js) && /base:\s*4\.00/.test(engine));
check('connect page loads the shared engine before the widget',
  /rates-engine\.js/.test(html) &&
  html.indexOf('/rates-engine.js') < html.indexOf('/connect-rateshop.js'));
check('no live-carrier claim on the pilot form',
  !/free trial|start free trial|50% off/i.test(html));

/* ---- 3. i18n coverage for /connect ------------------------------- */
const markupKeys = new Set([...html.matchAll(/data-i18n="([^"]+)"/g)].map((m) => m[1]));
const dictKeys = (src) => new Set([...src.matchAll(/^\s*([A-Za-z_]\w*)\s*:/gm)].map((m) => m[1]));
const bmKeys = new Set([...dictKeys(bmPage), ...dictKeys(bmChrome)]);
const missing = [...markupKeys].filter((k) => !bmKeys.has(k));
check('every /connect data-i18n key has a BM value', missing.length === 0, missing.join(', '));
check('rate-shop keys are translated', ['dcRsH2', 'rsZoneC', 'rsDisclaimer'].every((k) => bmKeys.has(k)));

/* ---- 3b. build-progress section must stay internally honest ------- */
const prog = (html.match(/<section class="sec" id="progress">([\s\S]*?)<\/section>/) || [])[1] || '';
check('progress section exists', prog.length > 0);
check('progress separates shipped / wip / not-started',
  /dcProgShipped/.test(prog) && /dcProgWip/.test(prog) && /dcProgTodo/.test(prog));
check('progress admits live courier feeds are NOT done',
  /Live courier rate feeds/.test(prog));
check('progress admits no price yet',
  /A published price, once the pilot/.test(prog));
check('progress admits courier agreements not started',
  /Courier partner agreements/.test(prog));
check('trial is listed under NOT started, never as shipped',
  prog.indexOf('Self-serve signup and a 14-day trial') > prog.indexOf('dcProgTodo'));
check('progress invites correction (feedback loop)',
  /updated as the work moves/.test(html));
const progKeys = [...prog.matchAll(/data-i18n="([^"]+)"/g)].map((m) => m[1]);
check('every progress key is translated', progKeys.every((k) => bmKeys.has(k)), progKeys.join(', '));

/* ---- 4. rate drift guard vs the DutaOS reference service ----------- */
// Canonical values, transcribed from dutaos/repo/connect.py.
const CANON = {
  'Ninja Van':     { base: 4.00, perKg: 1.25, days: 2, sur: { A: 0, B: 0.60, C: 4.00 } },
  'J&T Express':   { base: 4.20, perKg: 1.35, days: 3, sur: { A: 0, B: 0.50, C: 3.50 } },
  'Pos Laju':      { base: 4.50, perKg: 1.40, days: 3, sur: { A: 0, B: 0.40, C: 3.00 } },
  'DHL eCommerce': { base: 6.00, perKg: 2.10, days: 2, sur: { A: 0, B: 1.20, C: 6.50 } },
};
const etalon = path.join(root, '..', 'dutaos', 'repo', 'connect.py');
if (fs.existsSync(etalon)) {
  const py = fs.readFileSync(etalon, 'utf8');
  const drift = [];
  for (const [name, r] of Object.entries(CANON)) {
    const line = py.split('\n').find((l) => l.includes(`"${name}"`));
    if (!line) { drift.push(`${name}: absent from connect.py`); continue; }
    for (const [field, val] of [['base', r.base], ['per_kg', r.perKg]]) {
      const m = line.match(new RegExp(`${field}["']?\\s*:\\s*([\\d.]+)`));
      if (!m || Math.abs(parseFloat(m[1]) - val) > 1e-9) {
        drift.push(`${name}.${field}: py=${m ? m[1] : '?'} js=${val}`);
      }
    }
  }
  check('JS rates match connect.py RATE_TABLE', drift.length === 0, drift.join('; '));

  const zonesMatch = /ZONE_SURCHARGE/.test(py) && /"C":\s*3\.50/.test(py);
  check('connect.py still defines zone surcharges (zone is not dead)', zonesMatch);
} else {
  console.log('  skip  drift guard (dutaos/repo/connect.py not present here)');
}

/* ---- 5. functional parity spot-checks ---------------------------- */
// 1.0 kg, Zone B — the no-JS fallback row set.
function cost(r, w, z) {
  return Math.round((r.base + r.perKg * w + r.sur[z]) * 100) / 100;
}
check('1kg Zone B: Ninja Van is RM 5.85', cost(CANON['Ninja Van'], 1, 'B') === 5.85, String(cost(CANON['Ninja Van'], 1, 'B')));
check('1kg Zone B: DHL is RM 9.30', cost(CANON['DHL eCommerce'], 1, 'B') === 9.30);
check('1kg Zone B: spread is RM 3.45',
  Math.round((9.30 - 5.85) * 100) / 100 === 3.45);
// Zone C must flip the winner — this is the insight the widget exists to show.
const zoneC = Object.entries(CANON).map(([n, r]) => [n, cost(r, 1, 'C')]).sort((a, b) => a[1] - b[1]);
check('Zone C flips the cheapest courier to Pos Laju', zoneC[0][0] === 'Pos Laju', zoneC.map((x) => x.join(':')).join(' '));
check('Zone C costs more than Zone A', cost(CANON['Ninja Van'], 1, 'C') > cost(CANON['Ninja Van'], 1, 'A'));

/* ---- 6. public rate-calculator page -------------------------------- */
const calcHtml = read('public/connect-rate-calculator.html');
const calcJs = read('public/rate-calculator.js');
const calcBm = read('public/bm/connect-rate-calculator.js');
const redirects = read('public/_redirects');

check('calculator page exists and is a full document',
  calcHtml.includes('<!doctype html>') && calcHtml.trim().endsWith('</html>'));
check('calculator has the right canonical URL',
  /<link rel="canonical" href="https:\/\/dutaintegra\.my\/connect\/rate-calculator">/.test(calcHtml));
check('calculator meta description refuses to promise live rates',
  /not live quotes/.test(calcHtml));
check('calculator carries a visible not-live disclaimer',
  /rcDisclaimer/.test(calcHtml) && /not live quotes from the couriers/.test(calcHtml));
check('calculator disclaimer tells users not to book against it',
  /Do not book shipping against them/.test(calcHtml));
check('calculator has a no-JS fallback table',
  /id="rcTable"[\s\S]{0,600}Ninja Van[\s\S]{0,400}RM 5\.85/.test(calcHtml));
check('calculator FAQ admits the numbers are not live',
  /No, and we will not pretend otherwise/.test(calcHtml) && /rcA1/.test(calcHtml));
check('calculator does not claim a live trial or a price',
  !/free trial to sign up for(?! )/i.test(calcHtml.replace(/rcBandNote[^\n]*/, '')) || /rcBandNote/.test(calcHtml));
check('calculator has FAQPage JSON-LD',
  /"@type":\s*"FAQPage"/.test(calcHtml));
check('calculator has WebApplication JSON-LD',
  /"@type":\s*"WebApplication"/.test(calcHtml));
check('calculator JSON-LD answers the not-live question too',
  /illustrative reference rates/.test(calcHtml));
check('calculator loads the shared engine before its own script',
  /rates-engine\.js/.test(calcHtml) &&
  calcHtml.indexOf('/rates-engine.js') < calcHtml.indexOf('/rate-calculator.js'));
check('calculator logic does not re-declare the rate table',
  !/base:\s*4\.00/.test(calcJs) && /window\.DIRates/.test(calcJs));
check('calculator ships both zone columns and the flip row',
  /data-ladder="A"/.test(calcHtml) && /data-ladder="B"/.test(calcHtml) &&
  /data-ladder="C"/.test(calcHtml) && /lt-row flip/.test(calcHtml));
check('/connect/rate-calculator is routed as a real page',
  /^\/connect\/rate-calculator\s+\/connect-rate-calculator\s+200$/m.test(redirects));
check('sitemap includes the calculator',
  /<loc>https:\/\/dutaintegra\.my\/connect\/rate-calculator<\/loc>/.test(read('public/sitemap.xml')));
check('/connect links to the calculator',
  /href="\/connect\/rate-calculator"/.test(html));

// i18n coverage for the calculator page
const calcKeys = new Set([...calcHtml.matchAll(/data-i18n="([^"]+)"/g)].map((m) => m[1]));
const calcDict = new Set([
  ...[...calcBm.matchAll(/^\s*([A-Za-z_]\w*)\s*:/gm)].map((m) => m[1]),
  ...[...bmChrome.matchAll(/^\s*([A-Za-z_]\w*)\s*:/gm)].map((m) => m[1]),
]);
const calcMissing = [...calcKeys].filter((k) => !calcDict.has(k));
check('every calculator data-i18n key has a BM value', calcMissing.length === 0, calcMissing.join(', '));
check('calculator option values stay pinned to English',
  /<option value="A"/.test(calcHtml) && /<option value="B"/.test(calcHtml) && /<option value="C"/.test(calcHtml));
check('calculator does not write to browser storage',
  !/localStorage|sessionStorage/.test(calcJs));

/* ---- 5. inline STR objects: the BM strings no dictionary test sees ---- *
 * connect-rateshop.js and rate-calculator.js build their outcome sentences
 * from their own inline STR literals. They sit OUTSIDE every data-i18n
 * dictionary, so nothing else in the suite validates them — exactly where
 * the garbled "sebabnyaKwarta" token shipped unnoticed. These checks parse
 * both literals and assert EN/MS parity plus basic BM hygiene. */
function parseStr(src) {
  const m = src.match(/var STR = (\{[\s\S]*?\n  \});/);
  if (!m) return null;
  return new Function('return ' + m[1])();  // plain string literals only
}
for (const [file, src, flipKey, flipRe] of [
  ['public/connect-rateshop.js', js, 'east', /Sabah dan Sarawak/],
  ['public/rate-calculator.js', calcJs, 'zoneNote', /Zona C/],
]) {
  const STR = parseStr(src);
  check(file + ': inline STR with en and ms halves', Boolean(STR && STR.en && STR.ms));
  if (!STR || !STR.en || !STR.ms) continue;
  const enKeys = Object.keys(STR.en).sort();
  const msKeys = Object.keys(STR.ms).sort();
  check(file + ': STR en/ms key parity',
    enKeys.length === msKeys.length && enKeys.every((k, i) => k === msKeys[i]),
    enKeys.filter((k) => !msKeys.includes(k)).concat(msKeys.filter((k) => !enKeys.includes(k))).join(', '));
  const bad = Object.entries(STR.ms).filter(([, v]) =>
    typeof v !== 'string' || !v.trim() || v !== v.trim() ||
    / {2}/.test(v) || /[a-z][A-Z]/.test(v));
  check(file + ': every ms string is clean (non-empty, no double space, no glued token)',
    bad.length === 0, bad.map(([k]) => k).join(', '));
  check(file + ': ms ' + flipKey + ' carries the zone-flip message',
    typeof STR.ms[flipKey] === 'string' && flipRe.test(STR.ms[flipKey]),
    String(STR.ms[flipKey]).slice(0, 60));
}

console.log(fail ? `\nFAIL — ${fail} failed, ${pass} passed` : `\nALL PASS — ${pass}/${pass}`);
process.exit(fail ? 1 : 0);