#!/usr/bin/env node
/*
 * fonts-fetch.js — refresh the self-hosted Google Fonts subsets in public/fonts/
 *
 * The site no longer loads fonts from fonts.googleapis.com at runtime (that
 * stylesheet was render-blocking and added a third-party origin to the CSP).
 * Instead, the latin + latin-ext woff2 subsets are vendored into public/fonts/
 * and served same-origin via /fonts/fonts.css.
 *
 * Usage:  node tools/fonts-fetch.js          # re-download + regenerate fonts.css
 *         node tools/fonts-fetch.js --check  # verify files exist & match CSS refs
 *
 * Run this whenever you change the family/weight list, then commit the result.
 */
const fs = require('fs');
const path = require('path');
const https = require('https');

const DIR = path.join(__dirname, '..', 'public', 'fonts');
const CSS_URL = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap';
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';
const SUBSETS = new Set(['latin', 'latin-ext']);

function get(url, opts = {}) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': UA, ...opts.headers } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(get(res.headers.location, opts));
      }
      if (res.statusCode !== 200) return reject(new Error(`${url} -> ${res.statusCode}`));
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

async function main() {
  const checkOnly = process.argv.includes('--check');
  const css = (await get(CSS_URL)).toString();

  // Parse @font-face blocks with their preceding subset comment.
  const blocks = [...css.matchAll(/\/\* ([a-z-]+) \*\/\s*@font-face \{([\s\S]*?)\}/g)]
    .filter((m) => SUBSETS.has(m[1]))
    .map((m) => ({
      subset: m[1],
      fam: /font-family: '([^']+)'/.exec(m[2])[1],
      style: /font-style: (\w+)/.exec(m[2])[1],
      weight: /font-weight: (\d+)/.exec(m[2])[1],
      url: /url\((https:\/\/[^)]+\.woff2)\)/.exec(m[2])[1],
      unicodeRange: /unicode-range: ([^;]+);/.exec(m[2])[1],
    }));
  if (!blocks.length) throw new Error('no latin blocks parsed — Google may have changed the CSS format');

  // Dedupe identical upstream files (variable fonts reuse one file across weights).
  const fileByUrl = new Map();
  for (const b of blocks) {
    if (!fileByUrl.has(b.url)) fileByUrl.set(b.url, `${b.fam.replace(/ /g, '')}-${b.weight}-${b.subset}`.toLowerCase() + '.woff2');
  }

  const out = [`/* Self-hosted Inter & Space Grotesk (latin + latin-ext subsets).`,
    `   Replaces the render-blocking Google Fonts stylesheet — run`,
    `   \`node tools/fonts-fetch.js\` to refresh these files from upstream.`,
    `   Inter and Space Grotesk are variable fonts: one woff2 file per subset`,
    `   serves all weights via separate @font-face rules with unicode-range. */`, ``];
  const seenRule = new Set();
  for (const b of blocks) {
    const fname = fileByUrl.get(b.url);
    const sig = `${b.fam}|${b.style}|${b.weight}|${fname}|${b.unicodeRange}`;
    if (seenRule.has(sig)) continue;
    seenRule.add(sig);
    out.push(`@font-face{`,
      `  font-family:'${b.fam}';font-style:${b.style};font-weight:${b.weight};`,
      `  font-display:swap;`,
      `  src:url('/fonts/${fname}') format('woff2');`,
      `  unicode-range:${b.unicodeRange};`,
      `}`, ``);
  }
  const newCss = out.join('\n').trimEnd() + '\n';

  if (checkOnly) {
    let fail = 0;
    const want = new Set(fileByUrl.values());
    for (const f of want) {
      if (!fs.existsSync(path.join(DIR, f))) { console.error(`MISSING ${f}`); fail++; }
    }
    const cur = fs.existsSync(path.join(DIR, 'fonts.css')) ? fs.readFileSync(path.join(DIR, 'fonts.css'), 'utf8') : '';
    if (cur.trim() !== newCss.trim()) { console.error('DRIFT: public/fonts/fonts.css differs from upstream — run `node tools/fonts-fetch.js`'); fail++; }
    console.log(fail ? `fonts-fetch --check FAILED (${fail})` : `fonts-fetch --check ok (${want.size} files referenced)`);
    process.exit(fail ? 1 : 0);
  }

  fs.mkdirSync(DIR, { recursive: true });
  for (const [url, fname] of fileByUrl) {
    const buf = await get(url);
    if (!buf.slice(0, 4).equals(Buffer.from('wOF2'))) throw new Error(`${fname} is not a woff2 file`);
    fs.writeFileSync(path.join(DIR, fname), buf);
    console.log(`wrote public/fonts/${fname} (${buf.length} bytes)`);
  }
  fs.writeFileSync(path.join(DIR, 'fonts.css'), newCss);
  console.log(`wrote public/fonts/fonts.css (${fileByUrl.size} unique files, ${blocks.length} faces)`);
}

main().catch((e) => { console.error('fonts-fetch failed:', e.message); process.exit(1); });
