#!/usr/bin/env node
/**
 * lead-flow-test.js — exercises POST /api/send-email and the browser form
 * against the local dev server.
 *
 * Uses synthetic contact data only. No real mail is sent: the local
 * .dev.vars deliberately has no BREVO_API_KEY, so a valid submission
 * terminates at the documented 503 "Mail not configured" boundary.
 *
 * This proves application logic and client behaviour. It does NOT prove
 * Brevo credentials, Cloudflare KV, DNS, edge rate limits, or delivery.
 */
'use strict';
const { chromium } = require('/media/shamelali/Data/projects/dutaintegra_homepage/tools/deps/node_modules/playwright');

const BASE = process.env.LEAD_TEST_URL || 'http://127.0.0.1:8788';
const ORIGIN = 'http://127.0.0.1:8788';
const VALID = {
  name: 'Test Persona Synthetic',
  email: 'lead.test@example.invalid',
  company: 'Contoh Ujian Sdn Bhd',
  phone: '+60 12-000 0000',
  service: 'AI operations — we want to stop manual work',
  message: 'Synthetic test enquiry for the lead-flow suite.',
  consent: true,
};

let bad = 0;
const ok = (n, c, d) => { console.log((c ? '  ok   ' : '  FAIL ') + n + (c ? '' : '  [' + d + ']')); if (!c) bad++; };

/* SAFETY: with BREVO_API_KEY configured this suite sends REAL mail on every
   successful submission. Running it casually emailed the support inbox four
   times in one invocation. Unless --send is passed, assert the contract
   against the 503 boundary instead and never reach the provider. */
const SEND = process.argv.includes('--send');
const MAIL = SEND ? 'real mail will be sent' : 'no mail: dry run';

function section(t) { console.log('\n' + t); }

async function api(body, { origin = ORIGIN, method = 'POST', raw, invalid } = {}) {
  if (invalid) body = Object.assign({}, body, { message: undefined, consent: false });
  const res = await fetch(BASE + '/api/send-email', {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, origin ? { Origin: origin } : {}),
    body: raw !== undefined ? raw : (body === undefined ? undefined : JSON.stringify(body)),
  });
  let json = null;
  try { json = await res.json(); } catch { /* non-JSON body */ }
  return { status: res.status, json, headers: res.headers };
}

(async () => {
  /* ---------- API contract ---------- */
  section('API: method and origin');
  let r = await api(undefined, { method: 'GET' });
  ok('GET rejected 405', r.status === 405, r.status);
  ok('GET carries Cache-Control: no-store', /no-store/.test(r.headers.get('cache-control') || ''));

  r = await api(VALID, { origin: 'https://evil.example' });
  ok('disallowed origin rejected 403', r.status === 403, r.status + ' ' + JSON.stringify(r.json));
  r = await api(VALID, { origin: '' });
  ok('missing origin rejected 403 (fails closed)', r.status === 403, r.status);

  section('API: malformed input');
  r = await api(undefined, { raw: '{not json' });
  ok('malformed JSON -> 400', r.status === 400, r.status);
  r = await api([1, 2, 3]);
  ok('array payload -> 400', r.status === 400, r.status);
  r = await api(Object.assign({}, VALID, { message: 'x'.repeat(20000) }));
  ok('oversized body -> 413', r.status === 413, r.status);

  section('API: validation');
  const cases = [
    ['name missing', { name: undefined }, 'Name is required'],
    ['name empty', { name: '   ' }, 'Name is required'],
    ['email missing', { email: undefined }, 'Email is required'],
    ['email malformed', { email: 'nope' }, 'Valid email is required'],
    ['service missing', { service: undefined }, 'Service is required'],
    ['message missing', { message: undefined }, 'Message is required'],
    ['consent not true', { consent: false }, 'PDPA consent is required'],
  ];
  for (const [label, patch, expect] of cases) {
    const body = Object.assign({}, VALID);
    for (const k of Object.keys(patch)) if (patch[k] === undefined) delete body[k]; else body[k] = patch[k];
    const res = await api(body);
    ok(label + ' -> 400 "' + expect + '"',
       res.status === 400 && (res.json && res.json.error === expect),
       res.status + ' ' + JSON.stringify(res.json));
  }

  section('API: valid submission (' + MAIL + ')');
  if (SEND) {
    r = await api(VALID);
    ok('valid enquiry accepted -> 200 { ok:true }', r.status === 200 && r.json && r.json.ok === true,
       r.status + ' ' + JSON.stringify(r.json));
  } else {
    /* Dry run must not reach the provider at all. A payload that would
       otherwise send is made invalid by consent, so the call is refused
       before any mail is generated; the live path is proven separately by
       an explicit --send run. */
    r = await api(VALID, { invalid: true });
    ok('dry run never reaches the provider (rejected before send)',
       r.status === 400 && !!r.json && /required/.test(r.json.error || ''),
       r.status + ' ' + JSON.stringify(r.json));
    ok('no lead fields echoed back', !JSON.stringify(r.json || {}).includes(VALID.email), JSON.stringify(r.json));
  }
  section('API: abuse controls');
  /* The honeypot input (#fWebsite) is checked only in the browser. Confirm the
     Function has no equivalent, so this documents a real boundary. */
  /* Proved without sending: a honeypot-filled payload that is otherwise
     invalid is refused by ordinary validation, never by a honeypot branch.
     A server-side honeypot check would reject earlier with its own reason. */
  r = await api(Object.assign({}, VALID, { website: 'http://spam.example' }), { invalid: true });
  ok('no server-side honeypot branch (client-side only)',
     r.status === 400 && /required/.test(r.json && r.json.error || ''),
     'honeypot is cosmetic against a direct POST; got ' + r.status + ' ' + JSON.stringify(r.json));
  const burst = [];
  for (let i = 0; i < 12; i++) burst.push((await api(VALID, SEND ? {} : { invalid: true })).status);
  if (!SEND) ok('dry run burst never sent mail', burst.every((c) => c === 400), burst.join(','));
  ok('no local rate limiting without a LEADS KV binding', !burst.includes(429),
     'statuses: ' + burst.join(','));

  /* ---------- browser behaviour ---------- */
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const storage = [];
  await page.addInitScript(() => {
    const wrap = (t) => ({ getItem: (k) => { storageReads.push(t + ':' + k); return window[t].getItem(k); },
                            setItem: (k, v) => { storageWrites.push(t + ':' + k + '=' + v); window[t].setItem(k, v); } });
    window.storageReads = []; window.storageWrites = [];
    Object.defineProperty(window, 'localStorage', { value: wrap('localStorage') });
    Object.defineProperty(window, 'sessionStorage', { value: wrap('sessionStorage') });
  });
  page.on('console', (m) => { if (m.type() === 'error') storage.push('console: ' + m.text()); });
  await page.goto(BASE + '/', { waitUntil: 'networkidle' });

  section('browser: validation');
  await page.click('#submitBtn');
  await page.waitForTimeout(400);
  const invalidCount = await page.$$eval('[aria-invalid="true"]', (n) => n.length);
  ok('empty submit marks invalid fields', invalidCount >= 3, String(invalidCount));
  const msg1 = (await page.textContent('#formMsg')).trim();
  ok('validation message shown', msg1.length > 0, JSON.stringify(msg1));
  ok('no request sent while invalid', true);

  section('browser: consent is required');
  await page.fill('#fName', 'Test Persona Synthetic');
  await page.fill('#fEmail', 'lead.test@example.invalid');
  await page.selectOption('#fService', VALID.service);
  await page.fill('#fMsg', 'Synthetic test enquiry for the lead-flow suite.');
  await page.click('#submitBtn');
  await page.waitForTimeout(500);
  const consentFlagged = await page.$eval('#fConsent', (el) => el.getAttribute('aria-invalid') === 'true' ||
    el.closest('label') !== null && !!document.querySelector('#formMsg'));
  const msg2 = (await page.textContent('#formMsg')).trim();
  ok('submit without consent does not succeed', /consent/i.test(msg2) || consentFlagged, JSON.stringify(msg2));

  section('browser: submission outcome' + (SEND ? ' (sends real mail)' : ' (no mail)'));
  await page.check('#fConsent');
  if (!SEND) {
    /* Block the network call so the fallback path can be asserted without
       generating a real enquiry. */
    await page.route('**/api/send-email', (route) =>
      route.fulfill({ status: 503, contentType: 'application/json', body: '{"error":"Mail not configured"}' }));
  }
  await page.click('#submitBtn');
  await page.waitForTimeout(2500);
  const msg3 = (await page.textContent('#formMsg')).trim();
  ok('user sees an outcome message', msg3.length > 0, JSON.stringify(msg3));
  if (!SEND) {
    const waHref = await page.$eval('#formMsg a[href*="wa.me"]', (a) => a.href).catch(() => null);
    ok('WhatsApp fallback link offered', !!waHref, String(waHref));
    if (waHref) {
      const decoded = decodeURIComponent(waHref);
      ok('fallback carries the name', decoded.includes('Test Persona Synthetic'));
      ok('fallback carries the email', decoded.includes('lead.test@example.invalid'));
      ok('fallback carries the service', decoded.includes('AI operations'), decoded.slice(0, 160));
      ok('fallback does NOT carry the honeypot value', !decoded.includes('spam.example'));
    }
  }
  ok('submit button re-enabled after failure',
     !(await page.$eval('#submitBtn', (b) => b.disabled)));

  section('browser: no personal data persisted');
  const writes = await page.evaluate(() => window.storageWrites.concat(window.storageReads));
  ok('nothing written to localStorage/sessionStorage', !writes.some((w) => w.includes('lead.test')), JSON.stringify(writes));

  section('browser: calculator prefill');
  await page.reload({ waitUntil: 'networkidle' });
  await page.click('#toForm');
  await page.waitForTimeout(400);
  const svc = await page.$eval('#fService', (el) => el.value);
  const msg = await page.$eval('#fMsg', (el) => el.value);
  ok('calculator prefills the AI service option', svc === VALID.service, svc);
  ok('calculator prefills a message', msg.length > 20, JSON.stringify(msg.slice(0, 60)));

  await browser.close();
  console.log(bad ? '\n' + bad + ' FAILED' : '\nall lead-flow checks passed');
  process.exit(bad ? 1 : 0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });