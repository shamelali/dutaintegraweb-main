'use strict';
const fs=require('fs'),path=require('path'); const root=path.resolve(__dirname,'..'); const read=(p)=>fs.readFileSync(path.join(root,p),'utf8'); let pass=0,fail=0;
function check(n,v){if(v){pass++;console.log('  ok    '+n)}else{fail++;console.log('  FAIL  '+n)}}
const html=read('public/workspace.html'),js=read('public/workspace.js'),css=read('public/workspace.css'),api=read('functions/api/workspace/[[path]].js'),auth=read('functions/_lib/workspace-auth.js'),sql=read('migrations/0002_workspace.sql'),redirects=read('public/_redirects'),headers=read('public/_headers'),pkg=JSON.parse(read('package.json'));
check('workspace HTML/CSS/JS present',fs.existsSync(path.join(root,'public/workspace.html'))&&fs.existsSync(path.join(root,'public/workspace.css'))&&fs.existsSync(path.join(root,'public/workspace.js')));
check('workspace is noindex',/name="robots" content="noindex, nofollow"/.test(html));
check('workspace uses API rather than localStorage for records',/fetch\(`\/api\/workspace/.test(js)&&!/localStorage|sessionStorage/.test(js));
check('workspace supports leads/proposals/projects',/id="lead-form"/.test(html)&&/id="proposal-form"/.test(html)&&/id="project-form"/.test(html)&&/id="projects-list"/.test(html));
check('API uses parameterised SQL and bounded body size',/MAX_BODY = 12 \* 1024/.test(api)&&/\.bind\(/.test(api));
check('API checks role and client organisation scope',/Staff access required/.test(api)&&/proposal\.organization_id !== user\.organization_id/.test(api)&&/WHERE organization_id=\?/.test(api));
check('client can only accept/decline sent proposals',/proposal\.status !== 'sent'/.test(api)&&/\['accepted','declined'\]\.includes\(status\)/.test(api));
check('Access JWT signature, issuer, audience and expiry verified',/crypto\.subtle\.verify/.test(auth)&&/payload\.iss !== issuer/.test(auth)&&/payload\.aud\.includes\(env\.CF_ACCESS_AUD\)/.test(auth)&&/payload\.exp <= now/.test(auth));
check('D1 schema includes users, leads, proposals, projects and audit log', ['workspace_users','leads','proposals','projects','workspace_audit_log'].every(t=>sql.includes(`CREATE TABLE IF NOT EXISTS ${t}`)));
check('workspace route configured',/\/workspace\s+\/workspace\s+200/.test(redirects));
check('workspace response has no-store and noindex headers',/\/workspace[ \t]*\r?\n[ \t]+Cache-Control: no-store[ \t]*\r?\n[ \t]+X-Robots-Tag: noindex/.test(headers)&&/\/api\/\*[ \t]*\r?\n[ \t]+Cache-Control: no-store/.test(headers));
check('phase 3 setup guide documents Access + D1 provisioning',/Cloudflare Access/.test(read('docs/PHASE-3-PROPOSAL-CLIENT-MANAGEMENT.md'))&&/D1/.test(read('docs/PHASE-3-PROPOSAL-CLIENT-MANAGEMENT.md')));
check('workspace test included in npm test',pkg.scripts.test.includes('workspace-test.js'));
console.log('');if(fail){console.log(`FAIL — ${fail} failed, ${pass} passed`);process.exit(1)}console.log(`ALL PASS — ${pass}/${pass}`);
