const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:703,height:1031}});
  const p=await c.newPage();
  await p.goto('file:///home/user/dutaintegra-homepage/pdpa-starter-pack/client-pack/'+process.argv[2],{waitUntil:'load'});
  await p.waitForTimeout(700);
  await p.emulateMedia({media:'print'});
  await p.waitForTimeout(300);
  const m=await p.evaluate(()=>{
    const H=1031; // A4 content height at 10mm margins, 96dpi
    const total=document.body.scrollHeight;
    const els=[...document.querySelectorAll('h2,.sign,.foot,table,.note,.plain,.clock')];
    const rows=els.map(e=>{
      const r=e.getBoundingClientRect();
      return {t:Math.round(r.top+window.scrollY), b:Math.round(r.bottom+window.scrollY),
              tag:e.tagName.toLowerCase()+(e.className?'.'+String(e.className).split(' ')[0]:''),
              txt:(e.textContent||'').trim().slice(0,38)};
    });
    const sign=rows.find(r=>r.tag==='div.sign');
    return {total, pages:+(total/H).toFixed(2), H, sign, tail:rows.slice(-6)};
  });
  console.log('  total content height:', m.total, 'px  =', m.pages, 'pages of', m.H);
  console.log('  pages needed (ceil):', Math.ceil(m.total/m.H));
  console.log('  overflow into last page:', m.total % m.H, 'px');
  console.log('\n  final blocks:');
  m.tail.forEach(r=>{
    const pg=Math.floor(r.t/m.H)+1;
    console.log(`    p${pg}  y=${String(r.t).padStart(5)}  ${r.tag.padEnd(14)} ${r.txt}`);
  });
  await b.close();
})();
