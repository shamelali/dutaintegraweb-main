const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({args:['--no-sandbox','--disable-dev-shm-usage']});
  const c=await b.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  const p=await c.newPage();
  await p.goto('http://127.0.0.1:8080/',{waitUntil:'networkidle'});
  await p.waitForTimeout(1200);

  const r=await p.evaluate(()=>{
    const parse=c=>{const n=(c.match(/[\d.]+/g)||[]).map(Number);if(n.length<3)return null;return {r:n[0],g:n[1],b:n[2],a:n.length>3?n[3]:1}};
    const unflat=cs=>{const bi=cs.backgroundImage;return !!bi&&bi!=='none'&&(bi.indexOf('gradient')>-1||bi.indexOf('url(')>-1)};
    // Composite every translucent layer down the ancestor chain. The previous
    // maths read only the RGB digits and ignored alpha, so a 7% tint over a
    // dark card was scored as fully opaque and produced false failures.
    const bgOf=el=>{
      const layers=[];let e=el;
      while(e&&e!==document.documentElement){
        const cs=getComputedStyle(e);
        if(unflat(cs)) return null;               // gradient/url-backed: needs pixel sampling
        const c=parse(cs.backgroundColor);
        if(c&&c.a>0){layers.push(c);if(c.a>=1)break;}
        e=e.parentElement;
      }
      if(!layers.length) return {r:255,g:255,b:255,a:1};
      let out=layers[layers.length-1];
      for(let i=layers.length-2;i>=0;i--){
        const t=layers[i],a=t.a;
        out={r:Math.round(t.r*a+out.r*(1-a)),g:Math.round(t.g*a+out.g*(1-a)),b:Math.round(t.b*a+out.b*(1-a)),a:1};
      }
      return out;
    };
    const lum=c=>{const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(c.r)+.7152*f(c.g)+.0722*f(c.b)};
    const contrast=(fg,bg)=>{const a=lum(fg),b=lum(bg);return ((Math.max(a,b)+.05)/(Math.min(a,b)+.05)).toFixed(2)};

    // 1. small tap targets
    const small=[];
    document.querySelectorAll('a,button,[role=button],input[type=checkbox],select').forEach(el=>{
      const r=el.getBoundingClientRect();
      if(r.width===0||r.height===0) return;
      if(r.height<40||r.width<40){
        small.push({t:el.tagName.toLowerCase(),txt:(el.textContent||el.getAttribute('aria-label')||el.type||'').trim().slice(0,34),
          w:Math.round(r.width),h:Math.round(r.height)});
      }
    });

    // 2. low-contrast text
    const low=[];
    document.querySelectorAll('p,span,li,a,small,div,label,h1,h2,h3,h4').forEach(el=>{
      if(el.children.length) return;
      const t=(el.textContent||'').trim();
      if(t.length<3) return;
      const cs=getComputedStyle(el);
      if(cs.display==='none'||cs.visibility==='hidden'||parseFloat(cs.opacity)<.5) return;
      const fs=parseFloat(cs.fontSize);
      const bg=bgOf(el);
      if(!bg) return;                    // gradient/url-backed: needs pixel sampling
      const fgRaw=parse(cs.color)||{r:0,g:0,b:0,a:1};
      const fg={r:Math.round(fgRaw.r*fgRaw.a+bg.r*(1-fgRaw.a)),
                g:Math.round(fgRaw.g*fgRaw.a+bg.g*(1-fgRaw.a)),
                b:Math.round(fgRaw.b*fgRaw.a+bg.b*(1-fgRaw.a))};
      const ratio=parseFloat(contrast(fg,bg));
      const need=(fs>=18||(fs>=14&&parseInt(cs.fontWeight)>=700))?3:4.5;
      if(ratio<need) low.push({txt:t.slice(0,38),ratio,fs:Math.round(fs),need});
    });

    // 3. form label coverage
    const bad=[];
    document.querySelectorAll('input:not([type=hidden]),select,textarea').forEach(el=>{
      const id=el.id, hasLbl=!!document.querySelector(`label[for="${id}"]`),
            wrap=el.closest('label'), aria=el.getAttribute('aria-label');
      if(!hasLbl&&!wrap&&!aria) bad.push(el.name||el.id||el.type);
    });

    // 4. images without alt
    const noalt=[...document.querySelectorAll('img')].filter(i=>!i.hasAttribute('alt')).length;

    return {small, low, bad, noalt, h1:document.querySelectorAll('h1').length};
  });

  console.log('TAP TARGETS < 40px:', r.small.length);
  r.small.slice(0,12).forEach(x=>console.log(`   ${x.t} ${x.w}x${x.h}  "${x.txt}"`));
  console.log('\nLOW CONTRAST:', r.low.length);
  const seen=new Set();
  r.low.forEach(x=>{const k=x.ratio+'|'+Math.round(x.fs); if(!seen.has(k)){seen.add(k);console.log(`   ratio ${x.ratio} (need ${x.need}) @${x.fs}px  "${x.txt}"`)}});
  console.log('\nUNLABELLED FIELDS:', r.bad.length, r.bad.join(', ')||'none');
  console.log('IMAGES MISSING ALT:', r.noalt);
  console.log('<h1> COUNT:', r.h1, r.h1===1?'(correct)':'⚠');
  await b.close();
})();
