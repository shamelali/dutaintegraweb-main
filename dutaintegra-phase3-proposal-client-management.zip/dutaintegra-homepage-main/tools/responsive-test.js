#!/usr/bin/env node
/**
 * responsive-test.js — asserts nothing overflows horizontally at any width.
 *
 * Both the homepage and services.css set body{overflow-x:hidden} in places and
 * use grid without min-width:0, so an over-wide child is *clipped* rather than
 * scrollable and the failure is invisible in a screenshot taken at desktop
 * width. This sweeps real widths and measures the DOM.
 *
 * Run with the dev server up:  npm run test:responsive
 */
'use strict';
const { chromium } = require('/media/shamelali/Data/projects/dutaintegra_homepage/tools/deps/node_modules/playwright');

const BASE = process.env.RESP_TEST_URL || 'http://127.0.0.1:8788';
// The 404 page is included on purpose. It is the only page that is served by
// a status code rather than a file, and it is reached by people who already
// have the wrong thing on screen, so a horizontal scrollbar there costs more
// than elsewhere. It is exercised through a path that deliberately 404s.
const MISSING_ROUTE = '/__no-such-page__';
const PAGES = ['/', '/ai-operations', '/managed-it', '/security-pdpa', '/websites', MISSING_ROUTE];
const WIDTHS = [320, 360, 390, 414, 768, 1280];

let bad = 0;
const ok = (n, c, d) => { console.log((c ? '  ok   ' : '  FAIL ') + n + (c ? '' : '  [' + d + ']')); if (!c) bad++; };

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  for (const route of PAGES) {
    console.log('\n' + route);
    for (const width of WIDTHS) {
      const page = await browser.newPage({ viewport: { width, height: 800 } });
      const errs = [];
      page.on('pageerror', (e) => errs.push(e.message));
      await page.goto(BASE + route, { waitUntil: 'networkidle' });
      await page.waitForTimeout(400);
      const r = await page.evaluate(() => {
        const W = document.documentElement.clientWidth;
        const over = [...document.querySelectorAll('body *')].filter((e) => {
          const b = e.getBoundingClientRect();
          return b.width > 0 && b.right > W + 1;
        });
        return {
          count: over.length,
          hScroll: document.documentElement.scrollWidth - W,
          offenders: over.slice(0, 3).map((e) => e.tagName + '.' + String(e.className).slice(0, 24) +
            '@' + Math.round(e.getBoundingClientRect().right)),
        };
      });
      ok(width + 'px: no horizontal overflow', r.count === 0 && r.hScroll <= 0,
         r.count + ' element(s), h-scroll ' + r.hScroll + 'px ' + r.offenders.join(', '));
      ok(width + 'px: no JS errors', errs.length === 0, errs.join(' | '));
      await page.close();
    }
  }
  await browser.close();
  console.log(bad ? '\n' + bad + ' FAILED' : '\nall responsive checks passed');
  process.exit(bad ? 1 : 0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });