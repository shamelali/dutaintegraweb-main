# Outreach pack — Malaysian SME IT & automation

**Why this exists:** a great homepage cannot convert visitors who never arrive. If your traffic is near zero, the site isn't the bottleneck — distribution is. This is the distribution plan, plus the copy to run it.

---

## Read this first: your WhatsApp number is a business asset

You will be tempted to send cold WhatsApp messages at volume. **Don't.**

Meta bans numbers for unsolicited bulk messaging, and it bans them permanently. Your `+60 11-5403 4051` line is on your homepage, your footer, your scorecard and your email signature. Losing it to a spam report is a business-critical failure, and appeals rarely succeed.

The rules that keep the number safe:

- **No bulk sends.** If you're pasting the same message into more than ~5 chats a day, you're on the path to a ban.
- **Never** paste a message into a chat where there's no prior human contact.
- **Always** personalise the first line. A message that could have been sent to anyone reads as spam to a human *and* to Meta's systems.
- **Honour "no" instantly** and don't follow up. One polite message, one polite exit.
- **Get introduced where you can.** A forwarded introduction from a mutual contact converts better than 50 cold messages and carries zero ban risk.

**The order that actually works:** community → LinkedIn → warm intro → WhatsApp *after* they've engaged with you once. Not the reverse.

---

## 1. Who to target

Pick one segment and go deep. Spraying across industries is how you get a 0.5% reply rate and conclude "outbound doesn't work."

**Your best-fit profile:**

| Attribute | Target |
|---|---|
| Headcount | 10–50 staff |
| Location | Johor Bahru, Klang Valley, Penang (start with JB — you're in Johor) |
| Sectors | Logistics & freight, manufacturing, trading & distribution, professional services (accounting, legal, engineering), private healthcare & dental, education centres, retail with 3+ outlets |
| Trigger | They have 1–2 "IT people" who are actually doing something else |
| Signal | They advertise on job boards for an "IT Executive" (they're feeling the pain *right now*) |
| Signal | They recently won a contract with a larger client who imposed compliance requirements |

**Disqualify fast:** under 5 staff (can't afford it), over 150 (you'll lose to an incumbent), and anyone who says "we already have a guy" *and* can't name what that guy does weekly.

**Where to find them:**
- **Job boards** — search "IT Executive", "IT Support", "Admin Executive" at SME-sized Malaysian companies. A company hiring for this is actively in pain. This is your single best source.
- **SSM / company directories** — filter by sector and size, build a list of 50.
- **Local chambers** — JB Chinese Chamber, Malay Chamber of Commerce (DPMM), Indian Chamber, SME Association of Malaysia (SAMENTA), MDEC/ Cyberjaya networks. Rotary, Lions, BNI chapters in JB and Klang Valley.
- **Industry WhatsApp and Telegram groups** — logistics, manufacturing, F&B operators. Join, be useful, don't pitch.
- **LinkedIn** — search by title: *Operations Manager*, *Finance Manager*, *Managing Director*, *Admin Manager* at 11–50 employee companies in Malaysia. These are the people who feel admin pain, not "Head of IT" (you'll be talking to your competitor).

---

## 2. The offer that opens doors

Don't lead with a service. Lead with the **free IT audit** — it's the most valuable thing you have and it costs you a few hours.

Specifically: **"I'll spend an hour on your setup and send you a written one-pager: the three things worth fixing now, roughly what they'd cost, and what I'd leave alone."**

That is a real deliverable (use `audit-scorecard.html` as the framework), it demonstrates competence rather than asserting it, and it gives the prospect something even if they never buy. It also filters hard — someone who won't give you an hour isn't going to buy managed IT.

---

## 3. Cold email

Send from your own address, plain text, no HTML template, no tracking pixel, no attachments on the first touch. One CTA, framed as low-commitment.

> **Subject:** IT at [Company] — or: the IT Executive role you're advertising
>
> Hi [Name],
>
> I saw [Company] is hiring an IT Executive. That usually means the day-to-day has outgrown whoever's been covering it — which is the stage we work with most.
>
> I run Duta Integra, a Cyberjaya-based IT and automation firm. We handle infrastructure and security for SMEs, plus automation for the repetitive admin work.
>
> Happy to do a free one-hour review of your setup and send you a written one-pager: three things worth fixing now, roughly what they'd cost, and what I'd leave alone. No obligation, and it's yours to keep either way.
>
> Worth a look?
>
> [Your name]
> Duta Integra Solutions
> +60 11-5403 4051 · support@dutaintegra.my · dutaintegra.my

**Why this works:** the first line proves you looked. The offer is time-boxed and specific. "Yours to keep either way" removes the fear of being captured by a sales process.

**If the job-ad hook doesn't apply**, use one of these openers instead:
- *"I noticed [Company] has been expanding — three outlets now?"* (only if true)
- *"Your site's contact form doesn't have a PDPA consent notice — worth a look, since the 2024 amendments are now in force."* (Only if true. This is a genuine, verifiable, useful observation. It also demonstrates exactly what you do.)
- *"[Mutual contact] suggested I reach out."* (Best of all, if true.)

---

## 4. LinkedIn

**Connection request** (no pitch — the pitch is what wastes the request):

> Hi [Name] — I work with Malaysian SMEs on IT and automation. Following along here; your work on [specific thing] caught my eye.

**Then, only if they accept, 2–3 days later:**

> Thanks for connecting, [Name]. Quick one — we do free one-hour IT reviews for SMEs and send a written one-pager on what to fix first, what it'd cost, and what to leave alone. No charge, no obligation. Want me to book one for [Company]?

**Post 2–3 times a week** with things that demonstrate competence rather than advertise. The highest-engagement formats for this audience:
- *"Three things I check first when an SME says their server keeps dropping"* (genuinely useful, no pitch)
- *"The 2024 PDPA amendments have been in force since June 2025. Most Malaysian SMEs I audit are still missing two of these four things."*
- *"A client was spending 3 hours a week on a report. Here's what it looks like now."*
- The calculator, shared as a tool: *"Free calculator — what manual admin is costing your business. No signup."*

None of these are ads. That's the point. They build the credibility that makes the DM work.

---

## 5. Follow-up sequence

Most replies come from follow-ups, not first touches. But keep it humane: **four touches, then stop.**

| When | Message |
|---|---|
| Day 1 | The cold email above. |
| Day 4 | *"Hi [Name] — following up on the free IT review. Happy to leave it here if the timing's wrong — just say the word."* |
| Day 10 | **Send value, don't re-ask.** Send the scorecard: *"In case it's useful — this is the 25-point checklist we run through. Even if we never speak, it's a decent way to spot what's slipping."* |
| Day 21 | The close: *"I'll stop here so I'm not cluttering your inbox. If IT ever moves up the list, my number's below. All the best."* |

Then genuinely stop. The breakup email has the highest reply rate of the four — people who were interested all along often answer *this* one. Both `docs/TESTIMONIAL-KIT.md` and this file exist so that when they do reply, you have somewhere to send them.

---

## 6. Community posts

The calculator gives you something genuinely shareable. Post it as a utility, never as an ad:

> **Free tool for SME owners: what is manual admin actually costing you?**
>
> I kept having the same conversation with business owners — "we're busy, but I can't tell you where the time goes." So I built a small calculator: staff × hours × salary → what that repetitive work costs per year.
>
> No signup, no email gate, no lead form. Just numbers. If it's useful, use it.
>
> [link]
>
> (I run an IT/automation firm in Cyberjaya, so yes, this is my area — but the tool is free and I'm not going to follow up with a pitch.)

Post it in: MySME-type Facebook groups, r/malaysia business threads, local business WhatsApp groups, LinkedIn. **The "no signup" promise is what makes it shareable.** Honour it.

---

## 7. Objection handling

Short, honest answers. Long answers lose SME owners.

| They say | You say |
|---|---|
| "We already have an IT guy." | "Good — you should keep him. We usually take over the parts that eat his week: monitoring, patching, backups, security, vendor chasing. Most of our clients' IT staff end up doing projects instead of tickets." |
| "Too expensive." | "Compared to what? Starter's RM 799 a month. If a staff member spends eight hours a week on repeat admin, that's roughly RM 1,500 a month in salary alone." |
| "We're too small." | "Our Starter plan is built for five people. The businesses that get the most out of this are the ones that never had anyone looking after IT properly — the fix is usually cheaper than the incident." |
| "Send me a proposal." | "Happy to — but I'd rather spend an hour first so the proposal is about your actual setup, not a generic list. Can we do [day]?" |
| "Just tell me the price." | "It's on our site, all of it. RM 799, RM 1,899 for the two managed plans. What I can't tell you without looking is which one you need — or whether you need either." |
| "Why should we trust a new company?" | "Fair question. That's why we do the free audit first — you'll see how we work before you pay us anything. And there's no lock-in: month-to-month, cancel any time." |

---

## 8. The numbers to expect (and not panic about)

Realistic cold outbound for a young B2B services firm in Malaysia:

- **50 well-targeted emails → 4–8 replies → 1–3 audits → 0–1 sale**
- LinkedIn with consistent posting: slower to start, better quality leads
- Communities and referrals: slowest, highest conversion, lowest effort

**If you get zero replies from 50 genuinely personalised emails, the message is fine — the list is wrong.** Change the list before you change the copy.

---

## 9. Compliance — this matters for you specifically

You sell PDPA compliance. Your own outbound has to be beyond reproach, because *any* prospect can check, and a single sloppy campaign undermines the entire pitch.

**Do:**
- Contact people at their **business** contact details, about a **business** matter, relevant to their role.
- Include your full identity and a real physical address in every message.
- Honour opt-outs immediately, in writing, and keep a simple suppression list.
- Keep a record of where each contact came from and why you believed they'd want to hear from you.

**Don't:**
- Buy a scraped contact list. Ever. It's the single fastest way to destroy a PDPA vendor's credibility.
- Add people to a mailing list because they enquired once. Enquiry consent covers *that enquiry*, not future marketing.
- Use the WhatsApp number for bulk sending (see the warning at the top).
- Keep contacting someone who asked you to stop.

If a prospect asks *"where did you get my details?"* — you should have a one-line, truthful answer. Prepare it before you send anything.

---

## 10. This week's plan

| Day | Action | Time |
|---|---|---|
| Mon | Build a list of 50 targets from job boards + LinkedIn, in **one** segment | 2 hrs |
| Tue | Personalise and send 15 emails. Log them. | 1.5 hrs |
| Wed | Send 15 more. Post the calculator in 2 communities. | 1.5 hrs |
| Thu | Send 20 more. LinkedIn: connect with 20, post once. | 1.5 hrs |
| Fri | First follow-ups. Run any audit that's booked. | 2 hrs |
| Week 2 | Repeat, and follow up on everything not yet answered | — |

**Track one thing:** how many audits you book. Not opens, not replies. Audits booked is the number that turns into revenue.
