#!/usr/bin/env node
/** Render Google Ads creatives to exact-size PNGs via system Chrome. */
'use strict';
const path = require('path');
const { chromium } = require('/media/shamelali/Data/projects/dutaintegra_homepage/tools/deps/node_modules/playwright');

const JOBS = [
  { html: 'ad-landscape-1200x628.html', png: 'ad-landscape-1200x628.png', w: 1200, h: 628 },
  { html: 'ad-square-1200x1200.html', png: 'ad-square-1200x1200.png', w: 1200, h: 1200 },
];

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  for (const j of JOBS) {
    const page = await browser.newPage({ viewport: { width: j.w, height: j.h } });
    await page.goto('file://' + path.join(__dirname, j.html), { waitUntil: 'networkidle' });
    await page.waitForTimeout(1200); // webfont settle
    await page.screenshot({ path: path.join(__dirname, j.png), clip: { x: 0, y: 0, width: j.w, height: j.h } });
    console.log('wrote', j.png);
    await page.close();
  }
  await browser.close();
})().catch((e) => { console.error('FAIL', e.message); process.exit(1); });
