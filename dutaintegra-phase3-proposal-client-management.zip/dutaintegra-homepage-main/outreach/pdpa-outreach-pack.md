# PDPA outreach pack — the gap-check engine

**Read `cold-outreach-pack.md` first.** It covers target lists, WhatsApp safety and the compliance rules for your own outbound. This document is the PDPA-hook version of the same machine, and it is the one to run for the next 30 days.

**Why this hook beats "we do managed IT":**

| Generic IT outreach | PDPA gap-check outreach |
|---|---|
| "We do managed IT and AI — got 15 minutes?" | "Your privacy notice is English-only. Section 7(3) requires BM and English." |
| Abstract claim, easy to ignore | Specific, checkable, already true |
| You're one of twenty vendors that week | You're the only one who looked |
| Asks for their time | Offers something first |

Since 1 June 2025 every Malaysian business processing personal data has been subject to the amended act, and almost none of them have done anything about it. That is not a reason to frighten people — it is a reason to be the person who noticed.

**The rule that makes this work: the gap check is genuinely free.** Not free-then-pitch. Not gated behind a call. You send a written summary of what you found, and you attach no proposal unless they ask. Every person you do this for walks away with something useful. That is why they reply, and why they remember you.

---

## What you actually check (15 minutes per prospect)

Open their website. Work down this list. Stop when you have two or three solid findings — you do not need all of them.

| # | Check | How you find it |
|---|---|---|
| 1 | **Privacy notice exists** | Footer link. Click it. If it 404s, that is finding #1 and you can stop early. |
| 2 | **Notice in Bahasa Malaysia too** | Look past the English. No BM version = s.7(3) gap. **Your strongest, most objective finding.** |
| 3 | **Purpose stated** | Ctrl+F for "purpose". "To improve our services" doesn't count. |
| 4 | **Source of data stated** | Do they say where data came from? Rarely present. |
| 5 | **Access and correction rights** | Search "access" and "correct". Often missing entirely. |
| 6 | **Who data is disclosed to** | "Our partners" is not a disclosure list. |
| 7 | **Contact for data enquiries** | A named person or role, with an email. A generic contact form doesn't satisfy it. |
| 8 | **Obligatory vs voluntary** | Do they say whether providing data is required and what happens if you decline? Almost never. |
| 9 | **Retention period** | "As long as necessary" is not a retention period. |
| 10 | **Consent checkbox on forms** | Submit their own contact form and look. No checkbox = no consent. |
| 11 | **CCTV** | Do they have cameras? Almost certainly, and it's almost never mentioned. |
| 12 | **WhatsApp as an enquiry channel** | If enquiries land in someone's personal WhatsApp, that's a storage location with no controls. |

**Record what you found in their exact words.** Screenshot it. You will quote it back to them in the email, and being able to say "your notice says we may share data with our partners" is what makes this land.

**Do not exaggerate.** If their notice is decent and only missing the BM version, say exactly that. The fifteen-minute check is a diagnosis, and a diagnosis you inflated is worthless.

---

## The email sequence

Four emails over 12 days. Short, specific, no attachments on the first one.

### Email 1 — the finding (day 0)

> **Subject:** Your privacy notice — one thing missing
>
> Hi [Name],
>
> I was looking at [Company]'s website this morning and noticed your privacy notice is published in English only.
>
> That's the rule most Malaysian SMEs have missed. Section 7(3) of the PDPA requires the notice in Bahasa Malaysia as well as English — and since the 2024 amendments came into force in June 2025, the rest of the act got stricter too: breaches have to be reported to the Commissioner within 72 hours.
>
> I do this for a living, so I put together a free checklist of what's actually required for a business your size: [link to /pdpa-checklist]
>
> If it would help, I'm happy to spend 30 minutes looking at what you currently have and send you a short written summary of where the gaps are. No charge and no obligation — and if you're already in good shape, I'll tell you that.
>
> Would that be useful?
>
> [Your name]
> Duta Integra Solutions
> F2-22-15, Tamarind Suites, Tamarind Square, Persiaran Multimedia, Cyber 11, 63000 Cyberjaya, Selangor
> +60 11-5403 4051 · support@dutaintegra.my

**Why this works:** the subject line is a specific claim about *them*. The body leads with what you found, not what you sell. The free checklist makes it valuable even if they never reply. The ask is a 30-minute review, not a meeting.

### Email 2 — the nudge (day 4)

> **Subject:** Re: Your privacy notice — one thing missing
>
> Hi [Name], just putting this back at the top of your inbox in case it got buried.
>
> Short version: your notice is English-only, and the PDPA requires both languages. It's a small fix, but it's the kind of thing a larger client's procurement team checks before they'll sign you.
>
> Offer stands — 30 minutes, written summary, no charge.
>
> [Your name]

### Email 3 — the useful follow-up (day 8)

Send something with no ask at all.

> **Subject:** The 72-hour clock (in case it's useful)
>
> Hi [Name],
>
> No pitch in this one — just the thing I get asked about most.
>
> If you have a data breach, the Commissioner has to be told within 72 hours of you *discovering* it. Not 72 hours from when it happened — from when you found out. Affected customers have to be told within 7 days after that, if the breach is likely to cause them harm.
>
> The reason most businesses would struggle isn't the deadline, it's that nobody knows who's supposed to do the reporting. Three names on a piece of paper in a drawer solves most of it.
>
> Full checklist here if useful: [link]
>
> [Your name]

### Email 4 — the close (day 12)

> **Subject:** Closing the loop
>
> Hi [Name],
>
> I'll stop here — I don't want to become a nuisance.
>
> If data protection comes up later, whether that's a client questionnaire, a tender, or someone asking awkward questions, my details are below. The free checklist lives at [link] and it's yours to use.
>
> One last thing: whichever way you take this, get the BM version of your notice published. It's the cheapest gap to close and it's the one most likely to be noticed.
>
> [Your name]

**Then stop.** Do not send a fifth. Add them to a quarterly check-in list at most.

---

## The gap-check summary — your real differentiator

This is the document you send after the 30 minutes. One page. It is the whole strategy in a single artefact: it proves you looked, it proves you know the subject, and it costs them nothing.

**Template:**

> ### PDPA gap check — [Company name]
> **Reviewed:** [date] · **By:** [your name], Duta Integra Solutions
>
> **What I looked at:** your website, your published privacy notice, your enquiry form, and the contact points listed on your site.
>
> **What's in good shape**
> [Be genuine. If the notice covers purposes and retention properly, say so. One or two lines.]
>
> **What needs attention**
> 1. **[Finding]** — [what the act requires, in one sentence]. *Your notice currently says: "[exact quote]".*
> 2. **[Finding]** — [requirement]. *Your form has no consent checkbox.*
> 3. **[Finding]** — [requirement].
>
> **What I'd do, in order**
> 1. [Cheapest, highest-value fix first — usually the BM notice.]
> 2. [Next.]
> 3. [Next.]
>
> **What I'd leave alone for now**
> [This section is why people trust the report. Example: "The DPO requirement doesn't apply to you — you're well under the 20,000 data subject threshold. Don't let anyone sell you one."]
>
> **If you'd like help:** our PDPA Starter Pack covers all of the above for a fixed RM 1,800–4,500, delivered in 14 days. Happy to send details — or equally happy if you'd rather fix it in-house. Everything in this summary is yours to use either way.
>
> [Name] · +60 11-5403 4051 · support@dutaintegra.my

**The "what I'd leave alone" section is the most important part.** Anyone can list what's wrong. Saying "you don't need the expensive thing" is what makes the rest of the report credible — and it is exactly what a competitor selling fear will never do.

---

## LinkedIn

Post twice a week. This is the slowest channel and the best-quality one.

**Post types that work:**

- **The finding, anonymised.** *"Checked 10 SME websites this week. All 10 had an English-only privacy notice. Section 7(3) requires BM and English — so that's 10 out of 10 in breach of a rule that's been in force since 2013."*
- **The correction.** *"Someone told a client they needed to appoint a DPO. They have 400 customers. The threshold is 20,000. This is why I tell people to read the actual guidelines."*
- **The practical one.** *"Three names. That's the entire breach plan for most SMEs — incident lead, notifier, comms. Write them down and put the paper in a drawer. You now have a 72-hour capability you didn't have this morning."*
- **The honest limitation.** *"I'm not a lawyer and I don't give legal advice. If a client needs a legal opinion, I refer them out. Here's the line I draw and why."*

**Do not post:** scare statistics, "RM1,000,000 fines!" headlines, or anything that implies a regulator is coming for a business with 400 customers. You have a credibility advantage over the fear-sellers. Do not throw it away.

**Outreach approach on LinkedIn:** connect with a genuine note, engage with their posts for a week or two, *then* send the finding as a message. The finding works as a message; it does not work as the opening line to a stranger.

---

## Objection handling — the PDPA-specific ones

The general objections are in `cold-outreach-pack.md` §7. These are the ones this offer creates:

| They say | You say |
|---|---|
| "We're too small for this." | "For the DPO requirement, probably true — that only applies above 20,000 people. But the notice requirement has no size threshold. If your website collects names and phone numbers, it applies to you. Let me show you what's actually required at your size, and if it's less than you think, I'll say so." |
| "We've never had a problem." | "Fair — you probably never will. Two reasons it still matters: larger clients are starting to ask for a compliance position before they sign, and if something did go wrong, the difference between a 72-hour response and a two-week scramble is whether anyone wrote it down." |
| "Can't I just download a template?" | "You can, and for some businesses that's genuinely enough. The problem is the notice has to describe the data *you* hold for *your* purposes. A template listing the wrong categories is worse than nothing — it documents a claim you can't stand behind." |
| "Shouldn't a lawyer do this?" | "For a legal opinion, yes. For most SMEs these are operational documents, not legal opinions — and I put that in writing. If your situation needs a lawyer, I'll tell you and refer you to one." |
| "We already have a policy." | "Send it and I'll review it free. Half the ones I see are English-only, which is the most common gap. It might just need updating — and if that's the case, I'll tell you that rather than sell you a replacement." |
| "It's not a priority right now." | "Understood. Can I leave you the checklist and check back in a quarter? Most of these become urgent when a client sends a procurement questionnaire, and that usually happens without warning." |
| "Who are you? Where did you get my details?" | "I found [Company] while researching [sector] businesses in [area], and your website is public. I looked because this is what I do — no list was bought. If you'd rather I didn't contact you again, say the word and you won't hear from me." |

That last one must be truthful and instant. You sell data protection. Your own outbound is the first thing a prospect will judge you on.

---

## Converting: gap check → pack → retainer

**Gap check → pack.** Roughly one in four should convert, if the check was genuine. The conversion happens in the summary document, not in a follow-up call — the "if you'd like help" line does the work, and they raise it themselves. When they do:

> "It's RM 2,800 fixed for the Complete pack, and it covers everything in that summary plus the breach plan and the register. Two weeks, and your side is about an hour plus one review. I'll send the engagement letter — it's plain English, and section 7 says explicitly that I'm not a lawyer and this isn't legal advice."

**Pack → retainer.** Wait until handover, then flag what you actually saw. The scripts are in `PRODUCT-GUIDE.md` under "Where the pack leads". Only say it if it's true.

**Pack → referral.** At handover, ask one question: *"Who else do you know who's had a client send them a compliance questionnaire?"* That single question is a better lead source than 50 cold emails, and the ask is natural because you've just delivered something useful.

---

## This month's numbers

Run the funnel for 30 days and track three numbers only. Nothing else matters yet.

| Stage | Target | What "working" looks like |
|---|---|---|
| Targeted businesses researched | 50 | One segment, one area |
| First emails sent | 50 | Genuinely personalised — real finding in each |
| Replies | 5–10 | Below 5 means the list is wrong, not the copy |
| Gap checks delivered | 4–8 | Free, written, no proposal attached |
| Packs sold | 1–2 | At RM 2,800, that's RM 2,800–5,600 |
| Retainer conversations | 1 | From the first completed pack |

**The diagnosis rule:** if you get zero replies from 50 genuinely personalised emails, change the list before you change the copy. The copy is proven — the finding is real and checkable.

**Realistic expectation:** this is not a get-rich channel. It is a "get your first three clients and a portfolio" channel, and the third client onward costs you almost nothing to deliver because the templates already exist.

---

## Legal check on your own outbound

You must be beyond reproach here, because any prospect can check.

- **Business contact details, business matter, relevant to their role.** That is a defensible basis for a one-to-one approach.
- **Full identity and a real physical address** in every message. Yours is in the signature above — keep it there.
- **Honour opt-outs immediately**, in writing, and keep a suppression list you actually check before sending.
- **Keep a record** of where each contact came from and why you believed they'd want to hear from you. If someone asks, you need a truthful one-line answer ready before you send.
- **Never buy or scrape a contact list.** For anyone else this is bad practice. For a PDPA vendor it is disqualifying, and it only takes one person to say so publicly.
- **No bulk WhatsApp.** See the warning at the top of `cold-outreach-pack.md`. Losing that number would cost more than any campaign could earn.
- **No hard sell on urgency you don't believe.** If they're under the DPO threshold, tell them. The reputation is the asset.
