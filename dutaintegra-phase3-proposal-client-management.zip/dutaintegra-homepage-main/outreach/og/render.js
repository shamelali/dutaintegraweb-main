#!/usr/bin/env node
/** Render the Open Graph card to public/og-image-v2.jpg (1200x630). */
'use strict';
const path = require('path');
const fs = require('fs');
const { chromium } = require('/media/shamelali/Data/projects/dutaintegra_homepage/tools/deps/node_modules/playwright');

const ROOT = '/media/shamelali/Data/projects/dutaintegra_homepage';
const JOB = { html: 'og-homepage-1200x630.html', out: path.join(ROOT, 'public/og-image-v2.jpg'), w: 1200, h: 630 };

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: JOB.w, height: JOB.h }, deviceScaleFactor: 1 });
  await page.goto('file://' + path.join(__dirname, JOB.html), { waitUntil: 'networkidle' });
  await page.waitForTimeout(1200); // webfont settle
  const buf = await page.screenshot({
    type: 'jpeg', quality: 88,
    clip: { x: 0, y: 0, width: JOB.w, height: JOB.h },
  });
  fs.writeFileSync(JOB.out, buf);
  console.log('wrote', JOB.out, (buf.length / 1024).toFixed(1) + ' KB');
  await browser.close();
})().catch((e) => { console.error('FAIL', e.message); process.exit(1); });