# dutaintegra.my — Homepage rebuild for lead capture

> **STATUS — updated after round 2.** Contact details changed, the recommended next steps built out, and the live site audited in a real browser across all 11 routes.
>
> | File | What it is | Status |
> |---|---|---|
> | `index.html` | Rebuilt homepage | ✅ Updated — new address, WhatsApp, email |
> | `privacy.html` | Bilingual PDPA privacy notice (`/privacy` currently renders **0 characters**) | ✅ Built — 11 `[CONFIRM]` markers to fill |
> | `audit-scorecard.html` | 25-point IT & automation audit scorecard, printable to a 5-page PDF | ✅ Built |
> | `docs/FIX-GUIDE.md` | Exact fixes for 9 live-site problems, incl. a missing PDPA consent checkbox | ✅ Built |
> | `docs/TESTIMONIAL-KIT.md` | The email to send clients + how to handle anonymity | ✅ Built |
> | `outreach/cold-outreach-pack.md` | ICP, templates, sequence, objection handling, WhatsApp-ban warning | ✅ Built |
> | `previews/` | Desktop/mobile screenshots + sample scorecard PDF | ✅ Built |
> | `og-image.jpg` + `assets/og-template.html` | 1200×630 social preview (81 KB) — every WhatsApp/LinkedIn share was a grey box before | ✅ Built |
> | `analytics.js` | Lead-event tracking: which WhatsApp link, which section, calculator use, form outcomes | ✅ Built — ships disabled |
> | `robots.txt`, `sitemap.xml` | Crawl rules; sitemap excludes the 3 empty pages | ✅ Built |
> | `_headers`, `_redirects` | Security headers + SPA-safe routing (Netlify/Cloudflare) | ✅ Built |
> | `deploy/nginx.conf.example` | Self-host equivalent — **validated with `nginx -t`** | ✅ Built |
> | `DEPLOY.md` | Deployment order, verification commands, rollback | ✅ Built |
>
> **Three things to know before you read on:**
> 1. Your **live contact form has no PDPA consent checkbox and no privacy link** — you sell PDPA compliance. `docs/FIX-GUIDE.md` §1.
> 2. **`/privacy`, `/terms`, `/cases`, `/stats`, `/insights` all render zero content.** The privacy notice you link in your footer does not exist. §2.
> 3. **Three empty public GitHub repos** named `dutaintegra*-live` sit under your account. §0.
>
> Repo status: `dutaintegraweb-main` is private (404), so I could not diff source against this rebuild — it's built from your live site's markup, copy, pricing and compiled CSS. The three other Duta Integra repos are public with **zero files** in them.

**Deliverable:** `index.html` (single file, no build step, ~75 KB, zero external JS)
**Goal:** turn the homepage from a brochure into a lead-capture surface that works for a company with no client logos and no testimonials yet.
**Constraint I respected:** I wrote only TRUE things. Every number, promise and claim on this page already exists somewhere on your live site (pricing, "3 working days", "no lock-in", "100% Malaysian-owned", Tamarind Suites, the founder quote). Nothing is invented — see *"What I deliberately did not do"* at the bottom.

---

## 1. The core problem I fixed

**Your site sells the offer. It doesn't reduce the risk of buying from you.**

That's the actual bottleneck, and it explains the low leads better than anything about design. Look at what a visitor to your current homepage learns:

| Visitor's real question | What the current homepage answers |
|---|---|
| What does it cost? | Nothing — pricing is one click away |
| Will this be annoying to buy? | "No lock-in" buried in a stat block |
| Who are you? | "3 Happy Clients" |
| Can I trust you? | A fake live-events feed |
| What do I get first, and what does it cost me? | "Free audit" mentioned, never defined |

Meanwhile the page *shouts* the scarcity angle — **"Your Competitors Automate. While You Chase IT Issues"**, "The cost of doing nothing grows every quarter." Fear-based urgency is a weak lever when the reader has never heard of you: it creates pressure without creating trust, and Malaysian SME owners are sold to constantly. And the stat "**3 Happy Clients**" actively tells a new visitor they'd be an early guinea pig.

### The strategic move

You don't have logos. So don't compete on social proof — compete on **risk reversal**, which you *can* offer from day one, at almost no cost:

> Free audit → fixed price in writing in 3 days → month-to-month, cancel any time → we'll tell you if you don't need us.

That's a much stronger pitch for a young vendor than "trust us". The new page makes those four promises the spine of the whole document, and repeats them in the hero, the guarantees block, the FAQ and next to the form.

### The second move: give the visitor a reason to act *before* they're ready to talk to a salesperson

The **"What is manual work costing you?" calculator** in the hero. Three sliders → a real ringgit number. This does four jobs at once:

1. **It qualifies the lead** — the WhatsApp message it generates tells you their staff count and admin load before you reply.
2. **It converts the hesitant** — a business owner who isn't ready for a call will still move a slider.
3. **It creates the buying argument for you** — RM 3,800/month in wasted admin vs RM 799/month managed IT. The price objection dissolves before it's raised.
4. **It's a shareable, memorable asset** — the kind of thing an SME owner forwards to their partner.

The assumptions (173 working hours/month, 60% recoverable) are printed on the page, not hidden. That honesty is itself a differentiator — and it protects you from "your calculator was wrong" arguments.

---

## 2. Before → after, section by section

| Section | Current site | Rebuild | Why |
|---|---|---|---|
| Sticky bar | none | "Free IT audit · fixed price in 3 days · no lock-in" | Your offer, visible while scrolling |
| Hero headline | "Your Competitors Automate. While You Chase IT Issues" | "Your IT, fully managed. **Your busywork, automated.**" | States what you do in words an SME owner uses. Fear hook moved to the calculator, where it's *evidence-backed* instead of generic |
| Hero proof | "3 Happy Clients", fake live event feed | Three checkable promises + ROI calculator | Removes the self-inflicted wound; replaces fake proof with real risk reversal |
| Live events ticker | "Contained lateral movement attempt · Petaling Jaya", "CVE-2026-4821" | **Removed** | These are unverifiable, and as written they'd be alarming if real. Selling PDPA compliance while displaying anonymous "incidents" is a credibility contradiction |
| Services | 5 cards, "Get Notified" CTAs on a live site | 4 cards with real "from" prices, BI flagged *Launching next* with a WhatsApp notify link | On a live site, **"Get a Quote / Get Notified" reads as "nothing is ready yet."** BI softened from a service to a roadmap item |
| Pricing | Separate `/pricing` page, 3 tiers + 6 project prices | Full tier table **and** project starting prices **on the homepage** | Buyers researching you will find a competitor's page before they find yours. Price transparency also pre-filters tyre-kickers |
| Why us | "Local expertise / AI+IT / Transparent / Fast onboarding" | 4 concrete promises + founder quote | "Transparent pricing" is a claim; "a fixed figure in writing in 3 working days" is a commitment you can be held to |
| Testimonials | Absent | Still absent — with an HTML comment showing exactly where to drop them | See §1. Not willing to fabricate these for you |
| Process | 4 generic steps | Same 4 steps, each with a **time commitment** ("3 working days", "weekly check-ins") | Turns process into expectation-setting, which is what a risk-averse buyer actually wants |
| FAQ | none | 7 questions incl. **price, lock-in, "we already have an IT person", "I don't think we're ready for AI"** | These are the four objections that kill SME deals. Answering them on-page means they don't cool off between your reply and their decision |
| Contact | Form on `/contact`, separate page | Form on the homepage + WhatsApp + direct number, all in one place | Fewer clicks to conversion. The form now asks the *one* question that matters: "what's the problem you're trying to solve?" |
| Mobile | unknown | Sticky bottom WhatsApp + "Free IT audit" bar | Most Malaysian SME owners will open you on a phone |
| Language | EN/BM toggle in header | Kept, and **Extended to the above-the-fold decision surface** | A site that promises BM but shows English headlines undercuts local credibility. Flagged as needing native review |
| Page weight | React SPA: 397 KB JS + 43 KB CSS parsed before first paint | 73 KB total, no render-blocking JS | Not a lead problem directly, but every second of blank screen costs conversions on Malaysian mobile connections |

---

## 3. Fix these on the live site today (real bugs found)

These are live right now, not design opinions:

1. **`svc4Desc` is rendering as visible text** on `/services`, under *IT Security & PDPA Compliance*. Same for **`svcStep4Desc`** under *Support* in the Process section. Untranslated i18n keys shipped to production — on a page selling professional services, this is the single most damaging thing on the site.
2. **`aboutVal2Desc`** is rendering visible on `/about` under *Partnership, Not Transaction*.
3. **"Get Notified" buttons** on `/services` for services you already sell. That's placeholder copy, and it reads as "launching soon" for your entire service line.
4. **The Services page says "24/7 support" is included in Starter**, and the Pricing page lists 24/7 next to Starter's features too — but Starter is a business-hours helpdesk with a monthly health check. Pick one; a client who reads both pages will ask, and it's an awkward answer.
5. **72% of your i18n keys are unset.** The bundle contains `svc1Title … svc3Feat6`, `aboutVal1Desc …`, `svcStep1Desc …` as raw keys. Whatever tool generates these, it's not being run — or it's broken. If the EN/BM toggle is showing BM button labels with English content, it's worse than not having a toggle.
6. **No SSM registration number anywhere.** Malaysian B2B buyers check SSM. It's free trust. Put it in the footer.
7. **`/privacy` has no page.** You sell PDPA compliance. A missing privacy notice on your own site is the exact failure you'd bill a client to fix. The form on my page links to it — publish it or point the link at a real notice before you ship.

---

## 4. What I deliberately did NOT do

So you know the boundaries of this file:

- **No invented testimonials, client names, logos or case studies.** I left a commented-out block in the right place. For a company whose revenue depends on being trusted with other firms' data, fake proof is an existential risk, not a growth hack.
- **No unverifiable numbers.** Your site claims "RM 240K+ saved" with 3 clients. I didn't carry that onto the new page — it's not defensible at that ratio, and it invites exactly the scepticism you can't afford yet. Replace it with a real, named case study when you have one.
- **The calculator figures are estimates with stated assumptions**, not projections about your clients.
- **One page only.** Homepage. The other routes, the React app, the lead backend and DNS are untouched.

### The three assets that would beat anything I can write

If you want the next big jump in lead quality, these are, in order:

1. **Three real testimonials with name, role, company and industry.** Not "great service!" — something specific: *"We were spending two days a month on reconciliation; it now runs overnight."* The interview template is in §6.
2. **One written case study** with a before/after number you can defend. One good case study outperforms every word on the current homepage.
3. **SSM number in the footer.** Five minutes of work.

---

## 5. Deploying this

The file is standalone HTML/CSS/JS — no framework, no build step, no CDN dependency except Google Fonts (which degrades gracefully).

**Option A — drop it in as-is (fastest to test):**
1. Preview it locally tomorrow morning at a coffee shop: open the file in a browser, check it on your phone too.
2. Put it at `/index.html` on your origin and point the `/` route at it.
3. **Critical:** your lead backend checks the request `Origin` against `ALLOWED_ORIGINS` and returns 403 otherwise. The form posts to `/api/send-email`, so make sure `https://dutaintegra.my` and `https://www.dutaintegra.my` are both allowlisted. I added a WhatsApp fallback: if the API errors or 403s, the form hands the visitor a pre-filled WhatsApp message with everything they typed, so **no lead is lost either way**. That fallback is not a substitute for fixing the allowlist.
4. Verify: submit the form on the deployed domain and confirm the enquiry arrives *and* lands in your enquiry store (you append before sending mail — good, keep that).

**Option B — port into your React app (better long-term):**
The markup is semantic and section-by-section, so it transfers cleanly: hero → calculator, trust strip, services, pricing, guarantees, process, FAQ, CTA band, form, footer. Move the three inline scripts into components (calculator, form, i18n) and run the copy through your existing i18n layer instead of my hand-rolled EN/BM toggle — see the note in the code.

**Worth doing either way:** run it through PageSpeed Insights once deployed. A static page should score well into the 90s where the SPA currently can't.

---

## 6. The next 7 days (lead-gen actions, no code required)

**Day 1 — stop the bleeding.** Fix the visible i18n placeholders (`svc4Desc`, `svcStep4Desc`, `aboutVal2Desc` — exact copy to paste is in `docs/FIX-GUIDE.md` §3), replace "Get Notified" buttons with "Get a Quote", add your SSM number to the footer. Roughly an hour, and it removes your worst credibility leak. **Do §1 and §2 as well** — the consent checkbox and the missing privacy notice are the two things a prospect could weaponise.

**Day 2 — get three real testimonials.** Email every client you've ever delivered for. Ask exactly this:

> "Could you answer three questions in a couple of sentences each? (1) What was broken or manual before? (2) What's different now — ideally with a number or a time saved? (3) Who would you recommend us to, and why?"

Specific beats glowing. "Two days a month on reconciliation" beats "highly professional". If a client won't put their name to it, use "Operations Manager, logistics company, Johor" — still vastly better than nothing, and honest about the anonymisation.

**Day 3 — start outreach.** Templates, targets, the 4-touch sequence and objection handling are all in `outreach/cold-outreach-pack.md`. **Read its opening section first** — bulk cold WhatsApp will get `+60 11-5403 4051` permanently banned by Meta, and that number is on your homepage, footer, scorecard and email signature. The safe order is community → LinkedIn → warm intro → WhatsApp only after engagement.

**Day 3, part 2 — put the calculator in front of people.** It's a shareable asset. Post it in Malaysian SME communities framed as a utility, not an ad: *"Made a free calculator for working out what manual admin is costing you — no signup."* People share tools. Nobody shares brochures.

**Day 4 — answer the questions your buyers are typing.** Publish 2 short articles targeting what SMEs actually search: *"managed IT cost Malaysia"*, *"PDPA compliance checklist for SMEs"*, *"how much does a chatbot cost in Malaysia"*. You already have PDPA retention guidelines written in your repo. Reuse them.

**Day 5 — make the free audit a razor.** ✅ The framework is built: `audit-scorecard.html`. 25 scored questions across backup/recovery, security, PDPA and automation, with a scoring band, a priority-actions grid and a "leave alone" column. Print to a 5-page PDF and use the same PDF twice — as the lead magnet ("get the scorecard") and as the deliverable you hand over after the audit. Fill it in *with* them on the call; the blanks become the conversation.

**Ongoing — measure one thing.** Set up a goal on form submits and WhatsApp clicks (`wa.me` link clicks, which you can fire as events). Without that, every future decision about this site is a guess.

---

## 7. What to measure, and how you'll know it worked

| Metric | Today (assumed) | What "working" looks like |
|---|---|---|
| Form submits + WhatsApp clicks per 100 sessions | unknown — measure it first | 3–6 |
| Calculator engagements per 100 sessions | n/a | 15+ (it's the top-of-funnel hook) |
| Reply-to-meeting rate | unknown | The form now pre-qualifies by budget and service, so this should rise even if raw volume doesn't |
| Bounce on homepage | likely high | Should fall; the page now answers price without navigation |

### Measured, not assumed

These were tested by serving the files through a real nginx instance and driving them in a real browser:

| Check | Result |
|---|---|
| Homepage gzipped | 82 KB → **21.6 KB** |
| `/privacy` content | **0 chars → 35,675 bytes** bilingual notice |
| Scorecard → PDF | clean 5 pages, no split rows |
| Security headers | HSTS, CSP, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy all present |
| `/stats`, `/insights` | 301 → `/services` |
| apex → www, http → https | 301, single canonical host |
| Analytics events | 13 captured across 7 event types, correctly attributed by page location |
| OG image | 1200×630, 81 KB (was 401 KB as PNG — 80% smaller, visually identical) |
| JS errors / layout overflow | none, at 1440 / 820 / 390 px on all three pages |

One honest note: if you change this page and leads *don't* move within three weeks, the bottleneck isn't the homepage — it's traffic. A great page can't convert visitors who aren't arriving. In that case the work moves to **outbound** (LinkedIn + cold WhatsApp to SMEs with 10–50 staff in Johor, Klang Valley, Penang) and to the free-audit offer as the door-opener, not the site.

---

## 8. Technical notes

- **No tracking beyond what you add.** The form sends `source: "homepage-redesign"` and the current page URL so you can tell where a lead came from once you add analytics.
- **Honeypot + consent + validation** are in the form; the API still needs its own server-side validation (don't trust the client).
- **Structured data:** JSON-LD `ProfessionalService` with your five real offers and prices, plus a FAQ section that's ready to extend — this is what makes you eligible for rich results, and your current SPA has none.
- **Accessibility:** skip link, focus-visible rings, `aria-live` on the calculator output and form status, `prefers-reduced-motion` respected throughout, real labels on every input.
- **SEO:** title and description now lead with the commercial terms people actually search ("managed IT", "Malaysian SMEs", the price). Add an `og:image` (1200×630) before launch — there's a TODO in the head.
- **Browser support:** modern evergreen browsers. The calculator uses `Intl.NumberFormat` and the reveal uses `IntersectionObserver` with a no-JS fallback so all content is visible without JavaScript.

---

## PDPA Starter Pack — the productised offer

The homepage answers "what do you do and what does it cost". The PDPA Starter Pack gives a **specific,
checkable reason to call you this week**, which is the harder half of the lead problem.

| Asset | Location | State |
|---|---|---|
| Offer sheet (3-page A4 PDF) | `pdpa-starter-pack/offer-sheet.pdf` | **Print-verified** — 3 pages, 594 KB |
| Privacy notice template (BM + EN) | `pdpa-starter-pack/client-pack/02-privacy-notice-TEMPLATE.html` | Built — 5 A4 pages, 37 fill fields |
| Data inventory + retention + DPO + breach registers | `pdpa-starter-pack/client-pack/01-*.xlsx` | Built — 4 sheets, 13 KB |
| Breach response plan | `pdpa-starter-pack/client-pack/03-*.html` | Built — 3 A4 pages |
| Data subject rights procedure | `pdpa-starter-pack/client-pack/04-*.html` | Built — 3 A4 pages |
| DPO appointment pack | `pdpa-starter-pack/client-pack/05-*.html` | Built — 3 A4 pages |
| Staff one-pager | `pdpa-starter-pack/client-pack/06-*.html` | Built — 2 A4 pages |
| Consent wording library | `pdpa-starter-pack/client-pack/07-consent-wording-library.md` | Internal swipes — 8 collection points |
| Product, pricing and objection handling | `pdpa-starter-pack/PRODUCT-GUIDE.md` | Internal |
| **Engagement letter / SOW** | `pdpa-starter-pack/client-pack/08-*.html` + `.pdf` | Built — 6 A4 pages, 15 clauses |
| **Kickoff questionnaire** | `pdpa-starter-pack/client-pack/09-*.html` + `.pdf` | Built — 11 sections, live DPO threshold calculator |
| **Drafting prompt** | `pdpa-starter-pack/prompts/draft-the-pack.md` | Internal — questionnaire to first draft in one pass |
| **PDPA outreach pack** | `outreach/pdpa-outreach-pack.md` | Internal — 4-email sequence + gap-check summary template |
| Delivery checklist | `pdpa-starter-pack/delivery-checklist.md` | Internal |
| **Free PDPA checklist (public)** | `lead-magnet/pdpa-checklist.html` → `/pdpa-checklist` | **Live-ready** — 5 sections, 42 checkpoints, FAQ schema |

**Pricing:** Essential RM 599 · Complete RM 1,999 · Sustained RM 3,999,
all fixed price, 14-day delivery.

**Why it belongs on the homepage:** the pitch is a *diagnosis*, not a claim. A prospect can open their own
website, look for their Bahasa Malaysia privacy notice, and discover the gap themselves in 60 seconds.
That is the same structural advantage the ROI calculator has — it makes an abstract risk concrete.

**Positioning rule applied throughout: no fear-selling.** The RM1,000,000 maximum fine is stated once, then
honestly discounted — most SMEs under 20,000 data subjects do not need a DPO, and we say so explicitly.
The stated benefits are tender-readiness, 72-hour capability and lawful consent capture. When a competitor
inflates the threat, that honesty is the differentiator.

**Full disclosure in every document:** not a law firm, not legal advice, no guaranteed regulatory outcome.

---

## Entity correction — Sdn Bhd → Enterprise

Confirmed as an **Enterprise** (registered under the Business Registration Act 1956), not a Sdn Bhd.
Renamed across **16 files**; all 8 PDFs regenerated and verified. Full detail in `docs/ENTITY-CORRECTION.md`.

The name change mattered less than the legal wording it exposed:

| Location | Was | Now |
|---|---|---|
| `privacy.html` (EN + BM) | "a company **incorporated** in Malaysia", company-number example | "a business **registered** under the Business Registration Act 1956", business-number example |
| SOW parties | "Registration no." | business registration no. **+ proprietor name**, and "trading as Duta Integra" |
| SOW signature | "For and on behalf of…" | "**Proprietor**, Duta Integra Solutions" |
| Client templates | "full registered **company** name" | "registered name as per your SSM certificate" (works for any client type) |

An Enterprise is *registered*, not *incorporated* — incorporation is a Companies Act concept. A sole
proprietor also signs personally rather than "for and on behalf of" the business.

**Commercially relevant:** an Enterprise has no separate legal personality, so the §12 liability cap in the
SOW caps contractual liability but does not shield personal assets the way a Sdn Bhd would. Worth knowing
before signing anything with a corporate client.
