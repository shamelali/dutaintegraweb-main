-- Phase 3: Proposal & Client Management. Apply with `wrangler d1 migrations apply <DB_NAME> --remote`.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS workspace_users (
  email TEXT PRIMARY KEY COLLATE NOCASE,
  display_name TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('admin','staff','client')),
  organization_id TEXT REFERENCES organizations(id) ON DELETE RESTRICT,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK ((role = 'client' AND organization_id IS NOT NULL) OR (role IN ('admin','staff')))
);
CREATE TABLE IF NOT EXISTS leads (
  id TEXT PRIMARY KEY,
  company TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  service_interest TEXT NOT NULL DEFAULT 'Digital assessment',
  source TEXT NOT NULL DEFAULT 'Digital assessment',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','qualified','proposal','won','lost')),
  notes TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL REFERENCES workspace_users(email),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS leads_status_created ON leads(status, created_at DESC);
CREATE TABLE IF NOT EXISTS proposals (
  id TEXT PRIMARY KEY,
  lead_id TEXT REFERENCES leads(id) ON DELETE SET NULL,
  organization_id TEXT REFERENCES organizations(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  currency TEXT NOT NULL DEFAULT 'MYR' CHECK (currency IN ('MYR')),
  amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sent','accepted','declined','expired')),
  valid_until TEXT,
  created_by TEXT NOT NULL REFERENCES workspace_users(email),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS proposals_status_created ON proposals(status, created_at DESC);
CREATE INDEX IF NOT EXISTS proposals_org ON proposals(organization_id, created_at DESC);
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  proposal_id TEXT REFERENCES proposals(id) ON DELETE SET NULL,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','in_progress','blocked','completed','cancelled')),
  next_action TEXT NOT NULL DEFAULT '',
  target_date TEXT,
  created_by TEXT NOT NULL REFERENCES workspace_users(email),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS projects_org ON projects(organization_id, created_at DESC);
CREATE TABLE IF NOT EXISTS workspace_audit_log (
  id TEXT PRIMARY KEY,
  actor_email TEXT NOT NULL,
  action TEXT NOT NULL,
  record_type TEXT NOT NULL,
  record_id TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS audit_created ON workspace_audit_log(created_at DESC);
