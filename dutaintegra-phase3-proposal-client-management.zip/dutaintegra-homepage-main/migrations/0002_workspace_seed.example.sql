-- EXAMPLE ONLY — do not apply unchanged. Replace all values and review access.
-- Provision identities only after Cloudflare Access policy and D1 binding are tested.
INSERT INTO organizations (id, name) VALUES ('org_replace_me', 'Replace with client legal name');
INSERT INTO workspace_users (email, display_name, role, organization_id)
VALUES ('staff@example.com', 'Replace with staff name', 'admin', NULL);
INSERT INTO workspace_users (email, display_name, role, organization_id)
VALUES ('client@example.com', 'Replace with client contact', 'client', 'org_replace_me');
