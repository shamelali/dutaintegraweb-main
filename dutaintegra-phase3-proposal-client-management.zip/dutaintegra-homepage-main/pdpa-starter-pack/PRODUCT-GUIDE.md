# PDPA Starter Pack — how to sell and deliver it

This is the internal guide. `offer-sheet.html` is what the client sees; this is what you know.

---

## The one-paragraph pitch

**Malaysian SMEs must now comply with PDPA rules that changed in June 2025, and almost none of them have.** Most websites still have an English-only privacy notice — which fails s.7(3) — no consent capture they can evidence, and no breach process. You fix that in two weeks for a fixed RM 599–3,999, and it opens the door to a managed IT retainer.

---

## Why this is your best door-opener

Not just because it's recurring revenue. Because of what it does to the sales conversation:

| Most IT vendors cold-call like this | You cold-call like this |
|---|---|
| "We do managed IT and AI, can we have 15 minutes?" | "Your website's privacy notice is English only. Section 7(3) requires BM and English. Want me to send you a one-page note on what else is missing?" |
| Abstract. Easy to say no. | Specific. Provable. Hard to dismiss. |
| You're one of twenty. | You're the only one who noticed. |

**The gap check is the product's real superpower.** You can open any prospect's website, find the PDPA gap in five minutes, and open with something true and useful. That's not a pitch — it's a diagnosis. People respond to diagnoses.

And the sale is small: RM 599 fixed for Essential, two weeks, no lock-in. Compare that to asking an SME to commit to a RM 1,899/month retainer as a first purchase from an unknown vendor. The pack is the low-risk way in.

---

## The three-tier structure, and why it's built that way

| Tier | Price | What it's for |
|---|---|---|
| **Essential** | RM 599 | Documents only. The compliance position exists on paper. |
| **Complete** | RM 1,999 | Everything, plus the operational plan. **~70% should buy this.** |
| **Sustained** | RM 3,999 | Sensitive data, or clients who get audited by their own customers. |

Essential exists mainly so Complete looks reasonable. That's normal and honest — Essential is genuinely deliverable and genuinely useful, it's just bare.

**Don't upsell into Sustained reflexively.** Cross-border assessment and vendor contract review are only worth paying for if there's actually cross-border processing or meaningful vendor risk. Recommending it when it isn't warranted is how you become the vendor they complain about.

### Pricing logic

- At RM 1,999 for roughly 10–14 hours of work, that's a healthy effective rate.
- It's priced under RM 3,000 deliberately: above that, SMEs start comparing quotes and delaying decisions.
- It's priced above RM 1,500 deliberately: below that, buyers assume it's a template mill, and you attract clients who won't pay for anything else.
- **Your second PDPA client costs you almost nothing** — the templates in `client-pack/` are done. Effective hourly rate roughly doubles from client two onward. That's the point of an asset business.

### If they push back on price

> "It's RM 1,999 fixed for Complete, and it doesn't renew. If you'd rather do it yourself, everything you need is public — but it's about a day of reading and you'd still need to write the notice for your actual data. Most people decide their time is worth more than that."

Don't discount. Offer to drop from Complete to Essential instead. Discounting a fixed-price product trains the client to negotiate everything that follows — including your retainer.

---

## The free gap check — your lead magnet

30 minutes, no charge, written summary of findings. This is the top of the funnel and it converts remarkably well.

**What you check (in order, it takes 15 minutes):**

1. **Privacy notice exists?** Load the site, find the footer link. If it 404s, that's finding #1.
2. **Bilingual?** Read past the English. If there's no BM version, that's a s.7(3) gap — your strongest, most objective finding.
3. **Does it cover all eight s.7 disclosure items?** Purpose, source, access/correction rights, contact details, disclosure classes, choices for limiting processing, whether provision is obligatory, consequences of not providing.
4. **Consent on forms?** Unticked box, near the submit, linking to the notice? If there's no box, that's a big one.
5. **Contact details for data enquiries?** Named DPO or data protection contact?
6. **Retention stated?** Most notices say "we keep data as long as necessary", which is not a retention period.
7. **CCTV?** If they have cameras on premises, ask. Almost always missing from the notice.
8. **WhatsApp?** Where do enquiry details live? If it's in a personal WhatsApp, that's a finding.

Then send a **one-page summary**: what you found, what it means, what you'd do. No proposal attached unless they ask.

> **Important:** the gap check must be genuinely free and genuinely useful. If you gate the summary behind "book a call first", it stops being a diagnosis and becomes a trap. The whole reason this works is that it costs the prospect nothing.

---

## Discovery questions for the kickoff call

Ask these on the day-one call, in this order. They take 45 minutes and they're the difference between a notice that fits and one that doesn't.

**The data**
- Walk me through what happens from when a customer first contacts you to when the job is done. Where does their information go at each step?
- What systems hold customer information? (Accounting, CRM, POS, spreadsheets, email, WhatsApp.)
- Anyone's desktop holding a customer list in Excel? *(There almost always is. Don't make it a crime — just add it to the inventory.)*
- Do you have CCTV? Who watches it, how long is it kept, and is there a sign up?
- How do you handle HR — payroll in-house or outsourced? Where do CVs go?

**The reality check**
- Who actually decides things like this? *(You need the approver, not just the interested party.)*
- Has any client ever asked you about data protection or sent you a compliance questionnaire? *(If yes, this just became urgent and you should say so.)*
- Has anything ever gone wrong — a lost laptop, an email to the wrong person, a shared password situation? *(You're not looking for a confession. You're looking for whether a breach plan needs to be concrete.)*

**The scope**
- Do you take payments? *(Changes whether financial data is in scope.)*
- Any customers outside Malaysia? *(Cross-border.)*
- Any job applicants from overseas?

---

## Delivery in 10–14 hours

| Step | Time | Notes |
|---|---|---|
| Kickoff call | 1 hr | Use the questions above |
| Data inventory | 2–3 hrs | Sheet 1 of the workbook, filled with them |
| Retention schedule | 1 hr | Sheet 2 |
| Privacy notice drafting | 3–4 hrs | `02-privacy-notice-TEMPLATE.html`, fill the amber fields |
| Consent wording | 1 hr | `07-consent-wording-library.md` |
| Breach plan | 1–2 hrs | `03-breach-response-plan.html` — fill the names |
| Rights procedure | 1 hr | `04-data-subject-rights-procedure.html` |
| DPO check and pack | 1 hr | `05` — or confirm not required |
| Review and handover call | 1–2 hrs | Walk the team through the breach plan |
| **Total** | **~12–16 hrs** | Complete tier |

**The templates make client two onward dramatically faster.** First client: work out how you like to do it. Second client: 6–8 hours. That's where the margin lives.

### The one thing you must not skip

**The BM translation must be reviewed by a native speaker.** Not machine translation. You sell local expertise — sloppy BM undermines the entire pitch, and a client who notices will quietly discount everything else you've said. Budget for the review, or have someone in-house do it properly.

---

## Objection handling

**"We're too small for this."**
> "Probably true for the DPO requirement — that only bites above 20,000 people. But the privacy notice requirement has no size threshold. If you have a website form collecting names and phone numbers, it applies to you. Let me show you what's actually required for a business your size, and if it's less than you think, I'll tell you that."

**"We've never had a problem, so why bother?"**
> "Fair. You probably never will. But two things are worth considering: your bigger clients are starting to ask for a compliance position before they sign, and if something did happen, the difference between a 72-hour response and a two-week scramble is whether anyone wrote it down. Neither of those needs a fine to matter."

**"Can't I just download a template?"**
> "You can, and honestly for some businesses that's enough. The problem is the notice has to describe the data *you* hold for *your* purposes. A template that lists the wrong categories is worse than nothing — it documents a claim you can't stand behind. The template isn't the hard part; knowing what you actually have is."

**"Isn't this a legal matter? Shouldn't I use a lawyer?"**
> "For most SMEs, no — these are operational documents, not legal opinions. I'll say that in writing. If your business handles sensitive data at scale, or a client contract asks for a formal legal opinion, you need a lawyer as well, and I'll tell you that up front rather than have you find out later."

**"We already have a privacy policy."**
> "Send it and I'll review it free. Half the ones I see are English-only, which is the most common gap. It might just need updating rather than replacing, and if that's the case I'll tell you."

**"Send me a proposal."**
> "Happy to. Before I do, can I spend 30 minutes on a call? I'd rather the numbers reflect your actual setup than send you something generic."

---

## Where the pack leads

The pack is not the destination — it's the on-ramp.

```
Free gap check  →  PDPA Starter Pack  →  Managed IT retainer  →  Automation projects
   (free)            (RM 1.8-4.5k)         (RM 799-1,899/mo)      (RM 2.5-8k each)
```

**The natural next conversation**, once the pack is delivered and they've seen how you work:

> "While I was in your systems I noticed [X]. Two things worth flagging: your backup hasn't been tested, and your team is doing [manual task] by hand every week. Would it be useful if I wrote those up separately? No charge for the write-up — you can decide later whether you want help with them."

That's how a RM 1,999 project becomes a RM 1,899/month client. But **only say it if it's true** — and write up what you actually found, not what you'd like to sell.

---

## Scope boundaries — hold these firmly

| In scope | Out of scope |
|---|---|
| Privacy notice (BM + EN) | Legal advice or legal opinions |
| Consent wording and record-keeping | Legal representation or defending a complaint |
| Data inventory and retention schedule | Full technical security implementation |
| Breach response plan and register | Acting as their DPO on an ongoing basis (separate service) |
| Data subject rights procedure | Sector-specific regulation (BNM, MCMC, healthcare) |
| DPO appointment pack, if thresholds met | Data Protection Impact Assessments at scale |
| Staff one-pager | Negotiating their client contracts |

**Always include the disclaimer** (it's already in `offer-sheet.html`): not a law firm, not legal advice, recommend a lawyer where required. This protects you and it's the honest position.

**Refer out** when a client's needs exceed the scope — banking, healthcare, or a business processing sensitive data at scale. Referring a client to a lawyer who then refers them back is how you build a professional network, not lose a client. Send them to one you trust and tell them why.

---

## The two documents that make this repeatable

### The engagement letter (`client-pack/08`)

Send it with the quote, before the kickoff call. It is plain-language and reads as fair — which is deliberate, because a heavy-handed contract frightens off exactly the SME clients you want.

Five clauses do the real work. Do not let anyone strip them out:

| Clause | Why it matters |
|---|---|
| **§7 Not legal advice** | Explicitly states you are not a law firm, no solicitor–client relationship, no guarantee the Commissioner will accept the documents. **This is your protection.** Never remove it. |
| **§6 Client responsibilities** | They must give you accurate information, return the questionnaire in 5 working days, and get the Malay text reviewed natively. Without this, every delay and every wrong statement becomes your problem. |
| **§9 IP on payment | They own the documents about their business; you keep the templates. This is what lets you reuse the pack for the next 50 clients without argument. |
| **§12 Liability cap** | Capped at fees paid, no indirect loss, and explicitly no liability for fines or regulatory sanctions imposed on the client. |
| **§13 Termination** | Pro-rata payment for work done, and the right to walk away if asked to produce something misleading. |

There is also an automatic **BM courtesy summary** at the end ("Ringkasan terma utama") which states plainly that the English version prevails. It is not a translation and does not pretend to be — it means a Malay-speaking signatory isn't signing something they can't read at all.

**One-time cost worth paying:** have a Malaysian lawyer review this agreement once before you use it. Then reuse the reviewed version forever. The clause that a lawyer will most want to discuss is §12.

### The drafting prompt (`prompts/draft-the-pack.md`)

This is the difference between the pack being a product and being a chore.

1. Client fills in `09-kickoff-questionnaire.html` and presses **Copy answers as text**.
2. Paste into the prompt, set the tier, run it.
3. You get a first draft of the privacy notice, breach plan and rights procedure — plus a "decisions I made" list showing exactly where it filled a gap.
4. **You read every line before it reaches the client.**

The prompt's central rule is that the model must write `[[NEEDS CLIENT INPUT: ...]]` rather than invent a fact. A first draft will typically carry 10–25 of those markers. **That count is your to-do list** — it is the tool working correctly, not failing.

**The failure mode is fluency.** A confident, well-written paragraph asserting a retention period the client never gave you is worse than an obvious gap, because it reads as authoritative. Read the output the way you'd read a junior colleague's work: checking, not admiring.

**Still non-negotiable:** native Bahasa Malaysia review before publication. The prompt drafts both languages. It does not make the Malay version publishable on its own.

---

## Print layout — the thing that bites

The pack documents are print-first: clients print them, sign them and put them in a drawer. Four of them
originally ended with a page holding nothing but the footer or a signature block, which looks unfinished.

Three rules learned the hard way:

1. **Measure at the true print width, not the screen width.** The content box is **703px** wide at
   `@page{size:A4;margin:12mm}`. Measuring at 900px or 1000px gives falsely reassuring numbers, and — worse —
   a `@media (max-width:760px)` breakpoint is *wider* than the print content area, so print silently inherits
   the **mobile** layout. That is what broke the offer sheet.
2. **`.note`, `.plain`, `.sign` and `tr` are `break-inside:avoid`.** A 900px unbreakable block cannot fill the
   bottom of a page, so it jumps whole to the next one. If a block is taller than about two-thirds of a page,
   either let it break (`.plain.letter{break-inside:auto}`) or split it into two blocks.
3. **A footer stranded on its own page is a `break-before` problem.** `break-before:avoid` on `.foot` and
   `.sign` pulls them back — but only if there is genuinely room. Otherwise compact the body.

The shared print rhythm lives at the bottom of `_pack.css`. Per-document overrides sit in a scoped
`<style>` block in 04, 05 and 08 where those documents needed more than the shared settings.

**After changing any pack document, re-check the page count.** Two commands, from `/home/user/tools`:

```bash
node final4.js          # page count, disclaimer presence, JS errors — all 7 docs
node fill.js <file>.html   # per-page fill %, to catch a near-empty last page
```

### Session setup

`node_modules` and browser binaries are stripped from every workspace snapshot — the exclusion applies to
the directory *name* at any depth, so a renamed copy does not survive either. Scripts do survive. Run this
once per session to rebuild the harness (~25 seconds, verified from scratch):

```bash
bash /home/user/tools/setup.sh
```

It installs system libraries, node packages into `tools/deps/`, creates the `tools/node_modules` symlink so
`tools/*.js` can `require('playwright')` unmodified, installs Chromium, and prints `LAUNCH OK`.

Playwright does not survive a session reset. Reinstall manually with:

```bash
cd /home/user/tools && npm i playwright@1.49.0 && npx playwright install chromium
sudo apt-get update && sudo apt-get install -y libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 \
  libatspi2.0-0 libxdamage1 libxkbcommon0 libasound2t64 libcups2 libdrm2 libgbm1 libxcomposite1 \
  libxfixes3 libxrandr2 libpango-1.0-0 libcairo2 poppler-utils
python3 -c "import PIL,numpy" || pip install pillow numpy
```

The verification harness lives in `/home/user/tools/`, which **is** snapshotted — unlike the old
`.arena/shot/` location, which was not, and cost a full reinstall this session.

---

## First 30 days plan

| Week | Action |
|---|---|
| 1 | Send the offer sheet to 20 warm contacts (past clients, enquiries, networking contacts). Run 3 free gap checks. |
| 2 | Deliver first pack. Publish a LinkedIn post: *"Most Malaysian SME privacy notices fail s.7(3) because they're English-only. Here's what to check."* |
| 3 | Ask the first client for a testimonial **while they're happy** — the day you hand over is the right day. |
| 4 | Raise the price to RM 2,200 for Essential / RM 3,200 for Complete once you have one delivered reference. |

**Track:** gap checks booked → packs sold → retainer conversions. Three numbers. Nothing else matters yet.

---

## Files in this pack

**All document PDFs are pre-rendered** into `client-pack/*.pdf` alongside the HTML, so a pack can be
emailed without opening a browser. Page counts are print-verified (A4, 12mm margins, `_pack.css`):

| Doc | HTML | Pages |
|---|---|---|
| 02 Privacy notice template | ✅ | 5 |
| 03 Breach response plan | ✅ | 3 |
| 04 Data subject rights procedure | ✅ | 2 |
| 05 DPO appointment pack | ✅ | 3 |
| 06 Staff one-pager | ✅ | 2 |
| 08 Engagement letter / SOW | ✅ | 6 |
| 09 Kickoff questionnaire | ✅ | 3 |

| File | Goes to client? | Purpose |
|---|---|---|
| `offer-sheet.html` | ✅ | The pitch. Print to PDF and send. |
| `client-pack/01-data-inventory-retention-and-registers.xlsx` | ✅ | Fill in with them |
| `client-pack/02-privacy-notice-TEMPLATE.html` | ✅ (filled) | The notice — 37 amber fields to complete |
| `client-pack/03-breach-response-plan.html` | ✅ | Fill the names, print, hand over |
| `client-pack/04-data-subject-rights-procedure.html` | ✅ | Includes the 21-day deadline |
| `client-pack/05-dpo-appointment-pack.html` | ✅ (if threshold met) | Appointment letter + registration steps |
| `client-pack/06-staff-one-pager.html` | ✅ | Print and give to the team |
| `client-pack/08-engagement-letter-and-sow.html` | ✅ signed | **The contract.** Fixed price, scope, not-legal-advice clause, liability cap |
| `client-pack/09-kickoff-questionnaire.html` | ✅ (filled by them) | The input to everything. Has a working DPO threshold calculator |
| `client-pack/07-consent-wording-library.md` | ➖ internal | Copy-paste wording for every collection point |
| `prompts/draft-the-pack.md` | ➖ internal | **The leverage.** Questionnaire → first draft in one pass |
| `delivery-checklist.md` | ➖ internal | Don't skip steps |
| `PRODUCT-GUIDE.md` | ➖ internal | This document |
| `../outreach/pdpa-outreach-pack.md` | ➖ internal | Cold email sequence, gap-check summary template, objection handling |
