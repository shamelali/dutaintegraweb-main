# Consent wording library

Copy-paste wordings for every place your business collects personal data. Replace `[bracketed]` items.

**Why exact wording matters:** under the PDPA you need consent you can *evidence*, and the notice must reach the person when you first ask for their data — not later, and not buried. Vague consent is consent you cannot rely on, and it is the first thing that fails when someone complains.

---

## 1. Website enquiry / contact form

Place directly **above the submit button**, never below it or in the footer.

```
[ ] I agree to [Company Name] contacting me about this enquiry.

I have read the Privacy Notice at [URL] and understand that my details
will be used only to respond to this enquiry, in line with Malaysia's
Personal Data Protection Act 2010. I can withdraw my consent at any time
by contacting [email].

* Required
```

**Rules:**

- Must be **unticked by default** — a pre-ticked box is not consent.
- Must be **required to submit**, and the data must be genuinely needed to respond. Don't bundle unrelated marketing into it.
- Add a **second, separate, optional** checkbox if you want to send marketing. Never combine the two.

```
[ ] (Optional) Send me occasional updates about [Company] services.
    You can unsubscribe at any time.
```

---

## 2. WhatsApp enquiry

Your WhatsApp Business greeting and away message should include:

```
Thanks for messaging [Company Name].

By messaging us you agree that we may use the details you provide to
respond to your enquiry, in line with our Privacy Notice: [URL]

We don't add you to marketing lists. Reply STOP any time to opt out.
```

**Note:** if you keep enquiry details in WhatsApp itself, say so in your privacy notice. WhatsApp is a location where personal data lives, and it is routinely missed off data inventories.

---

## 3. Paper forms and sign-in sheets

At the top of the form, in **both BM and English**:

```
Pengumpulan Data / Data Collection Notice

Your personal data is collected and processed by [Company Name] for the
purpose of [e.g. site access records / membership registration]. It will
not be disclosed to third parties except where required by law. Our full
Privacy Notice is available at [URL] and at our office.

Maklumat peribadi anda dikumpul oleh [Company Name] untuk tujuan
[contoh: rekod akses premis]. Ia tidak akan didedahkan kepada pihak ketiga
melainkan dikehendaki oleh undang-undang. Notis Privasi penuh kami boleh
didapati di [URL].
```

---

## 4. Customer sign-up / registration

```
Personal Data Notice

We need the following information to [state the actual purpose]:
  - Name  — to identify you and address you correctly
  - Email — to send [invoices / confirmations / service updates]
  - Phone — to contact you about [orders / appointments]
  - [Other fields — state the reason for each]

We will not use this information for anything else without asking you first.
We keep it for [period] and then delete it. Full details, including your
rights and our breach notification obligations, are in our Privacy Notice:
[URL]

[ ] I agree to the processing of my personal data as described above.
```

**The strongest version of this** tells the person *why each field is needed*. It reduces friction, cuts down on fake data, and is the kind of specificity that makes a notice credible rather than boilerplate.

---

## 5. Job applications

```
Data Protection Notice for Job Applicants

We will use your application and CV only to assess your suitability for
this role. If you are unsuccessful, we will keep your details for a further
[6 months] in case a suitable role arises, and then securely delete them.

We will not share your application outside [Company Name] without your
permission. Our full Privacy Notice, including your rights of access and
correction, is at [URL].

[ ] I consent to [Company Name] holding my application for [6 months]
    after this recruitment process ends.
```

---

## 6. Email marketing opt-in — always separate

```
[ ] Yes, send me occasional news and offers from [Company Name].
    I can unsubscribe with one click at any time.
```

**Do not** make this a condition of signing up, purchasing, or receiving a quote. Bundled marketing consent is not freely given consent, and it is the most common weakness we find in SME consent records.

---

## 7. Withdrawal of consent

You must make this easy, and you must act promptly. Suggested flow:

> **Withdrawing consent:** email [address] with the subject "Withdraw consent", or reply STOP to any message. We will confirm within [3] working days and stop the processing. Withdrawing consent does not affect processing already carried out, and it does not stop us contacting you about a service you are already receiving.

Keep a record of every withdrawal — date, who, and what was actioned.

---

## 8. Consent record — what to keep

For every consent, record:

| Field | Why |
|---|---|
| Who consented | Name / identifier |
| When | Date and time |
| What exactly they agreed to | The wording shown, not a summary |
| How they gave it | Web form, paper form, WhatsApp, verbal with whom |
| Which notice version | Notice version number or effective date |
| Their IP address (web forms) | Technical evidence of the submission |
| Withdrawal date, if any | And what you did about it |

**The practical test:** if someone complained tomorrow that they never agreed, could you show what they saw and when? If the answer is a shrug, the consent is not evidenced.

---

## Common mistakes to avoid

| Mistake | Why it fails |
|---|---|
| Pre-ticked checkboxes | Not freely given consent |
| Marketing bundled with service consent | Consent must be specific to each purpose |
| "By using this site you agree…" as the only consent | Implied consent is weak, and it doesn't meet the s.7 notice requirement |
| Notice only in English | s.7(3) requires Bahasa Malaysia **and** English |
| Notice in the footer, far from the form | The notice must reach them when you first ask for the data |
| "We may share your data with our partners" | Fails the Disclosure Principle — name the parties or categories |
| No record of what they agreed to | Consent you cannot evidence is consent you cannot rely on |
