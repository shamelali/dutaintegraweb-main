# Delivery checklist — PDPA Starter Pack

Print this. Work down it. Don't skip steps because you're confident — the steps you skip are the ones that generate a rework conversation two weeks later.

---

## Before you quote

- [ ] Ran the 30-minute gap check (see `PRODUCT-GUIDE.md`)
- [ ] Sent the one-page gap summary — **free, no proposal attached**
- [ ] Confirmed who the actual approver is (not just the interested party)
- [ ] Checked whether BNM / MCMC / healthcare / other sector rules apply → if yes, this is **not** our scope, refer out
- [ ] Checked the DPO thresholds against their real numbers
- [ ] Quoted a tier. **Fixed price.** No "from" language.

---

## Kickoff call (45 min)

- [ ] Walked the customer journey end to end, noting where personal data lands
- [ ] Listed every system holding personal data — including spreadsheets and WhatsApp
- [ ] Asked about CCTV: yes/no, who watches, retention, signage
- [ ] Asked about HR: payroll in/out of house, where CVs are stored
- [ ] Asked about payments → whether financial data is in scope
- [ ] Asked about overseas customers, suppliers or applicants → cross-border
- [ ] Asked whether any client has sent a compliance questionnaire (if yes, flag urgency)
- [ ] Confirmed the **data protection contact** or DPO name and their dedicated email
- [ ] Agreed the review date and the go-live date

---

## Build the documents

### Data inventory and retention (workbook sheets 1–2)

- [ ] Every row of the inventory filled — no "misc" entries
- [ ] Each row states **where** it lives, **who** can access it, and **why** it's held
- [ ] Retention period set for every category, with the reason
- [ ] Retention schedule and privacy notice **agree** — check them side by side
- [ ] Deleted the five worked example rows from the inventory

### Privacy notice (`client-pack/02`)

- [ ] All 37 amber fields replaced — `grep -c 'background:#fde68a'` returns 0
- [ ] Company name, SSM number and registered address correct
- [ ] Purposes match the inventory exactly
- [ ] Processors **named**, not described vaguely
- [ ] Retention table matches the schedule
- [ ] Section 8 security claims are **true** — you can defend every one
- [ ] Cookies section says what they actually use
- [ ] DPO paragraph present **only if** a DPO is genuinely appointed
- [ ] **Bahasa Malaysia reviewed by a native speaker** — not machine translated
- [ ] Both languages published in full, not hidden behind a JS toggle
- [ ] Client has approved the final text in writing

### Consent (`client-pack/07`)

- [ ] Wording added to every collection point: web form, WhatsApp, paper forms, sign-up
- [ ] Checkboxes **unticked by default**
- [ ] Marketing consent is separate from service consent
- [ ] Consent record mechanism agreed (what gets stored, and where)

### Breach plan (`client-pack/03`)

- [ ] Three names filled in — incident lead, notifier, comms
- [ ] **Backup named for each role**, and each person knows they're on it
- [ ] Contact numbers correct and reachable
- [ ] Printed and physically filed somewhere — not just emailed
- [ ] Registered in the breach register is understood (sheet 4 of the workbook)

### Rights procedure (`client-pack/04`)

- [ ] Handler and decision maker named
- [ ] Team knows the **21-day** clock
- [ ] Identity verification method agreed and proportionate

### DPO pack (`client-pack/05`) — only if thresholds met

- [ ] Threshold assessment documented
- [ ] DPO meets the requirements (Malaysia-resident or contactable, BM + English)
- [ ] **Dedicated DPO email created** — not a shared inbox
- [ ] Letter of appointment signed
- [ ] Registration completed at `daftar.pdp.gov.my` **within 21 days**
- [ ] If **not** required: reasoning documented and shared with the client

### Staff one-pager (`client-pack/06`)

- [ ] Printed and distributed
- [ ] Team briefed on **who to tell within the hour** if something goes wrong

---

## Handover

- [ ] 60-minute walkthrough with the team (Complete tier and above)
- [ ] Breach plan walked through as a **scenario** — "you've just found an email sent to the wrong person, what happens next?" Walk it, don't read it.
- [ ] Notice live on their website, link tested, both languages rendering
- [ ] Consent checkbox live on their forms, and you've submitted a test entry
- [ ] All documents handed over in an editable format **and** PDF
- [ ] Client told plainly: **the documents are theirs to keep and reuse**

---

## Ask for the testimonial — the same day

- [ ] Asked on handover day, while they're happy
- [ ] Requested something specific: *"what changed, with a number if possible"*
- [ ] Got permission to name them, or agreed an anonymisation level

See `../../docs/TESTIMONIAL-KIT.md`. **Handover day is the highest-probability moment. Miss it and it becomes an awkward email three weeks later.**

---

## 30 days after

- [ ] Follow-up: has anything come up? Any questions from their team?
- [ ] Flagged the two things you noticed in their systems (backups, manual work) — **only if true**
- [ ] Asked whether they'd like a quote for the managed IT retainer
- [ ] Logged the outcome and lessons for the next delivery

---

## Internal: what to fix for next time

- [ ] How long did it actually take? (Target: 12–16 hrs first client, 6–8 hrs after.)
- [ ] Which template needed the most rework? Fix the template, not the process.
- [ ] Where did the client hesitate? That's your next objection-handling line.
- [ ] Did the BM review catch anything? If you skipped it, note what it cost you.
