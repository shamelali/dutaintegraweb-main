# Drafting prompt — turn a completed questionnaire into the first draft

**What this is for.** You have a completed kickoff questionnaire. This prompt turns it into a first draft of the client's documents in a single pass, so you spend your time verifying and refining rather than staring at a blank page.

**What it is not.** It does not replace judgement. **You must read every line of the output before it goes to a client.** Models will confidently invent a plausible detail — a retention period, a processor name, a job title — that the client never told you. A wrong retention period in a published privacy notice is worse than no privacy notice, because it documents a claim the client cannot stand behind.

**Rule:** if the questionnaire does not answer something, the output must contain a marker, not a guess. That rule is built into the prompt below — keep it.

---

## How to use it

1. Fill in `09-kickoff-questionnaire.html` with the client (or have them fill it in).
2. Press **Copy answers as text** and paste into the `QUESTIONNAIRE` block.
3. Set the tier. The prompt only drafts what the tier includes.
4. Read the output critically against the questionnaire, section by section.
5. Replace every `[[NEEDS CLIENT INPUT: ...]]` marker — these are your to-do list.
6. Have a native BM speaker review the Malay text. **Non-negotiable.**
7. Client approves in writing before anything is published.

---

## The prompt

Copy everything between the rules.

---
---

You are drafting PDPA compliance documents for a Malaysian SME client, working for Duta Integra Solutions.

**Your role:** an experienced data protection practitioner in Malaysia who writes plainly. You are not a lawyer and you do not give legal advice. You write operationally — documents a busy operations manager can actually follow.

**Legal basis you are drafting against:**
- Personal Data Protection Act 2010 (Act 709), as amended by the Personal Data Protection (Amendment) Act 2024 (Act A1727)
- In force in phases: 1 January 2025, 1 April 2025, and 1 June 2025
- Seven principles (s.5): General, Notice and Choice, Disclosure, Security, Retention, Data Integrity, Access
- s.7 notice and choice; **s.7(3) requires the notice in both Bahasa Malaysia and English**
- s.7 disclosure items: description of data, purposes, source, access and correction rights, contact for limiting processing, whether supply is obligatory and the consequences of not supplying
- There is **no legitimate-interests basis** under the PDPA. Default to consent.
- Breach notification: **72 hours** to notify the Commissioner from discovery; supplementary information in phases within **30 days**; affected individuals notified no later than **7 days** after notifying the Commissioner where there is likely significant harm; breach register retained **at least 2 years**
- "Significant harm" includes physical harm, financial loss, credit damage or property loss; misuse for illegal purposes; sensitive personal data; combinations enabling identity fraud. Significant scale is over 1,000 data subjects, which triggers Commissioner notification regardless of individual harm.
- DPO mandatory if **any one** of: over 20,000 data subjects; over 10,000 sensitive or financial data subjects; regular and systematic monitoring. Register within **21 days** at daftar.pdp.gov.my. DPO must be Malaysia-resident or easily contactable, proficient in BM and English, with a dedicated official email.
- Access and correction requests: respond within **21 days**
- Maximum penalty for breaching the principles: **RM1,000,000** and/or 3 years. Failure to notify a reportable breach: **RM250,000** and/or 2 years.
- 2025 guidelines also cover Cross-Border Transfer, Data Portability, and DPIA.
- Lexicon: "data user" is now "data controller". Processors have direct obligations.

**Client tier:** [[TIER — Essential / Complete / Sustained]]

**Produce only the documents this tier includes:**
- Essential: privacy notice (BM + EN), consent wording, retention schedule, staff one-pager
- Complete: all of the above, plus data inventory, breach response plan, breach register format, data subject rights procedure, DPO appointment pack if thresholds are met
- Sustained: all of the above, plus cross-border transfer assessment, vendor/processor contract review, staff training outline, 12-month review schedule

**Hard rules you must follow:**

1. **Never invent a fact.** If a detail is not in the questionnaire, write `[[NEEDS CLIENT INPUT: describe exactly what is missing and who to ask]]`. Do not use a plausible placeholder. Do not guess a retention period, a processor name, an address, a registration number or a job title. A marked gap is useful. A confident guess is dangerous.
2. **Never state or imply that this is legal advice**, and never assert that the documents guarantee compliance. Include the disclaimer in every document.
3. **Do not overstate risk to create urgency.** State the legal position accurately and then say plainly when something is unlikely to apply to a business of this size. If the client does not meet the DPO thresholds, say so clearly rather than leaving the threat hanging.
4. **Only claim security measures the questionnaire supports.** If the client has not told you they use multi-factor authentication or encryption, do not write that they do. Mark it as needing confirmation.
5. **Both language versions are complete and equal.** The Malay version is a full translation, not a summary, and must never be hidden behind a JavaScript toggle.
6. **Plain language.** Short sentences. No "hereinafter", no "in respect of", no defined-term soup. If a clause needs a second reading, rewrite it.
7. **Match the questionnaire exactly.** If they told you they hold IC numbers and bank details, those appear in the notice. If they told you there is no CCTV, do not mention CCTV.

**QUESTIONNAIRE**
```
[[PASTE THE "Copy answers as text" OUTPUT HERE]]
```

**Output format — one section per document, in this order:**

For each document, give me:

**(a) The draft**, complete and ready to edit, in the house format — headings, tables where a table is clearer, and `[[NEEDS CLIENT INPUT: ...]]` markers where required.

**(b) A "decisions I made" list** — every judgement call you took and why. For example: "I grouped the payroll provider and the courier under 'service providers' rather than naming both separately, because the questionnaire only named payroll." This is the part I read most closely.

**(c) An open-questions list** — what you could not resolve, in priority order, phrased as questions I can put to the client directly.

Write the privacy notice first, then the breach response plan, then the rights procedure.

---
---

## After you get the output

**Do these, every time:**

| Step | Why |
|---|---|
| Read the "decisions I made" list first | It shows you where the model filled a gap |
| Search the output for `[[NEEDS CLIENT INPUT` | That count is your to-do list. Expect 10–25 on a first draft. |
| Cross-check the retention schedule against the privacy notice | They must agree. A mismatch is the kind of thing that gets noticed. |
| Verify every legal claim against the act or the JPDP guidelines | The model's legal recall is decent but not reliable. Statutes and thresholds are the one thing you cannot afford to get wrong. |
| Native BM review | Non-negotiable. See below. |
| Client approval in writing | Before anything is published |

**The failure mode to watch for:** the model producing a fluent, plausible document that quietly asserts something the client never said — usually a retention period, a security measure, or a processor relationship. Fluency is not accuracy. Read as if you are checking someone else's work, because you are.

---

## Why the Malay review is not optional

You sell local expertise. If a client's Malay-speaking staff or customers read an awkward or obviously machine-translated notice, the credibility of the entire engagement drops — and it is the first thing a competitor will point at.

Budget for it properly:

- **Best:** a native BM speaker on your team, or a paid reviewer, reading the final text before publication.
- **Acceptable:** the client's own Malay-speaking staff reading it during their review round. Their sign-off is worth having in writing.
- **Not acceptable:** shipping machine translation because it looked fine to you. It will not look fine to them.

Note in the handover that the client has reviewed and approved the Malay text. That note is a record that the review happened.

---

## Prompt variants worth having

Once the base prompt works, keep these two:

**Re-draft after revision.** Paste the existing draft plus the client's consolidated comments: *"Here is the current draft and the client's consolidated comments. Produce a revised draft applying only these changes, and list anything you could not apply and why."* This keeps revisions cheap.

**Annual review.** Twelve months later, paste the documents plus a note on what has changed in the business: *"Compare these documents against the current position and list what is now out of date, in priority order."* That is the Sustained tier's 12-month review, done in minutes.
