"""Fail-closed settings: credentials are provisioned outside the repository."""
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    api_key: str
    admin_key: str
    approval_secret: bytes
    worker_count: int = 4
    queue_capacity: int = 128
    max_records: int = 1000
    job_timeout: float = 30
    approval_ttl: int = 300
    simulation_interval: float = 0
    astra_model_label: str = "GPT-6 Astra"
    sol_model_label: str = "GPT-8.1 Sol / GPT-Sol"
    # Lane overrides are optional so existing deployments can continue to use
    # queue_capacity, worker_count, and max_records as their defaults.
    telemetry_queue_capacity: int | None = None
    proposal_queue_capacity: int | None = None
    remediation_queue_capacity: int | None = None
    telemetry_worker_count: int | None = None
    proposal_worker_count: int | None = None
    remediation_worker_count: int | None = None
    telemetry_max_records: int | None = None
    proposal_max_records: int | None = None
    remediation_max_records: int | None = None
    telemetry_model_label: str = "GPT-Sol"
    proposal_model_label: str = "GPT-8.1 Sol"
    recovery_model_label: str = "fixed mock recovery"

    def __post_init__(self) -> None:
        if min(len(self.api_key), len(self.admin_key), len(self.approval_secret)) < 32:
            raise ValueError("Three independent secrets of at least 32 characters are required")
        if len({self.api_key.encode(), self.admin_key.encode(), self.approval_secret}) != 3:
            raise ValueError("Credentials and signing secret must be distinct")
        if not 1 <= self.worker_count <= 32 or not 1 <= self.queue_capacity <= 10000:
            raise ValueError("Invalid worker or queue capacity")
        if not 1 <= self.max_records <= 100000 or not 1 <= self.approval_ttl <= 3600:
            raise ValueError("Invalid retention or approval TTL")
        if not 0 < self.job_timeout <= 300 or not 0 <= self.simulation_interval <= 3600:
            raise ValueError("Invalid execution timing")
        for value in (
            self.telemetry_queue_capacity, self.proposal_queue_capacity,
            self.remediation_queue_capacity,
        ):
            if value is not None and not 1 <= value <= 10000:
                raise ValueError("Invalid per-lane queue capacity")
        for value in (
            self.telemetry_worker_count, self.proposal_worker_count,
            self.remediation_worker_count,
        ):
            if value is not None and not 1 <= value <= 32:
                raise ValueError("Invalid per-lane worker count")
        for value in (
            self.telemetry_max_records, self.proposal_max_records,
            self.remediation_max_records,
        ):
            if value is not None and not 1 <= value <= 100000:
                raise ValueError("Invalid per-lane retention limit")

    def lane_queue_capacity(self, lane: str) -> int:
        return getattr(self, f"{lane}_queue_capacity") or self.queue_capacity

    def lane_worker_count(self, lane: str) -> int:
        return getattr(self, f"{lane}_worker_count") or self.worker_count

    def lane_max_records(self, lane: str) -> int:
        return getattr(self, f"{lane}_max_records") or self.max_records

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            api_key=os.environ.get("DUTA_API_KEY", ""),
            admin_key=os.environ.get("DUTA_ADMIN_KEY", ""),
            approval_secret=os.environ.get("DUTA_APPROVAL_SECRET", "").encode(),
            simulation_interval=float(os.environ.get("DUTA_SIMULATION_INTERVAL", "0")),
            astra_model_label=os.environ.get("DUTA_ASTRA_MODEL", "GPT-6 Astra"),
            sol_model_label=os.environ.get("DUTA_SOL_MODEL", "GPT-8.1 Sol / GPT-Sol"),
            telemetry_queue_capacity=_optional_int("DUTA_TELEMETRY_QUEUE_CAPACITY"),
            proposal_queue_capacity=_optional_int("DUTA_PROPOSAL_QUEUE_CAPACITY"),
            remediation_queue_capacity=_optional_int("DUTA_REMEDIATION_QUEUE_CAPACITY"),
            telemetry_worker_count=_optional_int("DUTA_TELEMETRY_WORKERS"),
            proposal_worker_count=_optional_int("DUTA_PROPOSAL_WORKERS"),
            remediation_worker_count=_optional_int("DUTA_REMEDIATION_WORKERS"),
            telemetry_max_records=_optional_int("DUTA_TELEMETRY_MAX_RECORDS"),
            proposal_max_records=_optional_int("DUTA_PROPOSAL_MAX_RECORDS"),
            remediation_max_records=_optional_int("DUTA_REMEDIATION_MAX_RECORDS"),
            telemetry_model_label=os.environ.get("DUTA_TELEMETRY_MODEL", "GPT-Sol"),
            proposal_model_label=os.environ.get("DUTA_PROPOSAL_MODEL", "GPT-8.1 Sol"),
            recovery_model_label=os.environ.get("DUTA_RECOVERY_MODEL", "fixed mock recovery"),
        )


def _optional_int(name: str) -> int | None:
    value = os.environ.get(name)
    return None if value is None else int(value)
