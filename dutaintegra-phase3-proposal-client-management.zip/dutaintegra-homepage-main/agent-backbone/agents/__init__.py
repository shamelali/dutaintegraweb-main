"""Routing and queue lifecycle."""
