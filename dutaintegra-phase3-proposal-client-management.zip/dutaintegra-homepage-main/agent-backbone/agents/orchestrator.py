"""Astra policy router with isolated in-memory execution lanes.

The tracker is deliberately single-process memory.  It is a bounded adapter
contract, not a pretend durable queue or Redis implementation.
"""
import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Protocol
from uuid import uuid4

from execution.sol_workers import (
    ExecutionWorkers,
    GPT81SolProposalAdapter,
    GPTSolTelemetryAdapter,
)
from pipelines.approval import ApprovalStore
from schemas import (
    HealthSample,
    Job,
    JobKind,
    JobState,
    NodeId,
    ProposalInput,
    ProposalResult,
    TelemetryInput,
    TelemetryResult,
)
from settings import Settings

logger = logging.getLogger(__name__)


class CapacityError(Exception):
    pass


@dataclass(frozen=True)
class RecoveryCommand:
    request_id: str
    token: str
    workflow_id: str | None = None
    correlation_id: str | None = None


@dataclass(frozen=True)
class Message:
    job_id: str
    kind: JobKind
    payload: TelemetryInput | ProposalInput | RecoveryCommand
    workflow_id: str
    correlation_id: str
    node_id: NodeId


class RecoveryAdapter(Protocol):
    async def run(self, payload: RecoveryCommand, workflow_id: str, correlation_id: str) -> dict[str, Any]: ...


class MockRecoveryAdapter:
    """The only recovery adapter: approval-gated and explicitly non-mutating."""

    def __init__(self, approvals: ApprovalStore) -> None:
        self._approvals = approvals

    async def run(self, payload: RecoveryCommand, workflow_id: str, correlation_id: str) -> dict[str, Any]:
        return await self._approvals.execute(
            payload.request_id,
            payload.token,
            workflow_id=workflow_id,
            correlation_id=correlation_id,
        )


@dataclass(frozen=True)
class NodeRegistration:
    node_id: NodeId
    kind: JobKind
    model_label: str
    adapter: GPTSolTelemetryAdapter | GPT81SolProposalAdapter | RecoveryAdapter


class NodeRegistry:
    """Explicit typed mapping from each lane to its offline node adapter."""

    def __init__(self, workers: ExecutionWorkers, approvals: ApprovalStore, settings: Settings) -> None:
        self._nodes: dict[JobKind, NodeRegistration] = {
            JobKind.TELEMETRY: NodeRegistration(
                NodeId.GPT_SOL_TELEMETRY,
                JobKind.TELEMETRY,
                settings.telemetry_model_label,
                GPTSolTelemetryAdapter(workers),
            ),
            JobKind.PROPOSAL: NodeRegistration(
                NodeId.GPT_81_SOL_PROPOSAL,
                JobKind.PROPOSAL,
                settings.proposal_model_label,
                GPT81SolProposalAdapter(workers),
            ),
            JobKind.REMEDIATION: NodeRegistration(
                NodeId.MOCK_RECOVERY,
                JobKind.REMEDIATION,
                settings.recovery_model_label,
                MockRecoveryAdapter(approvals),
            ),
        }

    def for_kind(self, kind: JobKind) -> NodeRegistration:
        return self._nodes[kind]

    def bind_workers(self, workers: ExecutionWorkers) -> None:
        """Keep test/in-process adapter replacement scoped to the two Sol nodes."""
        telemetry = self._nodes[JobKind.TELEMETRY]
        proposal = self._nodes[JobKind.PROPOSAL]
        self._nodes[JobKind.TELEMETRY] = NodeRegistration(
            telemetry.node_id, telemetry.kind, telemetry.model_label, GPTSolTelemetryAdapter(workers)
        )
        self._nodes[JobKind.PROPOSAL] = NodeRegistration(
            proposal.node_id, proposal.kind, proposal.model_label, GPT81SolProposalAdapter(workers)
        )

    def all(self) -> tuple[NodeRegistration, ...]:
        return tuple(self._nodes.values())


class MessageTracker(Protocol):
    """A bounded memory adapter; distributed implementations need leases/acks."""

    async def submit(self, kind: JobKind, payload: TelemetryInput | ProposalInput | RecoveryCommand, *,
                     workflow_id: str | None = None, correlation_id: str | None = None) -> Job: ...
    async def claim(self, kind: JobKind = JobKind.TELEMETRY) -> Message: ...
    async def finish(self, job_id: str, result: dict[str, Any] | None, error: str | None) -> None: ...
    async def get(self, job_id: str) -> Job: ...


@dataclass
class _Lane:
    queue: asyncio.Queue[Message]
    max_records: int
    records: list[str]


class MemoryTracker:
    """Independent queue and retention quota for every job kind."""

    _PAYLOAD_TYPES = {
        JobKind.TELEMETRY: TelemetryInput,
        JobKind.PROPOSAL: ProposalInput,
        JobKind.REMEDIATION: RecoveryCommand,
    }

    def __init__(self, capacity: int, max_records: int, *,
                 lane_capacities: dict[JobKind, int] | None = None,
                 lane_max_records: dict[JobKind, int] | None = None) -> None:
        capacities = {kind: capacity for kind in JobKind}
        capacities.update(lane_capacities or {})
        retention = {kind: max_records for kind in JobKind}
        retention.update(lane_max_records or {})
        self.lanes: dict[JobKind, _Lane] = {
            kind: _Lane(asyncio.Queue(maxsize=capacities[kind]), retention[kind], [])
            for kind in JobKind
        }
        # Compatibility for callers that used the original telemetry queue.
        self.queue = self.lanes[JobKind.TELEMETRY].queue
        self.telemetry_queue = self.lanes[JobKind.TELEMETRY].queue
        self.proposal_queue = self.lanes[JobKind.PROPOSAL].queue
        self.remediation_queue = self.lanes[JobKind.REMEDIATION].queue
        self.jobs: dict[str, Job] = {}
        self._job_lanes: dict[str, JobKind] = {}
        self.accepting = True

    def queue_for(self, kind: JobKind) -> asyncio.Queue[Message]:
        return self.lanes[kind].queue

    async def submit(self, kind: JobKind, payload: TelemetryInput | ProposalInput | RecoveryCommand, *,
                     workflow_id: str | None = None, correlation_id: str | None = None) -> Job:
        expected_type = self._PAYLOAD_TYPES[kind]
        if not isinstance(payload, expected_type):
            raise ValueError(f"Payload does not match {kind.value} lane")
        lane = self.lanes[kind]
        # All checks and put_nowait happen without an await: atomic on this loop.
        if not self.accepting or lane.queue.full():
            raise CapacityError(f"{kind.value} queue unavailable or full")
        if len(lane.records) >= lane.max_records:
            removable = next((job_id for job_id in lane.records
                              if self.jobs[job_id].state in {JobState.SUCCEEDED, JobState.FAILED}), None)
            if removable is None:
                raise CapacityError(f"{kind.value} job history capacity reached")
            lane.records.remove(removable)
            del self.jobs[removable]
            del self._job_lanes[removable]

        if isinstance(payload, RecoveryCommand):
            effective_workflow = payload.workflow_id or workflow_id or str(uuid4())
            effective_correlation = payload.correlation_id or correlation_id or effective_workflow
        else:
            effective_workflow = workflow_id or str(uuid4())
            effective_correlation = correlation_id or effective_workflow
        job_id = str(uuid4())
        node_id = {
            JobKind.TELEMETRY: NodeId.GPT_SOL_TELEMETRY,
            JobKind.PROPOSAL: NodeId.GPT_81_SOL_PROPOSAL,
            JobKind.REMEDIATION: NodeId.MOCK_RECOVERY,
        }[kind]
        job = Job(id=job_id, kind=kind, workflow_id=effective_workflow,
                  correlation_id=effective_correlation, node_id=node_id)
        self.jobs[job_id] = job
        self._job_lanes[job_id] = kind
        lane.records.append(job_id)
        lane.queue.put_nowait(Message(job_id, kind, payload, effective_workflow,
                                      effective_correlation, node_id))
        return job.model_copy(deep=True)

    async def claim(self, kind: JobKind = JobKind.TELEMETRY) -> Message:
        message = await self.lanes[kind].queue.get()
        self.jobs[message.job_id].state = JobState.RUNNING
        return message

    async def finish(self, job_id: str, result: dict[str, Any] | None, error: str | None) -> None:
        job = self.jobs[job_id]
        job.state = JobState.FAILED if error else JobState.SUCCEEDED
        job.result, job.error = result, error
        self.lanes[self._job_lanes[job_id]].queue.task_done()

    async def get(self, job_id: str) -> Job:
        return self.jobs[job_id].model_copy(deep=True)

    async def drain(self) -> None:
        for kind, lane in self.lanes.items():
            while not lane.queue.empty():
                message = lane.queue.get_nowait()
                if message.job_id in self.jobs:
                    await self.finish(message.job_id, None, "shutdown_cancelled")


class AstraOrchestrator:
    def __init__(self, settings: Settings, workers: ExecutionWorkers, approvals: ApprovalStore) -> None:
        self.settings = settings
        self._workers = workers
        self.approvals = approvals
        lane_capacities = {kind: settings.lane_queue_capacity(kind.value) for kind in JobKind}
        lane_retention = {kind: settings.lane_max_records(kind.value) for kind in JobKind}
        self.tracker = MemoryTracker(settings.queue_capacity, settings.max_records,
                                     lane_capacities=lane_capacities,
                                     lane_max_records=lane_retention)
        self.registry = NodeRegistry(workers, approvals, settings)
        self._tasks: dict[JobKind, list[asyncio.Task[None]]] = {kind: [] for kind in JobKind}
        self._simulator: asyncio.Task[None] | None = None
        self.simulation_dropped = 0

    @property
    def workers(self) -> ExecutionWorkers:
        return self._workers

    @workers.setter
    def workers(self, value: ExecutionWorkers) -> None:
        self._workers = value
        if hasattr(self, "registry"):
            self.registry.bind_workers(value)

    async def start(self) -> None:
        for kind in JobKind:
            self._tasks[kind] = [asyncio.create_task(self._run(kind),
                              name=f"{self.registry.for_kind(kind).node_id}-{n}")
                                 for n in range(self.settings.lane_worker_count(kind.value))]
        if self.settings.simulation_interval:
            self._simulator = asyncio.create_task(self._simulate(), name="telemetry-simulator")

    async def stop(self) -> None:
        self.tracker.accepting = False
        if self._simulator:
            self._simulator.cancel()
            await asyncio.gather(self._simulator, return_exceptions=True)
        try:
            async with asyncio.timeout(self.settings.job_timeout + 1):
                await asyncio.gather(*(lane.queue.join() for lane in self.tracker.lanes.values()))
        except TimeoutError:
            pass
        all_tasks = [task for tasks in self._tasks.values() for task in tasks]
        for task in all_tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*all_tasks, return_exceptions=True)
        await self.tracker.drain()

    def health(self) -> dict[str, Any]:
        nodes: dict[str, dict[str, Any]] = {}
        for kind in JobKind:
            registration = self.registry.for_kind(kind)
            tasks = self._tasks[kind]
            nodes[registration.node_id.value] = {
                "kind": kind.value,
                "model_label": registration.model_label,
                "queue_depth": self.tracker.queue_for(kind).qsize(),
                "queue_capacity": self.tracker.queue_for(kind).maxsize,
                "worker_count": len(tasks),
                "workers_alive": sum(not task.done() for task in tasks),
            }
        aggregate = {
            "queue_depth": sum(node["queue_depth"] for node in nodes.values()),
            "queue_capacity": sum(node["queue_capacity"] for node in nodes.values()),
            "worker_count": sum(node["worker_count"] for node in nodes.values()),
            "workers_alive": sum(node["workers_alive"] for node in nodes.values()),
        }
        ready = self.tracker.accepting and bool(aggregate["worker_count"]) \
            and aggregate["workers_alive"] == aggregate["worker_count"] \
            and (self._simulator is None or not self._simulator.done())
        return {
            "ready": ready,
            "nodes": nodes,
            "aggregate": aggregate,
            # Existing clients used these aggregate-ish fields.
            "queue_depth": aggregate["queue_depth"],
            "worker_count": aggregate["worker_count"],
            "simulation_dropped": self.simulation_dropped,
            "execution_mode": "mock",
            "storage": "volatile_single_process",
            "astra_model_label": self.settings.astra_model_label,
            "sol_model_label": self.settings.sol_model_label,
        }

    async def _run(self, kind: JobKind) -> None:
        while True:
            message = await self.tracker.claim(kind)
            try:
                async with asyncio.timeout(self.settings.job_timeout):
                    result = await self._dispatch(message)
                await self.tracker.finish(message.job_id, result, None)
            except asyncio.CancelledError:
                # A claimed message must not remain RUNNING during shutdown.
                if message.job_id in self.tracker.jobs and self.tracker.jobs[message.job_id].state == JobState.RUNNING:
                    await self.tracker.finish(message.job_id, None, "shutdown_cancelled")
                raise
            except Exception as exc:
                logger.warning("job_failed id=%s type=%s", message.job_id, type(exc).__name__)
                await self.tracker.finish(message.job_id, None,
                                          "timeout" if isinstance(exc, TimeoutError) else "execution_failed")

    async def _dispatch(self, message: Message) -> dict[str, Any]:
        registration = self.registry.for_kind(message.kind)
        if message.kind is JobKind.TELEMETRY:
            if not isinstance(message.payload, TelemetryInput):
                raise ValueError("Telemetry lane received incompatible payload")
            result = TelemetryResult.model_validate(await registration.adapter.run(message.payload))
            if [f.service for f in result.findings] != [s.service for s in message.payload.samples]:
                raise ValueError("Telemetry output does not match input services")
            requests = []
            for sample, finding in zip(message.payload.samples, result.findings, strict=True):
                if finding.severity == "critical" or not sample.available or sample.error_count >= 10:
                    record = await self.approvals.create(
                        sample.service, message.job_id, message.workflow_id, message.correlation_id,
                    )
                    requests.append(record["id"])
            return {**result.model_dump(), "approval_request_ids": requests,
                    "review": "schema_and_safety_policy", "router_mode": "deterministic_mock",
                    "node_id": registration.node_id.value}
        if message.kind is JobKind.PROPOSAL:
            if not isinstance(message.payload, ProposalInput):
                raise ValueError("Proposal lane received incompatible payload")
            proposal = ProposalResult.model_validate(await registration.adapter.run(message.payload))
            return {**proposal.model_dump(), "node_id": registration.node_id.value}
        if not isinstance(message.payload, RecoveryCommand):
            raise ValueError("Remediation lane received incompatible payload")
        return {
            **await registration.adapter.run(message.payload, message.workflow_id, message.correlation_id),
            "node_id": registration.node_id.value,
        }

    async def _simulate(self) -> None:
        tick = 0
        while True:
            tick += 1
            payload = TelemetryInput(samples=[HealthSample(
                service="simulated-web", cpu_percent=40, memory_percent=50,
                error_count=12 if tick % 5 == 0 else 0, available=tick % 5 != 0,
            )])
            try:
                await self.tracker.submit(JobKind.TELEMETRY, payload)
            except CapacityError:
                self.simulation_dropped += 1
            await asyncio.sleep(self.settings.simulation_interval)
