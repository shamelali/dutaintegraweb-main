"""Validated messages shared by API, router, and execution workers."""
from enum import StrEnum
from typing import Annotated, Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class JobKind(StrEnum):
    TELEMETRY = "telemetry"
    PROPOSAL = "proposal"
    REMEDIATION = "remediation"


class NodeId(StrEnum):
    GPT_SOL_TELEMETRY = "gpt-sol-telemetry"
    GPT_81_SOL_PROPOSAL = "gpt-8.1-sol-proposal"
    MOCK_RECOVERY = "mock-recovery"
    UNASSIGNED = "unassigned"


class JobState(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class HealthSample(StrictModel):
    service: str = Field(pattern=r"^[a-zA-Z0-9_-]{1,64}$")
    cpu_percent: float = Field(ge=0, le=100)
    memory_percent: float = Field(ge=0, le=100)
    error_count: int = Field(ge=0, le=1000000)
    available: bool


class TelemetryInput(StrictModel):
    samples: list[HealthSample] = Field(min_length=1, max_length=100)


class Finding(StrictModel):
    service: str
    severity: str = Field(pattern=r"^(healthy|warning|critical)$")
    reasons: list[str]


class TelemetryResult(StrictModel):
    findings: list[Finding]
    execution_mode: str = "mock"
    model_label: str


class CostItem(StrictModel):
    description: str = Field(min_length=1, max_length=200)
    quantity: int = Field(ge=1, le=10000)
    unit_cost: Annotated[str, Field(pattern=r"^\d{1,9}(\.\d{1,2})?$")]


class ProposalInput(StrictModel):
    customer: str = Field(min_length=1, max_length=200)
    hardware: list[CostItem] = Field(max_length=100)
    labor: list[CostItem] = Field(max_length=100)
    sla_monthly_cost: Annotated[str, Field(pattern=r"^\d{1,9}(\.\d{1,2})?$")]
    sla_months: int = Field(ge=1, le=60)
    sla_response_hours: int = Field(ge=1, le=168)
    currency: str = Field(default="MYR", pattern=r"^[A-Z]{3}$")


class ProposalResult(StrictModel):
    blueprint: dict[str, Any]
    markdown: str
    execution_mode: str = "mock"
    model_label: str


class Job(StrictModel):
    id: str
    kind: JobKind
    state: JobState = JobState.QUEUED
    workflow_id: str = Field(default_factory=lambda: str(uuid4()))
    correlation_id: str = Field(default_factory=lambda: str(uuid4()))
    node_id: NodeId = NodeId.UNASSIGNED
    result: dict[str, Any] | None = None
    error: str | None = None


class ExecuteApproval(StrictModel):
    token: str = Field(pattern=r"^[a-f0-9]{64}$")
