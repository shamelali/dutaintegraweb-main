"""Behavioral tests for the offline Sol workers."""

from __future__ import annotations

import asyncio

from execution.sol_workers import ExecutionWorkers, SolWorkers
from schemas import CostItem, HealthSample, ProposalInput, TelemetryInput


def test_telemetry_thresholds_and_mock_metadata() -> None:
    worker = SolWorkers()
    result = asyncio.run(
        worker.analyze_telemetry(
            TelemetryInput(
                samples=[
                    HealthSample(
                        service="api",
                        cpu_percent=84.99,
                        memory_percent=84.99,
                        error_count=0,
                        available=True,
                    ),
                    HealthSample(
                        service="worker",
                        cpu_percent=85,
                        memory_percent=10,
                        error_count=1,
                        available=True,
                    ),
                    HealthSample(
                        service="db",
                        cpu_percent=1,
                        memory_percent=1,
                        error_count=10,
                        available=False,
                    ),
                ]
            )
        )
    )

    assert [finding.severity for finding in result.findings] == [
        "healthy",
        "warning",
        "critical",
    ]
    assert any("85%" in reason for reason in result.findings[1].reasons)
    assert any("unavailable" in reason for reason in result.findings[2].reasons)
    assert result.execution_mode == "mock"
    assert result.model_label == "GPT-8.1 Sol / GPT-Sol"


def test_worker_satisfies_future_adapter_protocol() -> None:
    assert isinstance(SolWorkers(), ExecutionWorkers)


def test_proposal_uses_decimal_totals_and_escapes_markdown() -> None:
    worker = SolWorkers(model_label="local-sol-label")
    result = asyncio.run(
        worker.generate_proposal(
            ProposalInput(
                customer="Acme *review*",
                hardware=[CostItem(description="Node [A]", quantity=2, unit_cost="10.25")],
                labor=[CostItem(description="Setup", quantity=3, unit_cost="5.10")],
                sla_monthly_cost="7.50",
                sla_months=4,
                sla_response_hours=8,
                currency="MYR",
            )
        )
    )

    assert result.blueprint["totals"] == {
        "hardware": "20.50",
        "labor": "15.30",
        "sla": "30.00",
        "grand_total_before_tax": "65.80",
    }
    assert result.blueprint["status"] == "draft"
    assert "Acme \\*review\\*" in result.markdown
    assert "Node \\[A\\]" in result.markdown
    assert "No uptime guarantee or legally binding commitment" in result.markdown
    assert result.execution_mode == "mock"
    assert result.model_label == "local-sol-label"


def test_empty_cost_categories_still_produce_zero_totals() -> None:
    result = asyncio.run(
        SolWorkers().generate_proposal(
            ProposalInput(
                customer="Small customer",
                hardware=[],
                labor=[],
                sla_monthly_cost="0",
                sla_months=1,
                sla_response_hours=1,
            )
        )
    )

    assert result.blueprint["totals"]["grand_total_before_tax"] == "0.00"
