import asyncio
from unittest.mock import patch

import pytest

from pipelines.approval import ApprovalStore


def test_signature_binding_replay_and_concurrent_execution() -> None:
    async def scenario() -> None:
        store = ApprovalStore(b"s" * 32)
        first = await store.create("web", "job-1")
        second = await store.create("db", "job-2")
        with pytest.raises(ValueError):
            await store.execute(first["id"], "0" * 64)
        approved = await store.approve(first["id"], "admin")
        await store.approve(second["id"], "admin")
        with pytest.raises(ValueError):
            await store.execute(second["id"], approved["token"])
        with pytest.raises(ValueError):
            await store.execute(first["id"], "0" * 64)
        results = await asyncio.gather(
            store.execute(first["id"], approved["token"]),
            store.execute(first["id"], approved["token"]), return_exceptions=True,
        )
        assert sum(isinstance(result, ValueError) for result in results) == 1
        assert (await store.get(first["id"]))["state"] == "succeeded"
        assert "token" not in await store.get(first["id"])
        with pytest.raises(ValueError):
            await store.execute(first["id"], approved["token"])
    asyncio.run(scenario())


def test_expiry_rejection_capacity_and_deduplication() -> None:
    async def scenario() -> None:
        store = ApprovalStore(b"s" * 32, ttl_seconds=1, max_records=1)
        with patch("pipelines.approval.time.time", return_value=100):
            record = await store.create("web", "job")
            assert (await store.create("web", "job2"))["id"] == record["id"]
            with pytest.raises(ValueError):
                await store.create("db", "job2")
            token = (await store.approve(record["id"], "admin"))["token"]
        with patch("pipelines.approval.time.time", return_value=102):
            with pytest.raises(ValueError):
                await store.execute(record["id"], token)
            assert (await store.get(record["id"]))["state"] == "expired"
            other = await store.create("db", "job2")
            await store.reject(other["id"], "admin")
            with pytest.raises(ValueError):
                await store.approve(other["id"], "admin")
    asyncio.run(scenario())


def test_cancellation_fails_closed() -> None:
    async def scenario() -> None:
        store = ApprovalStore(b"s" * 32)
        record = await store.create("web", "job")
        approved = await store.approve(record["id"], "admin")
        task = asyncio.create_task(store.execute(record["id"], approved["token"]))
        await asyncio.sleep(0)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        assert (await store.get(record["id"]))["state"] == "failed"
    asyncio.run(scenario())
