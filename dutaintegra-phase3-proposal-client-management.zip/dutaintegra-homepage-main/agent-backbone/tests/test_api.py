import time
from typing import Any

import pytest
from fastapi.testclient import TestClient

from main import create_app
from settings import Settings

CONFIG = Settings(api_key="a" * 32, admin_key="b" * 32, approval_secret=b"c" * 32)
AUTH = {"Authorization": f"Bearer {CONFIG.api_key}"}
ADMIN = {**AUTH, "X-Admin-Key": CONFIG.admin_key}
TELEMETRY = {"samples": [{"service": "mock-web", "cpu_percent": 40,
                         "memory_percent": 50, "error_count": 12, "available": False}]}
PROPOSAL = {"customer": "Example <script>", "hardware": [
    {"description": "Server | rack", "quantity": 3, "unit_cost": "0.10"}],
    "labor": [{"description": "Setup", "quantity": 2, "unit_cost": "50.25"}],
    "sla_monthly_cost": "100.00", "sla_months": 12, "sla_response_hours": 4}


def wait_job(client: TestClient, job_id: str) -> dict[str, Any]:
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        response = client.get(f"/v1/jobs/{job_id}", headers=AUTH)
        assert response.status_code == 200
        job = response.json()
        if job["state"] in {"succeeded", "failed"}:
            return job
        time.sleep(0.005)
    raise AssertionError("Job did not finish")


def test_full_telemetry_approval_recovery_flow() -> None:
    with TestClient(create_app(CONFIG)) as client:
        assert client.get("/health/ready", headers=AUTH).json()["ready"]
        assert client.post("/v1/telemetry", json=TELEMETRY).status_code == 401
        response = client.post("/v1/telemetry", json=TELEMETRY, headers=AUTH)
        assert response.status_code == 202
        job = wait_job(client, response.json()["id"])
        assert job["state"] == "succeeded"
        request_id = job["result"]["approval_request_ids"][0]
        base = f"/v1/approvals/{request_id}"
        assert client.get(base, headers=AUTH).json()["state"] == "pending"
        assert client.post(base + "/approve", headers=AUTH).status_code == 403
        approved = client.post(base + "/approve", headers=ADMIN)
        assert approved.status_code == 200
        token = approved.json()["token"]
        assert client.post(base + "/execute", headers=AUTH, json={"token": token}).status_code == 403
        result = client.post(base + "/execute", headers=ADMIN, json={"token": token})
        recovery = wait_job(client, result.json()["id"])
        assert recovery["state"] == "succeeded"
        assert recovery["result"]["production_mutated"] is False
        replay = client.post(base + "/execute", headers=ADMIN, json={"token": token})
        assert wait_job(client, replay.json()["id"])["state"] == "failed"


def test_proposal_validation_and_decimal_totals() -> None:
    with TestClient(create_app(CONFIG)) as client:
        response = client.post("/v1/proposals", json=PROPOSAL, headers=AUTH)
        result = wait_job(client, response.json()["id"])["result"]
        assert result["blueprint"]["totals"]["grand_total_before_tax"] == "1300.80"
        assert result["blueprint"]["status"] == "draft"
        assert "<script>" not in result["markdown"]
        assert "\\|" in result["markdown"]
        bad = {**PROPOSAL, "sla_monthly_cost": "-1"}
        assert client.post("/v1/proposals", json=bad, headers=AUTH).status_code == 422
        assert client.post("/v1/telemetry", json={**TELEMETRY, "command": "restart"}, headers=AUTH).status_code == 422
        assert client.get("/v1/jobs/missing", headers=AUTH).status_code == 404


def test_startup_requires_independent_credentials() -> None:
    with pytest.raises(ValueError):
        Settings(api_key="", admin_key="", approval_secret=b"")
    with pytest.raises(ValueError):
        Settings(api_key="a" * 32, admin_key="a" * 32, approval_secret=b"c" * 32)
