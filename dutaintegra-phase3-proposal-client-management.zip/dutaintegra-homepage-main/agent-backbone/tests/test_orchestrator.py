import asyncio
from dataclasses import replace

import pytest

from agents.orchestrator import (
    AstraOrchestrator,
    CapacityError,
    MemoryTracker,
    RecoveryCommand,
)
from execution.sol_workers import SolWorkers
from pipelines.approval import ApprovalStore
from schemas import (
    HealthSample,
    JobKind,
    JobState,
    ProposalInput,
    TelemetryInput,
    TelemetryResult,
)
from settings import Settings


def payload() -> TelemetryInput:
    return TelemetryInput(samples=[HealthSample(service="mock", cpu_percent=20,
        memory_percent=20, error_count=0, available=True)])


def test_bounded_admission_and_retention() -> None:
    async def scenario() -> None:
        tracker = MemoryTracker(1, 1)
        first = await tracker.submit(JobKind.TELEMETRY, payload())
        with pytest.raises(CapacityError):
            await tracker.submit(JobKind.TELEMETRY, payload())
        await tracker.claim()
        with pytest.raises(CapacityError):
            await tracker.submit(JobKind.TELEMETRY, payload())
        await tracker.finish(first.id, {}, None)
        await tracker.submit(JobKind.TELEMETRY, payload())
        with pytest.raises(KeyError):
            await tracker.get(first.id)
    asyncio.run(scenario())


def test_timeout_isolated_workers_continue_and_simulator_stops() -> None:
    class SlowWorkers(SolWorkers):
        async def analyze_telemetry(self, data: TelemetryInput) -> TelemetryResult:
            await asyncio.sleep(1)
            return await super().analyze_telemetry(data)

    async def scenario() -> None:
        config = Settings(api_key="a" * 32, admin_key="b" * 32, approval_secret=b"c" * 32,
                          job_timeout=0.01, worker_count=2)
        router = AstraOrchestrator(config, SlowWorkers(), ApprovalStore(config.approval_secret))
        await router.start()
        jobs = [await router.tracker.submit(JobKind.TELEMETRY, payload()) for _ in range(4)]
        await asyncio.wait_for(router.tracker.queue.join(), 1)
        for job in jobs:
            assert (await router.tracker.get(job.id)).error == "timeout"
        assert router.health()["ready"]
        router.workers = SolWorkers()
        recovered = await router.tracker.submit(JobKind.TELEMETRY, payload())
        await router.tracker.queue.join()
        assert (await router.tracker.get(recovered.id)).state == JobState.SUCCEEDED
        await router.stop()
        assert not router.health()["ready"]
        sim = AstraOrchestrator(replace(config, simulation_interval=0.005), SolWorkers(),
                                ApprovalStore(config.approval_secret))
        await sim.start()
        await asyncio.sleep(0.04)
        await sim.stop()
        assert len(sim.tracker.jobs) >= 5
        assert await sim.approvals.list_requests()
        assert sim._simulator is not None and sim._simulator.done()
    asyncio.run(scenario())


def test_proposal_saturation_does_not_block_telemetry_or_other_retention() -> None:
    class BlockedProposalWorkers(SolWorkers):
        def __init__(self) -> None:
            super().__init__()
            self.started = asyncio.Event()
            self.release = asyncio.Event()

        async def generate_proposal(self, data):  # type: ignore[no-untyped-def]
            self.started.set()
            await self.release.wait()
            return await super().generate_proposal(data)

    async def scenario() -> None:
        workers = BlockedProposalWorkers()
        config = Settings(
            api_key="a" * 32, admin_key="b" * 32, approval_secret=b"c" * 32,
            telemetry_worker_count=1, proposal_worker_count=1, remediation_worker_count=1,
            proposal_queue_capacity=2, proposal_max_records=2,
        )
        router = AstraOrchestrator(config, workers, ApprovalStore(config.approval_secret))
        await router.start()
        proposal = ProposalInput(
            customer="customer", hardware=[], labor=[], sla_monthly_cost="1",
            sla_months=1, sla_response_hours=1,
        )
        first = await router.tracker.submit(JobKind.PROPOSAL, proposal)
        await asyncio.wait_for(workers.started.wait(), 1)
        second = await router.tracker.submit(JobKind.PROPOSAL, proposal)
        with pytest.raises(CapacityError):
            await router.tracker.submit(JobKind.PROPOSAL, proposal)

        telemetry = await router.tracker.submit(JobKind.TELEMETRY, payload())
        await asyncio.wait_for(router.tracker.queue.join(), 1)
        assert (await router.tracker.get(telemetry.id)).state == JobState.SUCCEEDED
        assert (await router.tracker.get(first.id)).state == JobState.RUNNING
        assert (await router.tracker.get(second.id)).state == JobState.QUEUED
        assert router.health()["nodes"]["gpt-sol-telemetry"]["queue_depth"] == 0
        workers.release.set()
        await asyncio.wait_for(router.tracker.queue_for(JobKind.PROPOSAL).join(), 1)
        await router.stop()
    asyncio.run(scenario())


def test_recovery_keeps_approval_workflow_after_source_job_eviction() -> None:
    async def scenario() -> None:
        config = Settings(
            api_key="a" * 32, admin_key="b" * 32, approval_secret=b"c" * 32,
            telemetry_max_records=1,
        )
        approvals = ApprovalStore(config.approval_secret)
        router = AstraOrchestrator(config, SolWorkers(), approvals)
        await router.start()
        source = await router.tracker.submit(JobKind.TELEMETRY, TelemetryInput(samples=[HealthSample(
            service="evictable", cpu_percent=1, memory_percent=1, error_count=10, available=False,
        )]))
        await router.tracker.queue_for(JobKind.TELEMETRY).join()
        approval_id = (await router.tracker.get(source.id)).result["approval_request_ids"][0]  # type: ignore[index]
        approval = await approvals.get(approval_id)
        approved = await approvals.approve(approval_id, "admin")
        await router.tracker.submit(JobKind.TELEMETRY, payload())
        await router.tracker.queue_for(JobKind.TELEMETRY).join()
        with pytest.raises(KeyError):
            await router.tracker.get(source.id)

        recovery = await router.tracker.submit(
            JobKind.REMEDIATION,
            RecoveryCommand(approval_id, approved["token"], approval["workflow_id"], approval["correlation_id"]),
        )
        await router.tracker.queue_for(JobKind.REMEDIATION).join()
        completed = await router.tracker.get(recovery.id)
        assert completed.workflow_id == approval["workflow_id"]
        assert completed.correlation_id == approval["correlation_id"]
        assert completed.result["production_mutated"] is False  # type: ignore[index]
        await router.stop()
    asyncio.run(scenario())


def test_kind_payload_mismatch_is_rejected_and_stop_drains_lanes() -> None:
    async def scenario() -> None:
        tracker = MemoryTracker(1, 1)
        with pytest.raises(ValueError, match="does not match"):
            await tracker.submit(JobKind.PROPOSAL, payload())

        class NeverProposal(SolWorkers):
            async def generate_proposal(self, data):  # type: ignore[no-untyped-def]
                await asyncio.Future()

        config = Settings(
            api_key="a" * 32, admin_key="b" * 32, approval_secret=b"c" * 32,
            job_timeout=0.01, proposal_queue_capacity=2,
        )
        router = AstraOrchestrator(config, NeverProposal(), ApprovalStore(config.approval_secret))
        await router.start()
        proposal = ProposalInput(
            customer="customer", hardware=[], labor=[], sla_monthly_cost="1",
            sla_months=1, sla_response_hours=1,
        )
        running = await router.tracker.submit(JobKind.PROPOSAL, proposal)
        queued = await router.tracker.submit(JobKind.PROPOSAL, proposal)
        await asyncio.sleep(0.01)
        await router.stop()
        assert (await router.tracker.get(running.id)).state == JobState.FAILED
        assert (await router.tracker.get(queued.id)).state == JobState.FAILED
        assert (await router.tracker.get(queued.id)).error in {"shutdown_cancelled", "timeout"}
    asyncio.run(scenario())
