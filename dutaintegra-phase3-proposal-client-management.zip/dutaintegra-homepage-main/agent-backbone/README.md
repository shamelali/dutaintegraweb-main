# Duta Integra asynchronous agent backbone

Python 3.12+ / FastAPI / AsyncIO. A runnable, mock-only backend with a bounded
worker pool, authenticated control plane, signed human approvals, and typed
execution adapter contract. It is separate from the homepage.

**Deployment status:** suitable for local/staging evaluation of the isolated
workflow, not yet a durable, highly available production service. No actual
GPT inference, real server monitoring, or production recovery is enabled.
The supplied model names are configuration labels, not verified provider IDs.

## 1. Multi-model execution flow

```mermaid
flowchart TD
  API[Authenticated FastAPI: 202 + job ID] --> Q[Bounded state tracker]
  SIM[Optional periodic simulated telemetry] --> TQ[Telemetry lane]
  Q --> TQ
  Q --> PQ[Proposal lane]
  Q --> RQ[Recovery lane]
  TQ --> ASTRA[Astra role: typed routing and safety policy]
  PQ --> ASTRA
  RQ --> ASTRA
  ASTRA --> SOL[Explicit node registry]
  SOL --> T[GPT-Sol telemetry adapter]
  SOL --> P[GPT-8.1 Sol proposal adapter]
  T --> REVIEW[Astra role: output schema and service identity review]
  REVIEW --> CRIT{Critical signal?}
  CRIT -->|yes| PENDING[Pending mock-recovery request]
  ADMIN[Human with separate admin credential] --> SIGN[Approve: server signs bound claims]
  PENDING --> SIGN
  SIGN --> EXEC[Admin submits token to queued execution]
  EXEC --> VERIFY[Atomic state + expiry + HMAC verification]
  VERIFY --> MOCK[Fixed mock restart only]
  P --> RESULT[JSON + Markdown draft]
```

The **Astra role** owns routing, output validation, and policy. The **Sol role**
owns bounded execution. In this release both are deterministic local code;
calling a class Astra does not imply an Astra model inference took place.
`execution_mode: mock` and readiness metadata make that boundary explicit.

`ExecutionWorkers` is the async Sol adapter seam. A future provider adapter must
use verified provider model IDs, asynchronous I/O, validated structured output,
timeouts and concurrency/rate limits. A future Astra cognitive router may propose
routes and review content but must never be able to bypass deterministic approval
policy. The present policy forces unavailable services or 10+ errors through
approval even if an execution adapter reports a lower severity.

### Three independent work types

- **Telemetry:** externally submitted samples or periodic synthetic samples;
  critical when unavailable or error count >= 10; warning for any errors or
  CPU/memory >= 85%. Critical findings create deduplicated pending requests.
  Telemetry, proposal, and recovery jobs use independent bounded lanes and
  reserved consumers, so proposal pressure cannot block health processing.
- **Remediation:** `pending → approved → executing → succeeded/failed`.
  Pending/approved requests can expire or be rejected. HMAC-SHA256 binds request
  ID, source job, service, fixed action, administrator, expiry and nonce.
  Atomic consumption prevents concurrent/replayed execution. Mock execution is
  an async delay and a structured receipt, not a shell script.
- **Proposals:** user-supplied hardware, labor and SLA costs produce exact
  Decimal totals, currency, itemization, assumptions, exclusions and acceptance
  criteria in JSON and escaped Markdown. Prices are unverified inputs; outputs
  remain drafts, not quotations or commercial commitments.

## 2. Code layout

```text
agent-backbone/
  main.py                    FastAPI routes, auth, lifespan
  settings.py                Fail-closed configuration
  schemas.py                 Pydantic input/output messages
  agents/orchestrator.py     Astra policy, queue/tracker, worker lifecycle
  execution/sol_workers.py   Sol protocol and offline implementations
  pipelines/approval.py     Signed approval state machine and fixed mock action
  tests/                     Integration and safety-boundary tests
  pyproject.toml             Package and test dependencies
  requirements.lock         Exact tested dependency versions
```

## 3. Run locally

From `agent-backbone/`:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps -e .

# Generate three independent secrets in this terminal; never commit or print them.
export DUTA_API_KEY="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export DUTA_ADMIN_KEY="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export DUTA_APPROVAL_SECRET="$(.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))')"

# Optional: ingest a synthetic sample every two seconds; every fifth is critical.
export DUTA_SIMULATION_INTERVAL=2
.venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 1
```

Swagger documentation: `http://127.0.0.1:8000/docs`. Secrets must remain available
in the shell used for the example API calls below. Do not use multiple Uvicorn
workers or replicas with the memory tracker. Simulation defaults to disabled.
`DUTA_ASTRA_MODEL` and `DUTA_SOL_MODEL` change labels only, never execution mode.

## 4. Exercise the workflow

```bash
curl -s http://127.0.0.1:8000/v1/telemetry \
  -H "Authorization: Bearer $DUTA_API_KEY" -H 'Content-Type: application/json' \
  -d '{"samples":[{"service":"mock-web","cpu_percent":92,"memory_percent":65,"error_count":12,"available":false}]}'

# Substitute the returned job ID. Poll until succeeded or failed.
curl -s http://127.0.0.1:8000/v1/jobs/JOB_ID \
  -H "Authorization: Bearer $DUTA_API_KEY"

# Human reviews the approval before signing. Substitute approval_request_ids[0].
curl -s http://127.0.0.1:8000/v1/approvals/REQUEST_ID \
  -H "Authorization: Bearer $DUTA_API_KEY"
curl -s -X POST http://127.0.0.1:8000/v1/approvals/REQUEST_ID/approve \
  -H "Authorization: Bearer $DUTA_API_KEY" -H "X-Admin-Key: $DUTA_ADMIN_KEY"

# Submit the returned token in a JSON body, never in a URL. Mock execution is queued.
curl -s http://127.0.0.1:8000/v1/approvals/REQUEST_ID/execute \
  -H "Authorization: Bearer $DUTA_API_KEY" -H "X-Admin-Key: $DUTA_ADMIN_KEY" \
  -H 'Content-Type: application/json' -d '{"token":"RETURNED_64_HEX_TOKEN"}'
```

`POST /v1/approvals/{id}/reject` also requires both credentials and revokes an
unconsumed approval. Execute returning 202 means admission only, **not** a valid
signature or successful recovery. Poll its job; invalid, replayed, expired or
revoked tokens fail inside the worker without executing recovery.

```bash
curl -s http://127.0.0.1:8000/v1/proposals \
  -H "Authorization: Bearer $DUTA_API_KEY" -H 'Content-Type: application/json' \
  -d '{"customer":"Example Sdn Bhd","currency":"MYR","hardware":[{"description":"Server","quantity":2,"unit_cost":"8500.00"}],"labor":[{"description":"Installation hours","quantity":16,"unit_cost":"180.00"}],"sla_monthly_cost":"900.00","sla_months":12,"sla_response_hours":4}'
```

Poll the returned job ID for `result.blueprint` and `result.markdown`. Monetary
values are decimal strings. Schema violations return 422, missing credentials
401/403, missing/evicted records 404, invalid synchronous transitions 409,
and saturated job admission 503 with `Retry-After`.

## 5. Concurrency, retention, and operational boundaries

- Four async consumers per lane by default; each lane has an independent bounded
  queue of 128 and up to 1,000 retained jobs/records. Programmatic `Settings` or
  `DUTA_TELEMETRY_*`, `DUTA_PROPOSAL_*`, and `DUTA_REMEDIATION_*` environment
  variables can adjust capacities, worker counts, retention, and node labels.
- Admission never waits for queue space. Completed job history is evicted first;
  active records are not evicted. Terminal approvals are evicted when necessary.
  This is bounded operational history, **not** a durable audit log.
- Each execution has a 30-second timeout. Failure is isolated to its job and the
  worker continues. There are no automatic retries of recovery actions.
- Shutdown stops ingress/simulation, attempts bounded draining, then cancels
  running jobs and marks queued jobs failed. Abrupt process death loses all state.
- `GET /health/live` is public. Authenticated `GET /health/ready` reports per-node
  worker health, lane queue depth/capacity, simulation drops, mock mode and
  volatile storage. Jobs expose `workflow_id`, `correlation_id`, and `node_id`.
- HMAC approvals are server-authenticated capabilities following admin clearance,
  **not** end-user public-key signatures or proof of individual human identity.
  The current admin principal is the single server-bound `configured-admin`.
- Models cannot mint approvals. No raw command, hostname endpoint, executable
  path, shell, remote execution SDK, or production adapter is exposed.
- In-memory state prevents approval replay during one process lifetime. Restart
  destroys pending requests too, so old tokens cannot authorize new requests.
- The simulator is part of this explicitly requested backend process, not an
  OS-level scheduler or an OmniRush Automation.

## 6. Before a real production rollout

1. Implement a durable queue plus job state, e.g. Redis Streams and a durable
   database. `MessageTracker` documents the contract, but this release does not
   provide a Redis adapter. Add atomic admission, leases, ack/reclaim, dead-letter
   handling and recovery after crashes. Refactor lifecycle operations through
   the adapter rather than relying on `MemoryTracker.queue`.
2. Move approvals to transactional shared storage. Signature verification,
   expiry and one-use consumption must be atomic across replicas. Preserve a
   durable audit trail and rotation/versioning for signing keys. Never retry a
   real mutation solely because its completion receipt was lost.
3. Replace the single admin key with verified OIDC identities/RBAC, MFA where
   appropriate, tenant isolation, independent approvers and revocation policies.
   Keep the signing key separate in a managed secret store/KMS.
4. Put TLS, request-body size limits, rate limiting, connection limits, and a
   request timeout at the gateway. Do not expose this development server
   directly to the internet. Redact auth headers, approval tokens, and private
   proposal content from gateway/APM logs; disable unnecessary public docs.
5. Package and scan the pinned dependencies, run as non-root, and enforce a
   read-only filesystem plus network egress denial for mock workers. Code-level
   absence of mutations is not an operating-system sandbox.
6. Add verified async provider adapters only after selecting available provider
   model IDs and authorizing outbound data sharing. Separate inference from
   deterministic money calculations and the signed execution gate.
7. Real remediation is deliberately not implemented. Any future adapter requires
   an allowlisted runbook, a signed target/action scope, isolated credentials,
   cooldowns, incident deduplication, idempotency, blast-radius controls, and
   explicit authorization. Do not turn model output into executable code.
8. Add load/chaos tests, durable audit exports, metrics/alerts, backup/restore and
   an external security review before claiming production readiness.

## 7. Verification

```bash
.venv/bin/python -m pytest -q
.venv/bin/ruff check .
.venv/bin/python -m compileall -q main.py settings.py schemas.py agents execution pipelines tests
.venv/bin/python -m pip check
```

Tests cover the authenticated API flow, admin-only signing and execution,
signature tampering/cross-request substitution, expiry, replay, concurrent
consumption, cancellation, queue saturation/retention, execution timeouts,
worker continuation, continuous simulation, exact proposal totals and input
validation. They do not prove multi-process durability, live model quality,
production load capacity or real infrastructure recovery.

Verified on Python 3.12.3: **12 tests passed**, Ruff passed, compileall passed,
and pip check reported no broken requirements. The installed Starlette test
client emits one deprecation warning for its current HTTPX integration; this is
not a runtime test failure. No static type checker, load test, live provider
inference or production deployment was run.
