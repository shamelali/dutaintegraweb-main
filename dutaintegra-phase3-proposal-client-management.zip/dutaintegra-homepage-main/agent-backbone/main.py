"""FastAPI control plane. Start with uvicorn main:app --workers 1."""
import hmac
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from agents.orchestrator import AstraOrchestrator, CapacityError, RecoveryCommand
from execution.sol_workers import SolWorkers
from pipelines.approval import ApprovalStore
from schemas import ExecuteApproval, Job, JobKind, ProposalInput, TelemetryInput
from settings import Settings


def create_app(config: Settings | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        settings = config or Settings.from_env()
        approvals = ApprovalStore(settings.approval_secret, settings.approval_ttl, settings.max_records)
        router = AstraOrchestrator(
            settings,
            SolWorkers(
                settings.sol_model_label,
                telemetry_model_label=settings.telemetry_model_label,
                proposal_model_label=settings.proposal_model_label,
            ),
            approvals,
        )
        app.state.settings, app.state.router, app.state.approvals = settings, router, approvals
        await router.start()
        try:
            yield
        finally:
            await router.stop()

    app = FastAPI(title="Duta Integra Agent Backbone", version="0.1.0", lifespan=lifespan)

    async def authenticated(request: Request, authorization: Annotated[str | None, Header()] = None) -> None:
        expected = f"Bearer {request.app.state.settings.api_key}"
        if authorization is None or not hmac.compare_digest(authorization.encode(), expected.encode()):
            raise HTTPException(401, "Valid API bearer credential required", headers={"WWW-Authenticate": "Bearer"})

    async def administrator(request: Request, x_admin_key: Annotated[str | None, Header()] = None) -> str:
        expected = request.app.state.settings.admin_key
        if x_admin_key is None or not hmac.compare_digest(x_admin_key.encode(), expected.encode()):
            raise HTTPException(403, "Administrator clearance required")
        # Identity is server-bound, never taken from a client actor field.
        return "configured-admin"

    secured = [Depends(authenticated)]

    @app.exception_handler(CapacityError)
    async def capacity_error(request: Request, exc: CapacityError) -> JSONResponse:
        return JSONResponse(status_code=503, content={"detail": "Queue capacity unavailable"}, headers={"Retry-After": "1"})

    @app.exception_handler(KeyError)
    async def missing(request: Request, exc: KeyError) -> JSONResponse:
        return JSONResponse(status_code=404, content={"detail": "Record not found or evicted"})

    @app.exception_handler(ValueError)
    async def conflict(request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(status_code=409, content={"detail": "Invalid or expired state transition"})

    @app.middleware("http")
    async def private_responses(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.get("/health/live")
    async def live() -> dict[str, str]:
        return {"status": "alive"}

    @app.get("/health/ready", dependencies=secured)
    async def ready(request: Request) -> JSONResponse:
        state = request.app.state.router.health()
        return JSONResponse(state, status_code=200 if state["ready"] else 503)

    @app.post("/v1/telemetry", status_code=202, response_model=Job, dependencies=secured)
    async def telemetry(payload: TelemetryInput, request: Request) -> Job:
        return await request.app.state.router.tracker.submit(JobKind.TELEMETRY, payload)

    @app.post("/v1/proposals", status_code=202, response_model=Job, dependencies=secured)
    async def proposal(payload: ProposalInput, request: Request) -> Job:
        return await request.app.state.router.tracker.submit(JobKind.PROPOSAL, payload)

    @app.get("/v1/jobs/{job_id}", response_model=Job, dependencies=secured)
    async def job(job_id: str, request: Request) -> Job:
        return await request.app.state.router.tracker.get(job_id)

    @app.get("/v1/approvals", dependencies=secured)
    async def approvals(request: Request) -> list[dict[str, Any]]:
        return await request.app.state.approvals.list_requests()

    @app.get("/v1/approvals/{request_id}", dependencies=secured)
    async def approval(request_id: str, request: Request) -> dict[str, Any]:
        return await request.app.state.approvals.get(request_id)

    @app.post("/v1/approvals/{request_id}/approve", dependencies=secured)
    async def approve(request_id: str, request: Request, actor: Annotated[str, Depends(administrator)]) -> dict[str, Any]:
        return await request.app.state.approvals.approve(request_id, actor)

    @app.post("/v1/approvals/{request_id}/reject", dependencies=secured)
    async def reject(request_id: str, request: Request, actor: Annotated[str, Depends(administrator)]) -> dict[str, Any]:
        return await request.app.state.approvals.reject(request_id, actor)

    @app.post("/v1/approvals/{request_id}/execute", status_code=202, response_model=Job, dependencies=secured)
    async def execute(request_id: str, payload: ExecuteApproval, request: Request,
                      actor: Annotated[str, Depends(administrator)]) -> Job:
        record = await request.app.state.approvals.get(request_id)
        return await request.app.state.router.tracker.submit(
            JobKind.REMEDIATION,
            RecoveryCommand(request_id, payload.token, record["workflow_id"], record["correlation_id"]),
        )

    return app


app = create_app()
