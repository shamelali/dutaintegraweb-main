"""Human clearance and one-use HMAC approval, inseparable from mock execution."""
import asyncio
import hashlib
import hmac
import json
import time
from copy import deepcopy
from typing import Any
from uuid import uuid4


class ApprovalStore:
    def __init__(self, secret: bytes, ttl_seconds: int = 300, max_records: int = 1000) -> None:
        if len(secret) < 32:
            raise ValueError("Signing secret must have at least 32 bytes")
        self._secret = secret
        self._ttl = ttl_seconds
        self._max = max_records
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    def _transition(self, record: dict[str, Any], state: str, actor: str) -> None:
        record["state"] = state
        record["audit"].append({"state": state, "actor": actor, "at": time.time()})

    def _expire(self, record: dict[str, Any]) -> None:
        if record["state"] in {"pending", "approved"} and time.time() >= record["expires_at"]:
            self._transition(record, "expired", "system")

    def _signature(self, record: dict[str, Any]) -> str:
        claims = {key: record[key] for key in (
            "id", "service", "source_job_id", "workflow_id", "correlation_id",
            "action", "expires_at", "approved_by", "nonce"
        )}
        body = json.dumps(claims, sort_keys=True, separators=(",", ":")).encode()
        return hmac.new(self._secret, body, hashlib.sha256).hexdigest()

    async def create(self, service: str, source_job_id: str, workflow_id: str | None = None,
                     correlation_id: str | None = None) -> dict[str, Any]:
        async with self._lock:
            for record in self._records.values():
                self._expire(record)
                if record["service"] == service and record["state"] in {"pending", "approved", "executing"}:
                    return deepcopy(record)
            if len(self._records) >= self._max:
                removable = next((key for key, value in self._records.items()
                                  if value["state"] in {"succeeded", "failed", "rejected", "expired"}), None)
                if removable is None:
                    raise ValueError("Approval capacity reached")
                del self._records[removable]
            workflow = workflow_id or str(uuid4())
            record = {"id": str(uuid4()), "service": service, "source_job_id": source_job_id,
                      "workflow_id": workflow, "correlation_id": correlation_id or workflow,
                      "action": "mock_restart", "expires_at": time.time() + self._ttl,
                      "approved_by": None, "nonce": str(uuid4()), "audit": []}
            self._transition(record, "pending", "astra-policy")
            self._records[record["id"]] = record
            return deepcopy(record)

    async def get(self, request_id: str) -> dict[str, Any]:
        async with self._lock:
            record = self._records[request_id]
            self._expire(record)
            return deepcopy(record)

    async def list_requests(self) -> list[dict[str, Any]]:
        async with self._lock:
            for record in self._records.values():
                self._expire(record)
            return deepcopy(list(self._records.values()))

    async def approve(self, request_id: str, actor: str) -> dict[str, Any]:
        async with self._lock:
            record = self._records[request_id]
            self._expire(record)
            if record["state"] != "pending":
                raise ValueError("Only pending requests can be approved")
            record["approved_by"] = actor
            self._transition(record, "approved", actor)
            return {**deepcopy(record), "token": self._signature(record)}

    async def reject(self, request_id: str, actor: str) -> dict[str, Any]:
        async with self._lock:
            record = self._records[request_id]
            self._expire(record)
            if record["state"] not in {"pending", "approved"}:
                raise ValueError("Request cannot be rejected in its current state")
            self._transition(record, "rejected", actor)
            return deepcopy(record)

    async def execute(self, request_id: str, token: str, *, workflow_id: str | None = None,
                      correlation_id: str | None = None) -> dict[str, Any]:
        async with self._lock:
            record = self._records[request_id]
            self._expire(record)
            if record["state"] != "approved":
                raise ValueError("Unapproved, expired, or already consumed request")
            if not hmac.compare_digest(self._signature(record), token):
                raise ValueError("Invalid signed approval")
            if workflow_id is not None and not hmac.compare_digest(record["workflow_id"], workflow_id):
                raise ValueError("Approval workflow binding mismatch")
            if correlation_id is not None and not hmac.compare_digest(record["correlation_id"], correlation_id):
                raise ValueError("Approval correlation binding mismatch")
            self._transition(record, "executing", "mock-worker")
        try:
            # The only recovery operation. No arbitrary commands or real service adapters.
            await asyncio.sleep(0.01)
        except BaseException:
            async with self._lock:
                self._transition(record, "failed", "mock-worker")
            raise
        async with self._lock:
            self._transition(record, "succeeded", "mock-worker")
            return {"request_id": request_id, "service": record["service"],
                    "workflow_id": record["workflow_id"], "correlation_id": record["correlation_id"],
                    "action": "mock_restart", "execution_mode": "mock",
                    "production_mutated": False, "state": record["state"]}
