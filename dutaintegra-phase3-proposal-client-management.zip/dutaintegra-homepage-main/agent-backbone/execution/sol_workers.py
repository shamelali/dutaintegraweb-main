"""Offline Sol adapter. No SDK, subprocess, filesystem, or network capability."""
import asyncio
import html
from decimal import Decimal
from typing import Protocol, runtime_checkable

from schemas import (
    Finding,
    ProposalInput,
    ProposalResult,
    TelemetryInput,
    TelemetryResult,
)


@runtime_checkable
class ExecutionWorkers(Protocol):
    async def analyze_telemetry(self, payload: TelemetryInput) -> TelemetryResult: ...
    async def generate_proposal(self, payload: ProposalInput) -> ProposalResult: ...


class GPTSolTelemetryAdapter:
    """Typed offline telemetry node; it never contacts a provider."""

    def __init__(self, workers: ExecutionWorkers) -> None:
        self._workers = workers

    async def run(self, payload: TelemetryInput) -> TelemetryResult:
        return await self._workers.analyze_telemetry(payload)


class GPT81SolProposalAdapter:
    """Typed offline proposal node; it never contacts a provider."""

    def __init__(self, workers: ExecutionWorkers) -> None:
        self._workers = workers

    async def run(self, payload: ProposalInput) -> ProposalResult:
        return await self._workers.generate_proposal(payload)


def markdown_text(value: str) -> str:
    text = html.escape(value).replace("\n", " ").replace("\r", " ")
    for char in "\\`*_{}[]()#+-.!|>":
        text = text.replace(char, "\\" + char)
    return text


class SolWorkers:
    def __init__(self, model_label: str = "GPT-8.1 Sol / GPT-Sol", *,
                 telemetry_model_label: str | None = None,
                 proposal_model_label: str | None = None) -> None:
        self.model_label = model_label
        self.telemetry_model_label = telemetry_model_label or model_label
        self.proposal_model_label = proposal_model_label or model_label

    async def analyze_telemetry(self, payload: TelemetryInput) -> TelemetryResult:
        findings: list[Finding] = []
        for sample in payload.samples:
            await asyncio.sleep(0)
            reasons: list[str] = []
            critical = not sample.available or sample.error_count >= 10
            if not sample.available:
                reasons.append("Service unavailable")
            if sample.error_count:
                reasons.append(f"Observed {sample.error_count} errors")
            if sample.cpu_percent >= 85:
                reasons.append("CPU utilization at least 85%")
            if sample.memory_percent >= 85:
                reasons.append("Memory utilization at least 85%")
            findings.append(Finding(
                service=sample.service,
                severity="critical" if critical else "warning" if reasons else "healthy",
                reasons=reasons or ["All monitored metrics within thresholds"],
            ))
        return TelemetryResult(findings=findings, model_label=self.telemetry_model_label)

    async def generate_proposal(self, payload: ProposalInput) -> ProposalResult:
        await asyncio.sleep(0)
        groups: dict[str, list[dict[str, str | int]]] = {}
        totals: dict[str, Decimal] = {}
        for name, items in (("hardware", payload.hardware), ("labor", payload.labor)):
            groups[name] = []
            totals[name] = Decimal("0")
            for item in items:
                amount = Decimal(item.unit_cost) * item.quantity
                totals[name] += amount
                groups[name].append({
                    "description": item.description, "quantity": item.quantity,
                    "unit_cost": f"{Decimal(item.unit_cost):.2f}", "total": f"{amount:.2f}",
                })
        sla = Decimal(payload.sla_monthly_cost) * payload.sla_months
        grand = totals["hardware"] + totals["labor"] + sla
        assumptions = ["All prices supplied by requester; not independently verified.",
                       "Draft only; scope, stock, taxes and commercial terms require review."]
        exclusions = ["Taxes, shipping and third-party licensing unless explicitly itemized.",
                      "No uptime guarantee or legally binding commitment is created."]
        acceptance = ["Confirm bill of materials and labor scope with the customer.",
                      "Validate installation and handover against an approved test plan."]
        blueprint = {
            "schema_version": "1.0", "status": "draft", "customer": payload.customer,
            "currency": payload.currency, **groups,
            "sla": {"monthly_cost": f"{Decimal(payload.sla_monthly_cost):.2f}",
                    "months": payload.sla_months, "response_hours": payload.sla_response_hours,
                    "coverage": "To be agreed", "total": f"{sla:.2f}"},
            "totals": {"hardware": f"{totals['hardware']:.2f}",
                       "labor": f"{totals['labor']:.2f}", "sla": f"{sla:.2f}",
                       "grand_total_before_tax": f"{grand:.2f}"},
            "assumptions": assumptions, "exclusions": exclusions,
            "acceptance_criteria": acceptance,
        }
        lines = [f"# IT Proposal — {markdown_text(payload.customer)}", "", "**DRAFT — review required**", ""]
        for name, entries in groups.items():
            lines += [f"## {name.title()}", "", "| Item | Quantity | Unit price | Total |",
                      "|---|---:|---:|---:|"]
            for entry in entries:
                lines.append(f"| {markdown_text(str(entry['description']))} | {entry['quantity']} | {entry['unit_cost']} | {entry['total']} |")
            lines.append("")
        lines += ["## SLA", f"{payload.sla_months} months; proposed response target: {payload.sla_response_hours} hours.",
                  f"Monthly cost: {payload.currency} {Decimal(payload.sla_monthly_cost):.2f}; total: {sla:.2f}.",
                  "Coverage hours and service credits: to be agreed.", "",
                  f"**Total before tax: {payload.currency} {grand:.2f}**"]
        for title, entries in (("Assumptions", assumptions), ("Exclusions", exclusions), ("Acceptance criteria", acceptance)):
            lines += ["", f"## {title}", *[f"- {entry}" for entry in entries]]
        return ProposalResult(blueprint=blueprint, markdown="\n".join(lines),
                              model_label=self.proposal_model_label)
