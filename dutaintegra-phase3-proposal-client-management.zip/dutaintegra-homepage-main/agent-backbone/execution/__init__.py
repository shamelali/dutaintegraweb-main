"""Isolated execution adapters."""
