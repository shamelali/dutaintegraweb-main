(function () {
  'use strict';

  var form = document.getElementById('healthForm');
  if (!form) return;
  var status = document.getElementById('healthStatus');
  var result = document.getElementById('healthResult');
  var submit = form.querySelector('.health-submit');

  var copy = {
    en: {
      working: 'Reviewing public signals and building your starting point…',
      done: 'Health check complete. This is an evidence-based starting point, not a compliance certification.',
      error: 'We could not complete the scan right now. Please check the website URL or try again.',
      invalid: 'Please enter a company name and a valid public website URL.',
      title: 'AI health check result',
      mode: 'Mode',
      recommended: 'Recommended starting point',
      evidence: 'Public signals reviewed',
      sources: 'Sources reviewed',
      followup: 'What to confirm with your team',
      noEvidence: 'No public evidence was available for this item.'
    },
    bm: {
      working: 'Sedang menyemak isyarat awam dan menyediakan titik mula anda…',
      done: 'Semakan kesihatan selesai. Ini ialah titik mula berasaskan bukti, bukan pensijilan pematuhan.',
      error: 'Semakan tidak dapat diselesaikan sekarang. Sila semak URL laman web atau cuba lagi.',
      invalid: 'Sila masukkan nama syarikat dan URL laman web awam yang sah.',
      title: 'Keputusan semakan kesihatan AI',
      mode: 'Mod',
      recommended: 'Titik mula yang disyorkan',
      evidence: 'Isyarat awam yang disemak',
      sources: 'Sumber yang disemak',
      followup: 'Perkara yang perlu disahkan bersama pasukan anda',
      noEvidence: 'Tiada bukti awam ditemui untuk perkara ini.'
    }
  };

  function language() {
    return document.documentElement.lang === 'ms' ? 'bm' : 'en';
  }

  function setStatus(message, state) {
    status.textContent = message;
    status.dataset.state = state || '';
  }

  function validWebsite(value) {
    try {
      var url = new URL(value);
      return (url.protocol === 'http:' || url.protocol === 'https:') && Boolean(url.hostname);
    } catch (error) {
      return false;
    }
  }

  function render(data, lang) {
    var strings = copy[lang];
    var lines = [strings.title, ''];
    lines.push(strings.recommended + ': ' + (data.recommended_service || strings.noEvidence));
    lines.push(strings.mode + ': ' + (data.mode || 'public evidence')); 
    lines.push('');
    if (data.summary) lines.push(data.summary, '');
    if (Array.isArray(data.findings) && data.findings.length) {
      lines.push(strings.evidence + ':');
      data.findings.forEach(function (finding, index) {
        var label = finding.title || finding.area || ('Finding ' + (index + 1));
        var detail = finding.detail || finding.status || strings.noEvidence;
        lines.push((index + 1) + '. ' + label + ' — ' + detail);
      });
      lines.push('');
    }
    if (Array.isArray(data.confirm_with_team) && data.confirm_with_team.length) {
      lines.push(strings.followup + ':');
      data.confirm_with_team.forEach(function (item) { lines.push('• ' + item); });
      lines.push('');
    }
    if (Array.isArray(data.sources) && data.sources.length) {
      lines.push(strings.sources + ':');
      data.sources.forEach(function (source) { lines.push('• ' + source); });
    }
    result.textContent = lines.join('\n').trim();
    result.setAttribute('aria-label', strings.title);
    result.hidden = false;
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var lang = language();
    var strings = copy[lang];
    var formData = new FormData(form);
    var company = String(formData.get('company') || '').trim();
    var website = String(formData.get('website') || '').trim();
    if (!company || !validWebsite(website)) {
      setStatus(strings.invalid, 'error');
      result.hidden = true;
      return;
    }

    submit.disabled = true;
    result.hidden = true;
    setStatus(strings.working, 'working');
    var signals = Array.prototype.map.call(form.querySelectorAll('input[name="signals"]:checked'), function (input) {
      return input.value;
    });

    fetch('/api/business-health-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        company: company,
        registrationNumber: String(formData.get('registrationNumber') || '').trim(),
        website: website,
        signals: signals,
        language: lang
      })
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) throw new Error(body.error || 'health_check_failed');
        return body;
      });
    }).then(function (body) {
      render(body, lang);
      setStatus(strings.done, 'success');
    }).catch(function () {
      setStatus(strings.error, 'error');
    }).then(function () {
      submit.disabled = false;
    });
  });
})();
