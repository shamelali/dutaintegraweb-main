/* ============================================================================
 * analytics.js — lead-event tracking for dutaintegra.my
 * ============================================================================
 * Why this exists: right now you cannot tell whether the homepage redesign,
 * the calculator or the outreach is working. Without that, every future
 * decision about the site is a guess.
 *
 * WHAT IT TRACKS (the events that map to money):
 *   wa_click        — every WhatsApp link click, with WHERE it was clicked
 *   form_submit     — enquiry form submitted successfully
 *   form_fallback   — form failed and handed off to WhatsApp (a near-miss lead)
 *   form_error      — validation failure (tells you if the form is confusing)
 *   calc_engage     — visitor moved a calculator slider (top-of-funnel intent)
 *   calc_handoff    — calculator → WhatsApp with their numbers (qualified lead)
 *   cta_click       — primary CTA clicks, by label
 *   email_click     — mailto clicks
 *   scroll_depth    — 25/50/75/100% (tells you where the page loses people)
 *
 * HOW TO SEND IT SOMEWHERE — pick ONE transport below.
 * It ships set to 'noop' so nothing is sent until you decide. That means you
 * are not shipping an analytics tool you didn't choose, and no data leaves the
 * visitor's browser until you switch it on.
 *
 *   'noop'        — collected in window.__di_events only. This is the default.
 *   'ga4'         — send to Google Analytics 4
 *   'plausible'   — Plausible
 *   'cloudflare'  — Cloudflare Web Analytics
 *   'endpoint'    — POST JSON to your own URL
 *
 * The last four do NOT work just because you filled in a CONFIG value. They
 * all call a global that has to exist on the page first:
 *   'ga4'        needs the Google tag snippet (<script> with gtag.js) in the page
 *   'plausible'  needs the Plausible snippet with your domain
 *   'cloudflare' needs the Cloudflare Web Analytics beacon
 *   'endpoint'   needs a route on your server — see the ENDPOINT note below
 * Pick the transport and add its snippet in the same commit, or you get silent
 * zero data: the branch runs, the global is undefined, the `if` no-ops, and
 * nothing in the console tells you.
 *
 * 'endpoint' has a second prerequisite that is easy to miss. In
 * deploy/nginx.conf.example every /api/ request is rate-limited by the SAME
 * zone as the enquiry form (`zone=enquiry rate=10r/m burst=5`). A pageview can
 * emit a dozen events, so turning 'endpoint' on without giving analytics its
 * own limit_req zone lets tracking spend the quota the lead form needs — the
 * visitor's enquiry then returns 429 and falls back to WhatsApp. Before you
 * switch this on: add POST /api/analytics to the server. The edge side is
 * already drafted — deploy/nginx.conf.example declares zone=analytics and an
 * exact-match location = /api/analytics that uses it — and DEPLOY.md §3 has
 * both steps.
 *
 * PRIVACY NOTE, because it's your brand promise: this deliberately does NOT
 * fingerprint devices, does NOT set cookies, does NOT write to localStorage or
 * sessionStorage, and does NOT capture field values from the form — only that
 * a submit happened. With 'noop' or 'endpoint' your privacy notice stays true
 * as written ("no tracking cookies, advertising pixels or third-party
 * analytics … stores nothing in your browser"). Switching to 'ga4',
 * 'plausible' or 'cloudflare' breaks that sentence: update privacy.html §11 in
 * both languages and consider a consent banner in the same commit.
 * ==========================================================================*/
(function () {
  'use strict';

  var CONFIG = {
    transport: 'noop',                 // 'noop' | 'ga4' | 'plausible' | 'cloudflare' | 'endpoint'
    GA4_ID: 'G-XXXXXXXXXX',            // not read here — your gtag snippet uses it
    PLAUSIBLE_DOMAIN: 'dutaintegra.my', // not read here — your Plausible snippet uses it
    CF_TOKEN: 'YOUR_CF_BEACON_TOKEN',  // not read here — your Cloudflare snippet uses it
    ENDPOINT: '/api/analytics',        // used only when transport is 'endpoint' — see the header
    debug: false                       // true = log every event to the console while testing
  };

  var queue = [];
  window.__di_events = queue;   // inspect in the console: __di_events

  function send(name, props) {
    var payload = Object.assign({
      event: name,
      page: location.pathname,
      ts: new Date().toISOString()
    }, props || {});

    queue.push(payload);
    if (CONFIG.debug) console.log('[track]', payload);

    try {
      switch (CONFIG.transport) {
        case 'ga4':
          if (window.gtag) window.gtag('event', name, props || {});
          break;
        case 'plausible':
          if (window.plausible) window.plausible(name, { props: props || {} });
          break;
        case 'cloudflare':
          if (window.__cfBeacon) window.__cfBeacon(name, props || {});
          break;
        case 'endpoint':
          // keepalive so the beacon survives the page unload caused by a
          // WhatsApp link opening in a new tab
          fetch(CONFIG.ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            keepalive: true
          }).catch(function () {});
          break;
        default:
          break; // 'noop'
      }
    } catch (e) { /* tracking must never break the page */ }
  }

  /* ---------------------------------------------------------------
   * Where on the page did the click happen? This is the whole point —
   * "12 WhatsApp clicks" is useless; "9 came from the hero, 3 from the
   * sticky mobile bar" tells you what to change.
   * ------------------------------------------------------------- */
  function locationLabel(el) {
    if (el.closest('.mbar')) return 'sticky_mobile_bar';
    if (el.closest('#calculator')) return 'hero_calculator';
    if (el.closest('.hdr') || el.closest('.mnav')) return 'header';
    if (el.closest('.announce')) return 'announcement_bar';
    if (el.closest('.band')) return 'cta_band';
    if (el.closest('#audit')) return 'contact_section';
    if (el.closest('footer')) return 'footer';
    if (el.closest('.hero')) return 'hero';
    if (el.closest('#pricing')) return 'pricing';
    if (el.closest('#services')) return 'services';
    return 'other';
  }

  /* ---- WhatsApp / phone / email clicks ---- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    var href = a.getAttribute('href') || '';
    var where = locationLabel(a);
    var label = (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 48);

    if (href.indexOf('wa.me') > -1) {
      // Prefilled message length tells you whether it was the calculator
      // handoff (long, contains their numbers) or a plain contact click.
      var msgLen = 0;
      try { msgLen = decodeURIComponent(href.split('text=')[1] || '').length; } catch (err) {}
      send('wa_click', {
        location: where,
        label: label,
        has_prefilled_message: msgLen > 0,
        prefilled_length: msgLen
      });
    } else if (href.indexOf('tel:') === 0) {
      send('phone_click', { location: where });
    } else if (href.indexOf('mailto:') === 0) {
      send('email_click', { location: where, address: href.replace('mailto:', '').split('?')[0] });
    } else if (href.charAt(0) === '#') {
      if (a.classList.contains('btn')) send('cta_click', { location: where, label: label, target: href });
    }
  }, true);

  /* ---- Calculator engagement ---- */
  (function () {
    var calc = document.getElementById('calculator');
    if (!calc) return;
    var touched = false;
    ['#rStaff', '#rHours', '#rSalary'].forEach(function (sel) {
      var el = calc.querySelector(sel);
      if (!el) return;
      el.addEventListener('input', function () {
        if (touched) return;   // fire once per session, not per pixel of drag
        touched = true;
        send('calc_engage', { first_field: sel });
      });
    });

    /* calc_handoff is a qualified lead: they asked for their numbers on
     * WhatsApp. It is hooked to the #waCalc click, NOT to the sliders'
     * 'change' event — 'change' fires on every mouse-up and arrow key, so
     * hooking it there reported slider fiddling as a lead. Once per session,
     * like calc_engage, so one visitor cannot inflate the count. */
    var handedOff = false;
    var waBtn = document.getElementById('waCalc');
    if (waBtn) waBtn.addEventListener('click', function () {
      if (handedOff) return;
      handedOff = true;
      send('calc_handoff', {
        staff: (document.getElementById('rStaff') || {}).value,
        hours_per_week: (document.getElementById('rHours') || {}).value,
        salary: (document.getElementById('rSalary') || {}).value
      });
    });
  })();

  /* ---- Form outcomes (hooked by the page's own submit handler) ---- */
  window.__di_trackForm = function (outcome, detail) {
    if (outcome === 'success') send('form_submit', detail || {});
    else if (outcome === 'fallback') send('form_fallback', detail || {});
    else send('form_error', detail || {});
  };

  /* ---- Scroll depth ---- */
  (function () {
    var marks = [25, 50, 75, 100], hit = {};
    function check() {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      if (h <= 0) return;
      var pct = Math.round((window.scrollY / h) * 100);
      marks.forEach(function (m) {
        if (pct >= m && !hit[m]) { hit[m] = 1; send('scroll_depth', { depth: m }); }
      });
    }
    var t;
    window.addEventListener('scroll', function () {
      clearTimeout(t); t = setTimeout(check, 250);
    }, { passive: true });
  })();

  /* ---- Source of the visit, so a new enquiry shows where it came from ----
   * Read from the current URL on demand instead of being written to
   * sessionStorage: privacy.html §11 states this script "stores nothing in
   * your browser", and that sentence is worth keeping literally true.
   * Trade-off: the source only survives while the visitor is still on the
   * landing URL. The enquiry form lives on the homepage, which is where
   * campaign links point, so that covers the normal path. */
  (function () {
    var params = new URLSearchParams(location.search);
    var src = params.get('utm_source') || params.get('ref');
    if (src) send('landed_with_source', { source: src, medium: params.get('utm_medium') || null });
  })();

  window.__di_attribution = function () {
    try {
      var params = new URLSearchParams(location.search);
      return params.get('utm_source') || params.get('ref') || 'direct';
    } catch (e) { return 'direct'; }
  };
})();
