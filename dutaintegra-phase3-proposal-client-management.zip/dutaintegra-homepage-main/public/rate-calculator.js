/* ============================================================
   rate-calculator.js — /connect/rate-calculator behaviour.

   All rate maths comes from /rates-engine.js (shared with the
   /connect widget). This file only renders.

   Progressive enhancement: the markup ships a no-JS table and a
   no-JS zone-ladder, so the page stays readable without JavaScript.
   No storage, no network calls (privacy notice §11).
   ============================================================ */
(function(){
  'use strict';
  var E = window.DIRates;
  if (!E) return;

  var $  = function(s){ return document.querySelector(s); };
  var $all = function(s){ return Array.prototype.slice.call(document.querySelectorAll(s)); };

  var table  = $('#rcTable');
  var outcome = $('#rcOutcome');
  var wEl = $('#rcWeight'), zEl = $('#rcZone'), oEl = $('#rcOrders');
  var ladder = $('#zones');
  if (!table || !wEl || !zEl || !oEl || !ladder) return;

  var STR = {
    en: { courier:'Courier', cost:'Cost', days:'Days', spread:'spread', cheapest:'is cheapest',
          via:'via', onEach:'on every parcel', at:'at', save:'you save',
          perMonth:'a month', across:'across', orders:'orders', gapIs:'that gap is',
          zoneNote:'In Zone C the cheapest courier is different, the cheapest price is roughly double, and the gap between couriers widens. That is the case rate shopping exists to catch.' },
    ms: { courier:'Kurier', cost:'Kos', days:'Hari', spread:'perbezaan', cheapest:'adalah yang termurah',
          via:'melalui', onEach:'setiap pakej', at:'pada', save:'jimat',
          perMonth:'sebulan', across:'pada', orders:'pesanan', gapIs:'jurang itu ialah',
          zoneNote:'Pada Zona C, kurier termurah berbeza, harga termurah lebih kurang dua kali ganda, dan jurang antara kurier melebar. Itulah sebabnya perbandingan kadar wujud.' }
  };
  function t(k){ return (E.isBM() ? STR.ms : STR.en)[k]; }

  function renderTable(shop){
    var html = '<div class="rs-row rs-head" aria-hidden="true">' +
      '<span>' + E.esc(t('courier')) + '</span>' +
      '<span>' + E.esc(t('cost')) + '</span>' +
      '<span>' + E.esc(t('days')) + '</span></div>';
    shop.rows.forEach(function(r){
      var cls = 'rs-row' + (r.isCheapest ? ' win' : '') + (r.isDearest && !r.isCheapest ? ' dear' : '');
      var flag = r.isCheapest ? ' <span class="rs-flag">' + E.esc(t('cheapest')) + '</span>' : '';
      html += '<div class="' + cls + '"><b>' + E.esc(r.name) + flag + '</b>' +
              '<span>' + E.money(r.cost) + '</span><span>' + r.eta + '</span></div>';
    });
    table.innerHTML = html;
  }

  function renderOutcome(shop, est){
    var txt = '<b>' + E.esc(shop.cheapest) + '</b> ' + E.esc(t('cheapest')) + ' ' +
              E.esc(t('at')) + ' ' + E.money(shop.cheapestCost) + '; ' +
              '<b>' + E.esc(shop.dearest) + '</b> ' + E.money(shop.dearestCost) + ' — ' +
              E.esc(t('spread')) + ' <b>' + E.money(shop.spread) + '</b> ' + E.esc(t('onEach')) + '.';
    if (est.orders > 0){
      txt += ' ' + E.esc(E.isBM() ? 'Pada' : 'At') + ' ' + est.orders + ' ' + E.esc(t('orders')) +
             ' ' + E.esc(t('perMonth')) + ', ' + E.esc(t('gapIs')) + ' <span class="sav">' +
             E.money(est.monthlySaving) + '</span> ' + E.esc(t('perMonth')) + '.';
    }
    outcome.innerHTML = txt;
  }

  /* Zone ladder: recompute the whole ladder for the current weight. */
  function renderLadder(weight){
    var rows = E.zoneLadder(weight);
    $all('[data-ladder]').forEach(function(el){
      var z = el.getAttribute('data-ladder');
      var hit = null;
      rows.forEach(function(r){ if (r.zone === z) hit = r; });
      el.innerHTML = hit ? E.money(hit.spread) : '—';
    });
    // Mark the zone whose cheapest courier differs from the cheapest in Zone A.
    var baseCheapest = rows[0] ? rows[0].cheapest : '';
    var note = $('#rcZoneNote');
    if (note){
      var flips = rows.filter(function(r){ return r.cheapest !== baseCheapest; })
                      .map(function(r){ return r.zone; });
      note.innerHTML = flips.length
        ? E.esc(E.isBM()
            ? 'Pada berat ini, kurier termurah berbeza pada Zone ' + flips.join(', ') +
              '. Itu sebabnya satu kurier tetap tidak cukup untuk seluruh negara.'
            : 'At this weight the cheapest courier changes in Zone ' + flips.join(', ') +
              '. That is why one fixed courier cannot be right for a whole country.')
        : E.esc(t('zoneNote'));
    }
  }

  function render(){
    var weight = E.clampWeight(wEl.value);
    var zone   = E.normZone(zEl.value);
    var orders = E.clampOrders(oEl.value);
    var shop   = E.rateShop(weight, zone);
    var est    = E.estimate(weight, zone, orders);
    renderTable(shop);
    renderOutcome(shop, est);
    renderLadder(weight);
  }

  [wEl, zEl, oEl].forEach(function(el){
    el.addEventListener('input', render);
    el.addEventListener('change', render);
  });

  E.onLangChange(render);
  render();
})();