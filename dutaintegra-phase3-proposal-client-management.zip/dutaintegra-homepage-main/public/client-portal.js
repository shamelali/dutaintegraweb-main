(() => {
  "use strict";

  const form = document.getElementById("portal-access-form");
  const email = document.getElementById("work-email");
  const error = document.getElementById("email-error");
  const status = document.getElementById("access-status");

  if (!form || !email || !error || !status) return;

  function showError(message) {
    email.setAttribute("aria-invalid", "true");
    error.textContent = message;
  }

  function clearError() {
    email.removeAttribute("aria-invalid");
    error.textContent = "";
  }

  email.addEventListener("input", clearError);

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    clearError();
    status.hidden = true;

    if (!email.value.trim()) {
      showError("Enter your work email address.");
      email.focus();
      return;
    }

    if (!email.validity.valid) {
      showError("Enter a valid work email address.");
      email.focus();
      return;
    }

    status.textContent = "Thanks — your address is ready for the invitation flow. If your organisation is already provisioned, Duta Integra will send a one-time sign-in link. This first portal release does not store passwords or credentials.";
    status.hidden = false;
  });
})();
