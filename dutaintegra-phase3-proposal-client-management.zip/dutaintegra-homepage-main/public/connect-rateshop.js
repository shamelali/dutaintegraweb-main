/* ============================================================
   connect-rateshop.js — illustrative rate comparison for /connect.

   All rate logic lives in /rates-engine.js (shared with the public
   rate calculator). This file only handles the widget's DOM.

   Progressive enhancement: the markup ships a server-rendered
   no-JS fallback row set; this script only upgrades the interaction.
   Nothing is stored (privacy notice §11) and no network call is made.
   ============================================================ */
(function(){
  'use strict';
  var E = window.DIRates;
  if (!E) return;

  var $ = function(s){ return document.querySelector(s); };
  var table = $('#rsTable'), outcome = $('#rsOutcome');
  var wEl = $('#rsWeight'), zEl = $('#rsZone'), oEl = $('#rsOrders');
  if (!table || !wEl || !zEl || !oEl) return;

  var STR = {
    en: { cheapest:'cheapest', perParcel:'per parcel', save:'you save', perMonth:'a month',
          across:'across', orders:'orders', at:'at', via:'via', east:'For Sabah and Sarawak the cheapest courier changes — check that row again' },
    ms: { cheapest:'murah', perParcel:'setiap pakej', save:'jimat', perMonth:'sebulan',
          across:'pada', orders:'pesanan', at:'pada', via:'melalui', east:'Untuk Sabah dan Sarawak, kurier termurah berubah — semak baris itu semula' }
  };
  function t(k){ return (E.isBM() ? STR.ms : STR.en)[k]; }

  function render(){
    var weight = E.clampWeight(wEl.value);
    var zone   = E.normZone(zEl.value);
    var orders = E.clampOrders(oEl.value);
    var shop   = E.rateShop(weight, zone);

    var html = '<div class="rs-row rs-head" aria-hidden="true">' +
      '<span>' + E.esc(E.isBM() ? 'Kurier' : 'Courier') + '</span>' +
      '<span>' + E.esc(E.isBM() ? 'Kos' : 'Cost') + '</span>' +
      '<span>' + E.esc(E.isBM() ? 'Hari' : 'Days') + '</span></div>';

    shop.rows.forEach(function(r){
      var cls = 'rs-row' + (r.isCheapest ? ' win' : '') + (r.isDearest && !r.isCheapest ? ' dear' : '');
      var flag = r.isCheapest ? ' <span class="rs-flag">' + E.esc(t('cheapest')) + '</span>' : '';
      html += '<div class="' + cls + '"><b>' + E.esc(r.name) + flag + '</b>' +
              '<span>' + E.money(r.cost) + '</span><span>' + r.eta + '</span></div>';
    });
    table.innerHTML = html;

    var est = E.estimate(weight, zone, orders);
    var msg = '<b>' + E.esc(shop.cheapest) + '</b> ' + E.esc(t('cheapest')) + ' ' +
              E.esc(t('at')) + ' ' + E.money(shop.cheapestCost) + ' ' + E.esc(t('perParcel'));
    if (orders > 0){
      msg += ' — ' + E.esc(t('save')) + ' <span class="sav">' + E.money(est.monthlySaving) +
             '</span> ' + E.esc(t('perMonth')) + ' ' + E.esc(t('across')) + ' ' +
             orders + ' ' + E.esc(t('orders')) + '.';
    } else {
      msg += ' — ' + E.esc(t('cheapest')) + ' ' + E.esc(t('at')) + ' ' + E.money(shop.cheapestCost) +
             ' ' + E.esc(t('via')) + ' <b>' + E.esc(shop.dearest) + '</b>, ' +
             E.esc(E.isBM() ? 'perbezaan' : 'spread') + ' <b>' + E.money(shop.spread) + '</b>.';
    }
    if (zone === 'C') msg += ' <span class="warn">' + E.esc(t('east')) + '.</span>';
    outcome.innerHTML = msg;
  }

  [wEl, zEl, oEl].forEach(function(el){
    el.addEventListener('input', render);
    el.addEventListener('change', render);
  });

  E.onLangChange(render);   // dynamic strings follow the language toggle
  render();
})();