(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { user: null, leads: [], proposals: [], projects: [] };
  const statusLabel = (value) => String(value || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  const money = (cents) => new Intl.NumberFormat('en-MY', { style: 'currency', currency: 'MYR', maximumFractionDigits: 2 }).format((Number(cents) || 0) / 100);
  function element(tag, cls, value) { const el = document.createElement(tag); if (cls) el.className = cls; if (value !== undefined) el.textContent = value; return el; }
  function record(title, detail, status, meta) {
    const card = element('article', 'record'); const top = element('div', 'record-top');
    top.append(element('h3', '', title || 'Untitled record'));
    if (status) top.append(element('span', `pill ${status}`, statusLabel(status)));
    card.append(top); if (detail) card.append(element('p', '', detail)); if (meta) card.append(element('p', 'meta', meta)); return card;
  }
  function empty(container, message) { container.replaceChildren(element('div', 'empty', message)); }
  async function api(path, options = {}) {
    const response = await fetch(`/api/workspace${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, credentials: 'same-origin', cache: 'no-store' });
    let data = {}; try { data = await response.json(); } catch {}
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  }
  function render() {
    $('identity').textContent = `${state.user.displayName || state.user.email} · ${statusLabel(state.user.role)}`;
    $('metric-leads').textContent = state.user.role === 'client' ? '—' : state.summary.leads;
    $('metric-proposals').textContent = state.summary.openProposals;
    $('metric-projects').textContent = state.summary.activeProjects;
    $('staff-tools').hidden = !['admin', 'staff'].includes(state.user.role);
    $('lead-count').textContent = state.leads.length; $('proposal-count').textContent = state.proposals.length; $('project-count').textContent = state.projects.length;
    const leads = $('leads-list');
    if (!state.leads.length) empty(leads, state.user.role === 'client' ? 'Lead pipeline is internal to Duta Integra.' : 'No leads recorded yet.');
    else { leads.replaceChildren(...state.leads.map((l) => { const c = record(l.company, `${l.contact_name} · ${l.email}`, l.status, `${l.service_interest} · ${new Date(l.created_at + 'Z').toLocaleDateString()}`); if (['admin','staff'].includes(state.user.role)) { const actions = element('div','record-actions'); [['qualified','Mark qualified'],['proposal','Proposal stage'],['won','Mark won'],['lost','Mark lost']].forEach(([s,label]) => { const b = element('button','',label); b.type='button'; b.addEventListener('click',()=>updateLead(l.id,s)); actions.append(b); }); c.append(actions); } return c; })); }
    const proposals = $('proposals-list');
    if (!state.proposals.length) empty(proposals, 'No proposals available.');
    else { proposals.replaceChildren(...state.proposals.map((p) => { const c = record(p.title, `${money(p.amount_cents)} · ${p.summary || 'No summary supplied'}`, p.status, `Created ${new Date(p.created_at + 'Z').toLocaleDateString()}${p.valid_until ? ` · Valid until ${p.valid_until}` : ''}`); if (state.user.role === 'client' && p.status === 'sent') { const actions=element('div','record-actions'); [['accepted','Accept proposal'],['declined','Decline proposal']].forEach(([s,label])=>{const b=element('button','',label);b.type='button';b.addEventListener('click',()=>updateProposal(p.id,s));actions.append(b);}); c.append(actions); } return c; })); }
    const projects = $('projects-list');
    if (!state.projects.length) empty(projects, 'No projects recorded yet.');
    else { projects.replaceChildren(...state.projects.map((p)=>record(p.name, `${p.organization_name || 'Client project'} · Next: ${p.next_action || 'Next action to be confirmed'}`, p.status, p.target_date ? `Target ${p.target_date}` : `Updated ${new Date(p.updated_at + 'Z').toLocaleDateString()}`))); }
  }
  function notice(message, isError = false) { const box=$('notice'); box.textContent=message; box.hidden=false; box.style.borderColor=isError?'rgba(255,130,130,.35)':''; box.style.color=isError?'#ffc2c2':''; }
  async function refresh() { const data=await api(''); Object.assign(state,data); render(); }
  async function updateLead(id,status) { try { await api(`/leads/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status})}); await refresh(); notice('Lead status updated.'); } catch(e){notice(e.message,true);} }
  async function updateProposal(id,status) { const action=status==='accepted'?'accept':'decline'; if(!window.confirm(`Confirm that you want to ${action} this proposal?`)) return; try { await api(`/proposals/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status})}); await refresh(); notice(`Proposal ${action}ed.`); } catch(e){notice(e.message,true);} }
  $('lead-form').addEventListener('submit',async(e)=>{e.preventDefault();const form=e.currentTarget;const b=Object.fromEntries(new FormData(form).entries());try{await api('/leads',{method:'POST',body:JSON.stringify(b)});form.reset();await refresh();notice('Lead saved.');}catch(err){notice(err.message,true);}});
  $('proposal-form').addEventListener('submit',async(e)=>{e.preventDefault();const form=e.currentTarget;const fd=new FormData(form);const b={title:fd.get('title'),amount:fd.get('amount'),leadId:fd.get('leadId'),organizationId:fd.get('organizationId'),validUntil:fd.get('validUntil'),summary:fd.get('summary'),status:fd.get('sendNow')==='on'?'sent':'draft'};try{await api('/proposals',{method:'POST',body:JSON.stringify(b)});form.reset();await refresh();notice('Proposal created. Verify the scope and price before sharing it with the client.');}catch(err){notice(err.message,true);}});
  $('project-form').addEventListener('submit',async(e)=>{e.preventDefault();const form=e.currentTarget;const b=Object.fromEntries(new FormData(form).entries());try{await api('/projects',{method:'POST',body:JSON.stringify(b)});form.reset();await refresh();notice('Project created.');}catch(err){notice(err.message,true);}});
  async function init(){try{const data=await api('');Object.assign(state,data);$('loading').hidden=true;$('workspace').hidden=false;render();}catch(err){$('loading').hidden=true;$('access-error').hidden=false;$('access-message').textContent=err.message;}}
  init();
})();
