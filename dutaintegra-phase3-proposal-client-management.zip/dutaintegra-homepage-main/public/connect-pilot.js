/* ============================================================
   connect-pilot.js — Duta Connect pilot signup form.

   Posts to the SAME /api/send-email endpoint as the homepage audit
   form, with the same contract: { name, email, company?, phone?,
   service, message, consent:true, source?, page? }.

   IMPORTANT (mirrors index.html): the server checks the request Origin
   against ALLOWED_ORIGINS and 403s anything not on the list. If the
   deployed domain is not allowlisted the form falls back to WhatsApp
   rather than silently failing.

   Analytics reuses window.__di_trackForm when analytics.js is present.
   Nothing is written to localStorage/sessionStorage (privacy notice §11).
   ============================================================ */
(function(){
  'use strict';
  var $  = function(s){ return document.querySelector(s); };
  var form = $('#pilotForm');
  if (!form) return;

  var msgBox = $('#pilotMsg'), btn = $('#pilotBtn'), done = $('#pilotDone');
  var WA_NUMBER = '601154034051';

  /* ---------- bilingual strings (mirrors the data-i18n layer) ---------- */
  var BM = {
    sending:'Menghantar…',
    submit:'Hantar butiran saya',
    fixErrors:'Sila semak medan yang ditandai.',
    errNoConsent:'Sila tandakan kebenaran PDPA untuk meneruskan.',
    errInvalid:'Format e-mel atau nombor tidak sah.',
    okMsg:'Terima kasih — butiran anda telah sampai. Kami akan membalas dalam satu hari bekerja. <a href="{a}" target="_blank" rel="noopener">Hantar melalui WhatsApp</a> jika anda mahu bercakap sekarang.',
    errMsg:'Kami tidak dapat menghantar melalui borang sekarang. <a href="{a}" target="_blank" rel="noopener">Hantar butiran yang sama melalui WhatsApp</a> supaya tiada yang hilang.'
  };
  function t(k){
    var bm = document.documentElement.lang === 'ms';
    return (bm && BM[k]) || { sending:'Sending…', submit:'Send my details',
      fixErrors:'Please check the highlighted fields.',
      errNoConsent:'Please tick the PDPA consent box to continue.',
      errInvalid:'That email or number does not look right.',
      okMsg:'Thank you — your details reached us. We reply within one business day. <a href="{a}" target="_blank" rel="noopener">Send via WhatsApp</a> if you would rather talk now.',
      errMsg:'We could not send via the form just now. <a href="{a}" target="_blank" rel="noopener">Send the same details over WhatsApp</a> so nothing is lost.'
    }[k];
  }
  function fill(tpl, wa){
    return tpl.replace('{a}', wa);
  }

  function show(kind, html){
    msgBox.className = 'form-msg ' + kind;
    msgBox.innerHTML = html;
  }

  /* ---------- validation (mirrors the audit form) ---------- */
  function fields(){ return ['pName','pEmail','pVolume','pChannels','pMsg','pConsent']; }
  function clearValidation(){
    fields().forEach(function(id){
      var el = $('#'+id); if (el) el.removeAttribute('aria-invalid');
    });
  }
  function missingFields(){
    var ids = [];
    if (!$('#pName').value.trim()) ids.push('pName');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test($('#pEmail').value.trim())) ids.push('pEmail');
    if (!$('#pVolume').value) ids.push('pVolume');
    if (!$('#pChannels').value) ids.push('pChannels');
    if (!$('#pMsg').value.trim()) ids.push('pMsg');
    if (!$('#pConsent').checked) ids.push('pConsent');
    return ids;
  }

  function waLink(p){
    var lines = [
      'Duta Connect pilot enquiry',
      '',
      'Name: ' + p.name
    ];
    if (p.company) lines.push('Company: ' + p.company);
    lines.push('Email: ' + p.email);
    if (p.phone) lines.push('Phone: ' + p.phone);
    lines.push('Orders per month: ' + p.volume);
    lines.push('Selling on: ' + p.channels);
    lines.push('');
    lines.push(p.message);
    return 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(lines.join('\n'));
  }

  form.addEventListener('submit', function(e){
    e.preventDefault();
    clearValidation();

    var ids = missingFields();
    if (ids.length){
      ids.forEach(function(id){ var el = $('#'+id); if (el) el.setAttribute('aria-invalid','true'); });
      if (ids[0]) $('#'+ids[0]).focus();
      show('err', !$('#pConsent').checked ? t('errNoConsent') : t('fixErrors'));
      if (window.__di_trackForm) window.__di_trackForm('validation_error', { form:'pilot' });
      return;
    }

    var payload = {
      name:     $('#pName').value.trim(),
      company:  $('#pCompany').value.trim(),
      email:    $('#pEmail').value.trim(),
      phone:    $('#pPhone').value.trim(),
      // value= is pinned to English so the payload stays stable in both languages
      service:  'Duta Connect pilot — ' + $('#pVolume').value + ' orders/month via ' + $('#pChannels').value,
      message:  'Orders per month: ' + $('#pVolume').value + '\nSelling on: ' + $('#pChannels').value + '\n\n' + $('#pMsg').value.trim(),
      consent:  true,
      source:   (window.__di_attribution ? window.__di_attribution() : 'direct'),
      page:     location.href
    };

    if ($('#pWebsite').value) return; // honeypot tripped — no request, no message

    btn.disabled = true;
    $('#pilotBtn span').textContent = t('sending');

    fetch('/api/send-email', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    })
    .then(function(r){ if(!r.ok) throw new Error('HTTP ' + r.status); return r.json().catch(function(){return{};}); })
    .then(function(){
      form.reset();
      clearValidation();
      btn.disabled = false;
      $('#pilotBtn span').textContent = t('submit');
      form.style.display = 'none';
      if (done){ done.classList.add('on'); done.setAttribute('tabindex','-1'); done.focus(); }
      if (window.__di_trackForm) window.__di_trackForm('success', { service:'duta_connect_pilot', volume: payload.service });
    })
    .catch(function(){
      btn.disabled = false;
      $('#pilotBtn span').textContent = t('submit');
      // Offline, static preview, or origin not allowlisted — hand off to WhatsApp so the lead isn't lost.
      if (window.__di_trackForm) window.__di_trackForm('fallback', { reason:'api_unreachable_or_forbidden', form:'pilot' });
      show('err', fill(t('errMsg'), waLink(payload)));
    });
  });
})();