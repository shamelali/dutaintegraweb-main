/* ============================================================
   services-i18n.js — shared behaviour for the Duta Integra service
   pages (/ai-operations, /managed-it, /security-pdpa, /websites).

   Same architecture as the homepage: the English string is the
   markup, BM is swapped in via [data-i18n] / [data-i18n-attr], the
   English original is cached on el.dataset.en so switching back is
   lossless, and NOTHING is written to storage — BM is the site
   default and an EN choice survives only as ?lang=en in the URL
   (privacy notice §11).

   The BM dictionary is NOT in this file. Each page loads its own
   /bm/<page>.js first, which sets window.DI_PAGE_BM, and the shared
   chrome strings come from window.DI_CHROME_BM on the same object.
   ============================================================ */
(function(){
  'use strict';
  var $ = function(s,c){ return (c||document).querySelector(s); };
  var $$ = function(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); };

  var BM = {};

  function setLang(bm){
    $$('.lang button').forEach(function(x){
      x.setAttribute('aria-pressed', String((x.getAttribute('data-lang') === 'bm') === bm));
    });
    $$('[data-i18n]').forEach(function(el){
      var k  = el.getAttribute('data-i18n');
      var at = el.getAttribute('data-i18n-attr');
      if (el.dataset.en === undefined) el.dataset.en = at ? el.getAttribute(at) : el.innerHTML;
      var v = bm ? (BM[k] || el.dataset.en) : el.dataset.en;
      if (at) el.setAttribute(at, v); else el.innerHTML = v;
    });
    document.documentElement.lang = bm ? 'ms' : 'en';
    try {
      var u = new URL(location.href);
      // BM is the site default (no param); an EN choice is recorded as ?lang=en.
      if (!bm) u.searchParams.set('lang','en'); else u.searchParams.delete('lang');
      history.replaceState(null, '', u.pathname + u.search + u.hash);
    } catch(e){ /* file:// or a sandboxed frame — the toggle still works */ }
  }

  function initNav(){
    var burger = $('.burger'), mnav = $('#mnav');
    if (burger && mnav){
      burger.addEventListener('click', function(){
        var open = mnav.getAttribute('data-open') === 'true';
        mnav.setAttribute('data-open', open ? 'false' : 'true');
        burger.setAttribute('aria-expanded', open ? 'false' : 'true');
      });
      $$('#mnav a').forEach(function(a){
        a.addEventListener('click', function(){
          mnav.setAttribute('data-open','false');
          burger.setAttribute('aria-expanded','false');
        });
      });
    }

    var groups = $$('.nav-group');
    function closeAll(keep){
      groups.forEach(function(g){
        if (g === keep) return;
        g.setAttribute('data-open','false');
        var b = g.querySelector('.nav-trigger');
        if (b) b.setAttribute('aria-expanded','false');
      });
    }

    groups.forEach(function(g){
      var btn = g.querySelector('.nav-trigger');
      if (!btn) return;
      btn.addEventListener('click', function(){
        var open = g.getAttribute('data-open') === 'true';
        closeAll(g);
        g.setAttribute('data-open', open ? 'false' : 'true');
        btn.setAttribute('aria-expanded', open ? 'false' : 'true');
      });
      g.addEventListener('mouseenter', function(){
        if (!window.matchMedia('(min-width:1041px)').matches) return;
        closeAll(g);
        g.setAttribute('data-open','true');
        btn.setAttribute('aria-expanded','true');
      });
    });

    var nav = $('.nav');
    if (nav){
      nav.addEventListener('mouseleave', function(){
        if (!window.matchMedia('(min-width:1041px)').matches) return;
        closeAll(null);
      });
    }

    document.addEventListener('click', function(e){
      var inside = e.target.closest ? e.target.closest('.nav-group') : null;
      closeAll(inside);
    });

    document.addEventListener('keydown', function(e){
      if (e.key !== 'Escape') return;
      var open = $('.nav-group[data-open="true"]');
      if (!open) return;
      var b = open.querySelector('.nav-trigger');
      closeAll(null);
      if (b) b.focus();
    });
  }

  function init(){
    var yr = $('#yr');
    if (yr) yr.textContent = new Date().getFullYear();
    initNav();
    $$('.lang button').forEach(function(b){
      b.addEventListener('click', function(){ setLang(b.getAttribute('data-lang') === 'bm'); });
    });
    // BM is the site default; ?lang=en opts back to English (nothing is stored)
    if (new URLSearchParams(location.search).get('lang') !== 'en') setLang(true);
  }

  function merge(src){
    if (!src) return;
    for (var k in src){
      if (Object.prototype.hasOwnProperty.call(src, k)) BM[k] = src[k];
    }
  }

  merge(window.DI_CHROME_BM);
  merge(window.DI_PAGE_BM);

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  window.DI_SERVICES = { bm: BM, setLang: setLang };
})();