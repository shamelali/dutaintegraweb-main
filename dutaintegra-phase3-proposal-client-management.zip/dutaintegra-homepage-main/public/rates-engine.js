/* ============================================================
   rates-engine.js — shared multi-carrier rate engine (browser side).

   Single source of truth for the illustrative rate logic used by:
     /connect                     (connect-rateshop.js)
     /connect/rate-calculator      (rate-calculator.js)

   Mirrors the DutaOS reference service (dutaos/repo/connect.py):
     cost = base + per_kg * weight + zone_surcharge
     eta  = days (+2 on zone C, Sabah & Sarawak)

   !! ILLUSTRATIVE SEED DATA — NOT LIVE CARRIER QUOTES. !!
   The *structure* (base + per-kg + zone surcharge) is how Malaysian
   couriers genuinely price, so comparisons and zone effects are
   directionally meaningful. The absolute numbers are not live quotes
   and must never be presented as such.

   tools/connect-rateshop-test.js pins these values against connect.py
   so the three implementations cannot silently drift apart.

   No storage, no network calls (privacy notice §11).
   ============================================================ */
(function (global) {
  'use strict';

  var RATES = [
    { name: 'Ninja Van',     base: 4.00, perKg: 1.25, days: 2, sur: { A: 0,    B: 0.60, C: 4.00 } },
    { name: 'J&T Express',   base: 4.20, perKg: 1.35, days: 3, sur: { A: 0,    B: 0.50, C: 3.50 } },
    { name: 'Pos Laju',      base: 4.50, perKg: 1.40, days: 3, sur: { A: 0,    B: 0.40, C: 3.00 } },
    { name: 'DHL eCommerce', base: 6.00, perKg: 2.10, days: 2, sur: { A: 0,    B: 1.20, C: 6.50 } }
  ];

  var WEIGHT_MIN = 0.1, WEIGHT_MAX = 30;
  var ORDERS_MAX = 200000;

  function clampWeight(v){
    var n = parseFloat(v);
    if (!isFinite(n)) n = 1;
    return Math.min(Math.max(n, WEIGHT_MIN), WEIGHT_MAX);
  }
  function clampOrders(v){
    var n = parseInt(v, 10);
    if (!isFinite(n) || n < 0) n = 0;
    return Math.min(n, ORDERS_MAX);
  }
  function normZone(z){
    z = String(z || '').toUpperCase().charAt(0);
    return (z === 'A' || z === 'B' || z === 'C') ? z : 'B';
  }
  function round2(n){ return Math.round(n * 100) / 100; }

  /* Compare every courier for one parcel. */
  function rateShop(weightKg, zone){
    var w = clampWeight(weightKg), z = normZone(zone);
    var rows = RATES.map(function (r) {
      return {
        name: r.name,
        cost: round2(r.base + r.perKg * w + r.sur[z]),
        surcharge: r.sur[z],
        eta: r.days + (z === 'C' ? 2 : 0)
      };
    }).sort(function (a, b) { return a.cost - b.cost; });

    var cheapest = rows[0], dearest = rows[rows.length - 1];
    return {
      weightKg: w,
      zone: z,
      rows: rows.map(function (r, i) {
        return {
          name: r.name,
          cost: r.cost,
          surcharge: r.surcharge,
          eta: r.eta,
          isCheapest: i === 0,
          isDearest: i === rows.length - 1
        };
      }),
      cheapest: cheapest.name,
      dearest: dearest.name,
      cheapestCost: cheapest.cost,
      dearestCost: dearest.cost,
      spread: round2(dearest.cost - cheapest.cost)
    };
  }

  /* Monthly projection, and what comparison would save versus always
     defaulting to the dearest courier (the common manual behaviour). */
  function estimate(weightKg, zone, orders){
    var shop = rateShop(weightKg, zone);
    var n = clampOrders(orders);
    var monthly = round2(shop.cheapestCost * n);
    var dearestMonthly = round2(shop.dearestCost * n);
    return {
      orders: n,
      zone: shop.zone,
      perOrder: shop.cheapestCost,
      monthlyTotal: monthly,
      ifAlwaysDearest: dearestMonthly,
      monthlySaving: round2(dearestMonthly - monthly)
    };
  }

  /* Zone cost escalation: the same parcel at the dearest courier across
     all three bands. This is the insight sellers cannot get today. */
  function zoneLadder(weightKg){
    return ['A', 'B', 'C'].map(function (z) {
      var s = rateShop(weightKg, z);
      return {
        zone: z,
        cheapest: s.cheapest,
        cheapestCost: s.cheapestCost,
        dearestCost: s.dearestCost,
        spread: s.spread
      };
    });
  }

  function money(n){
    return 'RM ' + Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function esc(s){
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function isBM(){ return document.documentElement.lang === 'ms'; }

  /* Re-render `fn` whenever the page language flips, so JS-written
     strings follow the same toggle as the [data-i18n] layer. */
  function onLangChange(fn){
    if (typeof MutationObserver === 'undefined') return;
    new MutationObserver(fn).observe(document.documentElement,
      { attributes: true, attributeFilter: ['lang'] });
  }

  global.DIRates = {
    RATES: RATES,
    rateShop: rateShop,
    estimate: estimate,
    zoneLadder: zoneLadder,
    normZone: normZone,
    money: money,
    esc: esc,
    isBM: isBM,
    onLangChange: onLangChange,
    clampWeight: clampWeight,
    clampOrders: clampOrders,
    limits: { weightMin: WEIGHT_MIN, weightMax: WEIGHT_MAX, ordersMax: ORDERS_MAX }
  };
})(window);