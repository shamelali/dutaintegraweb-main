(function (root) {
  'use strict';

  var STATES = Object.freeze({
    IDLE: 'idle',
    MONITORING: 'monitoring',
    AWAITING_APPROVAL: 'awaiting-approval',
    RECOVERING: 'recovering',
    COMPLETE: 'complete'
  });

  var STATE_ORDER = [STATES.IDLE, STATES.MONITORING, STATES.AWAITING_APPROVAL, STATES.RECOVERING, STATES.COMPLETE];

  function createInitialState() {
    return { state: STATES.IDLE, runId: null, events: [], startedAt: null, cancelled: false };
  }

  function transitionState(current, action) {
    var state = current && current.state ? current.state : STATES.IDLE;
    if (action === 'START' && state === STATES.IDLE) return STATES.MONITORING;
    if (action === 'APPROVE' && state === STATES.AWAITING_APPROVAL) return STATES.RECOVERING;
    if (action === 'COMPLETE' && state === STATES.RECOVERING) return STATES.COMPLETE;
    if (action === 'REJECT' && state === STATES.AWAITING_APPROVAL) return STATES.IDLE;
    if (action === 'CANCEL' && state !== STATES.IDLE && state !== STATES.COMPLETE) return STATES.IDLE;
    if (action === 'RESET') return STATES.IDLE;
    return state;
  }

  function parseCents(value) {
    var text = String(value == null ? '' : value).trim().replace(/,/g, '');
    if (!/^\d+(?:\.\d{1,2})?$/.test(text)) return { ok: false, error: 'Use a non-negative amount with up to 2 decimals.' };
    var parts = text.split('.');
    var whole = Number(parts[0]);
    var fraction = parts[1] || '';
    if (!Number.isSafeInteger(whole)) return { ok: false, error: 'Amount is too large for an exact draft.' };
    var cents = whole * 100 + Number((fraction + '00').slice(0, 2));
    if (!Number.isSafeInteger(cents)) return { ok: false, error: 'Amount is too large for an exact draft.' };
    return { ok: true, cents: cents };
  }

  function parseWhole(value, label) {
    var text = String(value == null ? '' : value).trim();
    if (!/^\d+$/.test(text)) return { ok: false, error: label + ' must be a whole number.' };
    var number = Number(text);
    if (!Number.isSafeInteger(number)) return { ok: false, error: label + ' is too large for an exact draft.' };
    return { ok: true, value: number };
  }

  function formatRM(cents) {
    return 'RM ' + (cents / 100).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function validateProposalInput(input) {
    var fields = {};
    var errors = {};
    var quantity = parseWhole(input.hardwareQuantity, 'Quantity');
    var hardware = parseCents(input.hardwareUnitCost);
    var hours = parseWhole(input.laborHours, 'Hours');
    var rate = parseCents(input.laborRate);
    var monthly = parseCents(input.slaMonthly);
    var months = parseWhole(input.slaMonths, 'Term');
    fields.hardwareQuantity = quantity.ok ? quantity.value : 0;
    fields.hardwareUnitCostCents = hardware.ok ? hardware.cents : 0;
    fields.laborHours = hours.ok ? hours.value : 0;
    fields.laborRateCents = rate.ok ? rate.cents : 0;
    fields.slaMonthlyCents = monthly.ok ? monthly.cents : 0;
    fields.slaMonths = months.ok ? months.value : 0;
    if (!quantity.ok) errors.hardwareQuantity = quantity.error;
    if (!hardware.ok) errors.hardwareUnitCost = hardware.error;
    if (!hours.ok) errors.laborHours = hours.error;
    if (!rate.ok) errors.laborRate = rate.error;
    if (!monthly.ok) errors.slaMonthly = monthly.error;
    if (!months.ok) errors.slaMonths = months.error;
    var products = [fields.hardwareQuantity, fields.hardwareUnitCostCents, fields.laborHours, fields.laborRateCents, fields.slaMonthlyCents, fields.slaMonths];
    if (!Object.keys(errors).length && products.some(function (value) { return !Number.isSafeInteger(value); })) errors.general = 'Values exceed the exact arithmetic limit.';
    return { ok: !Object.keys(errors).length, fields: fields, errors: errors };
  }

  function calculateProposal(input) {
    var checked = validateProposalInput(input);
    if (!checked.ok) return checked;
    var f = checked.fields;
    var hardwareTotalCents = f.hardwareQuantity * f.hardwareUnitCostCents;
    var laborTotalCents = f.laborHours * f.laborRateCents;
    var slaTotalCents = f.slaMonthlyCents * f.slaMonths;
    var totalCents = hardwareTotalCents + laborTotalCents + slaTotalCents;
    if (![hardwareTotalCents, laborTotalCents, slaTotalCents, totalCents].every(Number.isSafeInteger)) return { ok: false, fields: f, errors: { general: 'The draft is too large for exact integer-cent arithmetic.' } };
    return { ok: true, fields: f, totals: { hardwareTotalCents: hardwareTotalCents, laborTotalCents: laborTotalCents, slaTotalCents: slaTotalCents, totalCents: totalCents } };
  }

  function buildDraftText(input) {
    var result = calculateProposal(input);
    if (!result.ok) return result;
    var f = result.fields;
    var t = result.totals;
    var draft = { type: 'illustrative-proposal-draft', commitment: false, currency: 'MYR', inputs: { hardware: { quantity: f.hardwareQuantity, unitCostCents: f.hardwareUnitCostCents }, labor: { hours: f.laborHours, rateCentsPerHour: f.laborRateCents }, slaPlanning: { monthlyCents: f.slaMonthlyCents, months: f.slaMonths } }, totals: t };
    var markdown = '# Illustrative proposal draft\n\n- Commitment: none\n- Currency: MYR\n\n| Line | Amount |\n| --- | ---: |\n| Hardware | ' + formatRM(t.hardwareTotalCents) + ' |\n| Labor | ' + formatRM(t.laborTotalCents) + ' |\n| SLA planning (' + f.slaMonths + ' months) | ' + formatRM(t.slaTotalCents) + ' |\n| **Illustrative total** | **' + formatRM(t.totalCents) + '** |\n\nThis is a local planning draft only. It is not a quote, order, contract, reservation, or commitment.';
    return { ok: true, json: JSON.stringify(draft, null, 2), markdown: markdown, totals: t, draft: draft };
  }

  var api = { STATES: STATES, STATE_ORDER: STATE_ORDER, createInitialState: createInitialState, transitionState: transitionState, parseCents: parseCents, validateProposalInput: validateProposalInput, calculateProposal: calculateProposal, buildDraftText: buildDraftText, formatRM: formatRM };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (!root || !root.document) return;

  var doc = root.document;
  var state = createInitialState();
  var timers = [];
  var eventCounter = 0;
  var paused = false;
  var nodes = {
    start: doc.getElementById('start-button'), reset: doc.getElementById('reset-button'), cancel: doc.getElementById('cancel-button'), approve: doc.getElementById('approve-button'), reject: doc.getElementById('reject-button'), approval: doc.getElementById('approval-actions'), status: doc.getElementById('scenario-status'), orb: doc.getElementById('status-orb'), tag: doc.getElementById('telemetry-tag'), cpu: doc.getElementById('cpu-metric'), availability: doc.getElementById('availability-metric'), queue: doc.getElementById('queue-metric'), run: doc.getElementById('run-metric'), director: doc.getElementById('director-message'), proposal: doc.getElementById('proposal-box'), proposalTime: doc.getElementById('proposal-time'), activity: doc.getElementById('activity-list'), count: doc.getElementById('activity-count'), live: doc.getElementById('live-status'), form: doc.getElementById('draft-form'), output: doc.getElementById('draft-output'), draftState: doc.getElementById('draft-state'), clear: doc.getElementById('clear-form')
  };

  function clearTimers() { timers.forEach(function (timer) { root.clearTimeout(timer); }); timers = []; }
  function later(callback, delay) { var timer = root.setTimeout(function () { timers = timers.filter(function (item) { return item !== timer; }); callback(); }, delay); timers.push(timer); }
  function nowLabel() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
  function announce(message) { nodes.live.textContent = message; }
  function addEvent(message) { state.events.push({ time: nowLabel(), message: message }); var item = doc.createElement('li'); var time = doc.createElement('time'); time.textContent = state.events[state.events.length - 1].time; var text = doc.createElement('span'); text.textContent = message; item.appendChild(time); item.appendChild(text); if (state.events.length === 1) { var empty = doc.getElementById('empty-activity'); if (empty) empty.remove(); } nodes.activity.appendChild(item); nodes.count.textContent = state.events.length + (state.events.length === 1 ? ' event' : ' events'); }
  function renderTimeline() { var current = STATE_ORDER.indexOf(state.state); doc.querySelectorAll('.timeline-step').forEach(function (step) { var stepIndex = STATE_ORDER.indexOf(step.getAttribute('data-step')); step.classList.toggle('is-active', stepIndex === current); step.classList.toggle('is-done', stepIndex < current); }); }
  function render() {
    nodes.status.textContent = ({ idle: 'Ready to simulate', monitoring: 'Signal under review', 'awaiting-approval': 'Human approval required', recovering: 'Guided recovery in progress', complete: 'Simulation complete' })[state.state];
    nodes.orb.setAttribute('data-state', state.state); nodes.cancel.disabled = state.state === STATES.IDLE || state.state === STATES.COMPLETE; nodes.start.disabled = state.state !== STATES.IDLE;
    nodes.cpu.textContent = state.state === STATES.IDLE ? '—' : '87%'; nodes.availability.textContent = state.state === STATES.IDLE ? '—' : 'UNAVAILABLE'; nodes.queue.textContent = state.state === STATES.IDLE ? '—' : '04:12'; nodes.run.textContent = state.runId || '—';
    nodes.tag.textContent = state.state === STATES.IDLE ? 'WAITING' : state.state === STATES.COMPLETE ? 'RESOLVED' : state.state === STATES.AWAITING_APPROVAL ? 'REVIEW' : 'ACTIVE'; nodes.tag.className = 'tag ' + (state.state === STATES.COMPLETE ? 'tag-success' : state.state === STATES.AWAITING_APPROVAL ? 'tag-warning' : 'tag-warning');
    nodes.approval.hidden = state.state !== STATES.AWAITING_APPROVAL; nodes.proposal.setAttribute('data-state', state.state); renderTimeline();
  }
  function resetRun(message) { clearTimers(); state = createInitialState(); render(); nodes.director.textContent = 'Start the simulation to reveal the illustrative signal and the proposed next step.'; nodes.proposalTime.textContent = 'Awaiting run'; nodes.activity.textContent = ''; var empty = doc.createElement('li'); empty.className = 'empty-activity'; empty.id = 'empty-activity'; empty.textContent = 'No events yet. Run the scenario to populate the local activity log.'; nodes.activity.appendChild(empty); nodes.count.textContent = '0 events'; if (message) { addEvent(message); announce(message); } }
  function startRun() { if (state.state !== STATES.IDLE) return; clearTimers(); eventCounter += 1; state = { state: STATES.MONITORING, runId: 'SIM-' + String(eventCounter).padStart(3, '0'), events: [], startedAt: Date.now(), cancelled: false }; nodes.director.textContent = 'Reviewing an illustrative CPU warning and simulated unavailable flag.'; nodes.proposalTime.textContent = 'just now'; addEvent('Astra director opened a local simulation run.'); addEvent('GPT-Sol telemetry reported CPU 87% · warning.'); announce('Monitoring started. Simulated CPU warning is visible.'); render(); later(function () { if (state.state !== STATES.MONITORING) return; state.state = STATES.AWAITING_APPROVAL; nodes.director.textContent = 'Suggested response: isolate the illustrative workload, then verify the service signal after recovery.'; nodes.proposalTime.textContent = 'review now'; addEvent('Simulated unavailable flag raised · critical review required.'); addEvent('Proposal is waiting for human approval.'); announce('Approval required. Review the illustrative recovery proposal.'); render(); }, 1700); }
  function approveRun() { if (state.state !== STATES.AWAITING_APPROVAL) return; clearTimers(); state.state = STATES.RECOVERING; nodes.director.textContent = 'Demonstrating the approved recovery path. No command has been sent anywhere.'; nodes.proposalTime.textContent = 'in progress'; addEvent('Human approval recorded for this demonstration only.'); addEvent('Recovery sequence is running locally.'); announce('Recovery demonstration started.'); render(); later(function () { if (state.state !== STATES.RECOVERING) return; state.state = STATES.COMPLETE; nodes.director.textContent = 'The local scenario reached a stable end state. Review the activity log; no infrastructure was changed.'; nodes.proposalTime.textContent = 'complete'; addEvent('Illustrative signal returned to a reviewable state.'); addEvent('Simulation complete · no external action taken.'); announce('Simulation complete. No external action was taken.'); render(); }, 1700); }
  function rejectRun() { if (state.state !== STATES.AWAITING_APPROVAL) return; clearTimers(); state.state = STATES.IDLE; state.cancelled = true; nodes.director.textContent = 'Proposal rejected. Nothing was executed; the local scenario is ready again.'; nodes.proposalTime.textContent = 'rejected'; addEvent('Human rejected the illustrative proposal.'); announce('Proposal rejected. Nothing was executed.'); render(); nodes.start.disabled = false; nodes.cancel.disabled = true; }
  function cancelRun() { if (state.state === STATES.IDLE || state.state === STATES.COMPLETE) return; clearTimers(); state.state = STATES.IDLE; state.cancelled = true; nodes.director.textContent = 'Run cancelled. No external action was taken.'; nodes.proposalTime.textContent = 'cancelled'; addEvent('Simulation cancelled by operator.'); announce('Simulation cancelled. No external action was taken.'); render(); }
  function getInputValues() { return { hardwareQuantity: doc.getElementById('hardware-quantity').value, hardwareUnitCost: doc.getElementById('hardware-unit-cost').value, laborHours: doc.getElementById('labor-hours').value, laborRate: doc.getElementById('labor-rate').value, slaMonthly: doc.getElementById('sla-monthly').value, slaMonths: doc.getElementById('sla-months').value }; }
  function showErrors(errors) { ['hardwareQuantity','hardwareUnitCost','laborHours','laborRate','slaMonthly','slaMonths'].forEach(function (key) { var input = doc.getElementById(key === 'hardwareQuantity' ? 'hardware-quantity' : key === 'hardwareUnitCost' ? 'hardware-unit-cost' : key === 'laborHours' ? 'labor-hours' : key === 'laborRate' ? 'labor-rate' : key === 'slaMonthly' ? 'sla-monthly' : 'sla-months'); var error = doc.getElementById(input.id + '-error'); input.setAttribute('aria-invalid', errors[key] ? 'true' : 'false'); error.textContent = errors[key] || ''; }); }
  function clearErrors() { showErrors({}); }
  function buildPreview(event) { event.preventDefault(); var result = buildDraftText(getInputValues()); if (!result.ok) { showErrors(result.errors); nodes.draftState.textContent = 'CHECK INPUTS'; nodes.draftState.className = 'tag tag-critical'; nodes.form.querySelector('[aria-invalid="true"]').focus(); return; } clearErrors(); nodes.output.textContent = result.json + '\n\n' + result.markdown; nodes.draftState.textContent = 'LOCAL DRAFT'; nodes.draftState.className = 'tag tag-success'; }
  function clearPreview() { nodes.form.reset(); clearErrors(); nodes.output.textContent = 'Build a preview to see validated planning math.'; nodes.draftState.textContent = 'EMPTY'; nodes.draftState.className = 'tag tag-neutral'; }

  nodes.start.addEventListener('click', startRun); nodes.reset.addEventListener('click', function () { resetRun(); announce('Simulation reset. Ready to start.'); }); nodes.cancel.addEventListener('click', cancelRun); nodes.approve.addEventListener('click', approveRun); nodes.reject.addEventListener('click', rejectRun); nodes.form.addEventListener('submit', buildPreview); nodes.clear.addEventListener('click', clearPreview); render();
  root.addEventListener('pagehide', function () { paused = true; clearTimers(); }); root.addEventListener('pageshow', function () { if (!paused) return; paused = false; if (state.state !== STATES.IDLE && state.state !== STATES.COMPLETE) { cancelRun(); } else render(); });
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
