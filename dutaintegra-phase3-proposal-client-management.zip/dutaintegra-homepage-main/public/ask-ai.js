(function (global, commonJs) {
  'use strict';

  var MAX_MESSAGES = 24;
  var MAX_QUESTION_LENGTH = 240;

  var answers = [
    {
      id: 'scorecard',
      keys: ['scorecard', '25 point', '25-point', 'how to score', 'priority band', 'print save'],
      answer: 'Scorecard guide: this is a printable, manual self-assessment — not an interactive calculator. Enter the header details, mark one level for each of the 25 lines (0 No, 1 Ad hoc, 2 Partly, 3 Yes, or 4 Proven), add the five answers in each section (20 points maximum), then total all five sections out of 100. Use the bands 80–100 Strong, 60–79 Fair, 40–59 At risk, and 0–39 Critical. Leave unknown items blank and use them as your audit agenda. The report is free; name, company, email and consent are requested at the contact gate before print/save is unlocked.',
      links: [['Open scorecard', '/audit-scorecard'], ['Read the guide', '/audit-guide']]
    },
    {
      id: 'gap',
      keys: ['gap check', 'pdpa', 'privacy', 'compliance', 'consent'],
      answer: 'The free PDPA gap check reviews your privacy notice, Bahasa Malaysia and English coverage, consent wording, contact details, retention wording and basic data-handling gaps.',
      links: [['Start free gap check', '/#pdpa'], ['PDPA checklist', '/pdpa-checklist']]
    },
    {
      id: 'audit',
      keys: ['free it audit', 'it audit', 'infrastructure', 'backups', 'security audit', 'automation opportunities'],
      answer: 'The free IT audit is a short discovery process covering infrastructure, security, backups, software workflows and automation opportunities. You can use the scorecard as a paper worksheet, then submit the contact gate to unlock its printable report and request a written next step.',
      links: [['Open free audit', '/#audit'], ['Open scorecard', '/audit-scorecard']]
    },
    {
      id: 'calculator',
      keys: ['hours', 'lose', 'week', 'repetitive', 'calculator'],
      answer: '“Hours each loses per week” means the average number of working hours one selected staff member spends on repetitive, avoidable work every week — for example copying data, preparing the same report, chasing approvals or re-keying invoices. It is not total hours worked and it is not a productivity judgment.',
      links: [['See the calculator', '/#calculator'], ['Request free audit', '/#audit']]
    },
    {
      id: 'pricing',
      keys: ['price', 'pricing', 'cost', 'automation'],
      answer: 'Managed IT retainers start from RM 2,500/month. AI software and automation projects start from RM 2,500. The free audit comes first so a proposal reflects your actual scope rather than an invented package.',
      links: [['View pricing', '/#pricing'], ['Start free audit', '/#audit']]
    }
  ];

  var fallback = {
    id: 'fallback',
    answer: 'I can help with the free PDPA gap check, free IT audit, audit scorecard, pricing, or the “hours each loses per week” calculator. Try one of those topics, or speak with the team through the audit form.',
    links: [['Free IT audit', '/#audit']]
  };

  var bmAnswers = {
    scorecard: {
      answer: 'Panduan scorecard: ini ialah penilaian kendiri manual yang boleh dicetak — bukan kalkulator interaktif. Isi butiran tajuk, tandakan satu tahap bagi setiap 25 baris (0 Tiada, 1 Ad hoc, 2 Sebahagian, 3 Ya atau 4 Terbukti), jumlahkan lima jawapan setiap bahagian (maksimum 20 mata), kemudian jumlahkan lima bahagian daripada 100. Gunakan band 80–100 Kukuh, 60–79 Sederhana, 40–59 Berisiko dan 0–39 Kritikal. Biarkan perkara yang tidak diketahui kosong dan jadikan ia agenda audit anda.',
      links: [['Buka scorecard', '/audit-scorecard'], ['Baca panduan', '/audit-guide']]
    },
    gap: {
      answer: 'Semakan jurang PDPA percuma menilai notis privasi anda, liputan Bahasa Malaysia dan Inggeris, kata-kata keizinan, butiran hubungan, tempoh penyimpanan dan jurang pengendalian data asas.',
      links: [['Mulakan semakan jurang', '/#pdpa'], ['Senarai semak PDPA', '/pdpa-checklist']]
    },
    audit: {
      answer: 'Audit IT percuma ialah proses penemuan ringkas yang meliputi infrastruktur, keselamatan, sandaran, aliran kerja perisian dan peluang automasi. Gunakan scorecard sebagai lembaran kerja, kemudian hantar borang hubungan untuk membuka laporan boleh cetak dan meminta langkah seterusnya secara bertulis.',
      links: [['Buka audit percuma', '/#audit'], ['Buka scorecard', '/audit-scorecard']]
    },
    calculator: {
      answer: '“Jam yang hilang setiap minggu” bermaksud purata jam bekerja seorang kakitangan terpilih yang digunakan untuk kerja berulang dan boleh dielakkan setiap minggu — contohnya menyalin data, menyediakan laporan sama, mengejar kelulusan atau memasukkan invois semula. Ia bukan jumlah jam bekerja dan bukan penilaian prestasi.',
      links: [['Lihat kalkulator', '/#calculator'], ['Minta audit percuma', '/#audit']]
    },
    pricing: {
      answer: 'IT terurus bermula daripada RM 2,500 sebulan. Projek perisian AI dan automasi bermula daripada RM 2,500. Audit percuma dibuat dahulu supaya cadangan berdasarkan skop sebenar, bukan pakej yang direka-reka.',
      links: [['Lihat harga', '/#pricing'], ['Mulakan audit percuma', '/#audit']]
    },
    fallback: {
      answer: 'Saya boleh membantu tentang semakan jurang PDPA percuma, audit IT percuma, scorecard audit, harga atau kalkulator “jam yang hilang setiap minggu”. Cuba salah satu topik ini atau hubungi pasukan melalui borang audit.',
      links: [['Audit IT percuma', '/#audit']]
    }
  };

  function normalize(value) {
    return String(value || '').slice(0, MAX_QUESTION_LENGTH).toLowerCase().replace(/[^a-z0-9 ]/g, ' ');
  }

  function answerFor(question) {
    var text = normalize(question);
    var best = null;
    var bestScore = 0;

    answers.forEach(function (item) {
      var hits = item.keys.reduce(function (count, key) {
        return count + (text.indexOf(key) >= 0 ? 1 : 0);
      }, 0);

      // Any scorecard mention should resolve to the manual worksheet guide. This
      // avoids the generic audit answer winning on questions such as “audit scorecard”.
      if (item.id === 'scorecard' && text.indexOf('scorecard') >= 0) hits += 3;
      if (hits > bestScore) {
        bestScore = hits;
        best = item;
      }
    });

    return best || fallback;
  }

  if (commonJs && commonJs.exports) {
    commonJs.exports = answerFor;
  }

  // The helper is also safe to load in Node for pure answer tests.
  if (!global || !global.document) return;

  var document = global.document;
  var root = document.getElementById('ask-ai');
  if (!root) return;

  var panel = root.querySelector('[data-ask-panel]');
  var toggle = root.querySelector('[data-ask-toggle]');
  var close = root.querySelector('[data-ask-close]');
  var form = root.querySelector('[data-ask-form]');
  var input = root.querySelector('[data-ask-input]');
  var messages = root.querySelector('[data-ask-messages]');
  var suggestions = root.querySelector('[data-ask-suggestions]');
  var languageGate = root.querySelector('[data-ask-language]');
  var languageOptions = root.querySelectorAll('[data-ask-language-option]');
  var content = root.querySelector('[data-ask-content]');
  var disclosure = root.querySelector('[data-ask-disclosure]');
  var welcome = root.querySelector('[data-ask-welcome]');
  var inputLabel = root.querySelector('[data-ask-input-label]');
  var submit = root.querySelector('[data-ask-submit]');
  if (!panel || !toggle || !close || !form || !input || !messages || !suggestions || !languageGate || !content || !languageOptions.length) return;

  var open = !panel.hidden;
  var opener = toggle;
  var selectedLanguage = null;
  var languageCopy = {
    en: {
      disclosure: 'A fast website guide using published Duta Integra information. No personal data is required and no live infrastructure action is possible here.',
      welcome: 'Hi. Ask me about the gap check, free IT audit, scorecard, pricing, or the hours calculator.',
      inputLabel: 'Ask a question',
      placeholder: 'Ask about the audit…',
      submit: 'Ask',
      suggestions: ['Scorecard guide', 'Gap check', 'Explain hours']
    },
    bm: {
      disclosure: 'Panduan laman web ringkas menggunakan maklumat Duta Integra yang diterbitkan. Data peribadi tidak diperlukan dan tiada tindakan infrastruktur langsung boleh dilakukan di sini.',
      welcome: 'Hai. Tanya saya tentang semakan jurang, audit IT percuma, scorecard, harga atau kalkulator jam yang hilang.',
      inputLabel: 'Tanya soalan',
      placeholder: 'Tanya tentang audit…',
      submit: 'Tanya',
      suggestions: ['Panduan scorecard', 'Semakan jurang', 'Terangkan jam']
    }
  };
  var focusableSelector = 'button:not([disabled]), input:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])';
  input.maxLength = MAX_QUESTION_LENGTH;
  if (!panel.id) panel.id = 'ask-ai-panel';
  toggle.setAttribute('aria-controls', panel.id);

  function localizedResult(result) {
    if (selectedLanguage !== 'bm') return result;
    var translated = bmAnswers[result.id || 'fallback'] || bmAnswers.fallback;
    return { answer: translated.answer, links: translated.links };
  }

  function setLanguage(language) {
    selectedLanguage = language === 'bm' ? 'bm' : 'en';
    var copy = languageCopy[selectedLanguage];
    languageGate.hidden = true;
    content.hidden = false;
    input.disabled = false;
    if (submit) submit.disabled = false;
    if (disclosure) disclosure.textContent = copy.disclosure;
    if (welcome) welcome.textContent = copy.welcome;
    if (inputLabel) inputLabel.textContent = copy.inputLabel;
    input.placeholder = copy.placeholder;
    if (submit) submit.textContent = copy.submit;
    Array.prototype.forEach.call(suggestions.querySelectorAll('button[data-question]'), function (button, index) {
      if (copy.suggestions[index]) button.textContent = copy.suggestions[index];
      button.setAttribute('data-active-question', selectedLanguage === 'bm'
        ? button.getAttribute('data-question-bm')
        : button.getAttribute('data-question'));
    });
    Array.prototype.forEach.call(languageOptions, function (button) {
      button.setAttribute('aria-pressed', String(button.getAttribute('data-ask-language-option') === selectedLanguage));
    });
    input.focus();
  }

  function focusOpener() {
    if (opener && typeof opener.focus === 'function') opener.focus();
    else toggle.focus();
  }

  function setOpen(next) {
    open = Boolean(next);
    panel.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    if (open) {
      opener = document.activeElement && document.activeElement !== document.body ? document.activeElement : toggle;
      if (selectedLanguage) input.focus();
      else languageOptions[0].focus();
    } else {
      focusOpener();
    }
  }

  function addMessage(text, type, links) {
    var item = document.createElement('div');
    var paragraph = document.createElement('p');
    item.className = 'ask-message ask-' + type;
    paragraph.textContent = String(text);
    item.appendChild(paragraph);
    (links || []).forEach(function (link) {
      var anchor = document.createElement('a');
      anchor.href = link[1];
      anchor.textContent = link[0];
      item.appendChild(anchor);
    });
    messages.appendChild(item);
    while (messages.children.length > MAX_MESSAGES) messages.removeChild(messages.firstElementChild);
    messages.scrollTop = messages.scrollHeight;
  }

  function ask(question) {
    if (!selectedLanguage) return;
    var value = String(question || '').trim().slice(0, MAX_QUESTION_LENGTH);
    if (!value) return;
    addMessage(value, 'user');
    var result = answerFor(value);
    var localized = localizedResult(result);
    addMessage(localized.answer, 'assistant', localized.links);
  }

  toggle.addEventListener('click', function () { setOpen(!open); });
  close.addEventListener('click', function () { setOpen(false); });
  Array.prototype.forEach.call(languageOptions, function (button) {
    button.setAttribute('aria-pressed', 'false');
    button.addEventListener('click', function () { setLanguage(button.getAttribute('data-ask-language-option')); });
  });
  panel.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      return;
    }
    if (event.key === 'Tab') {
      var focusable = Array.prototype.slice.call(panel.querySelectorAll(focusableSelector))
        .filter(function (element) { return element.offsetParent !== null; });
      if (!focusable.length) return;
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    ask(input.value);
    input.value = '';
  });
  suggestions.addEventListener('click', function (event) {
    var button = event.target.closest('button[data-question]');
    if (button) ask(button.getAttribute('data-active-question') || button.getAttribute('data-question'));
  });
}(typeof window !== 'undefined' ? window : null, typeof module !== 'undefined' ? module : null));
