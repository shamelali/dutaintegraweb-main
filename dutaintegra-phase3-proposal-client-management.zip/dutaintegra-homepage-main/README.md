# Duta Integra workspace

This workspace has two source boundaries:

- **`dutaintegra-homepage/`** is the canonical, independently versioned website
  repository. Cloudflare Pages publishes its `public/` directory and its
  root `functions/` directory. Run website Git commands from that directory.
  The workspace ignores it to prevent accidental nested-repository commits.
- **`agent-backbone/`** belongs to this workspace repository. It is an isolated,
  mock-only Python service; it is not part of the Pages deployment.

Local `uploads/`, `.pki/`, dependencies, caches, and credentials are ignored.
The homepage repository also contains internal business and delivery documents;
its source visibility must remain private unless those files are separated.

## Website development

From this workspace, `npm test` runs the homepage's dependency-free checks.
`npm run preview` starts the static preview at `http://127.0.0.1:8080`.
The preview deliberately returns 503 for form submissions (no mail is sent).

The dependency-free website suite is `npm test` **inside
`dutaintegra-homepage/`**. Browser smoke tests require Playwright and a
Chromium executable in the local environment; see `tools/routes.js` and
`tools/a11y.js` for the current checks. See the homepage repository's
`DEPLOY.md` for Pages Functions, bindings, and release checks.

## Python development

Use Python 3.12+ and recreate the environment rather than copying a `.venv`
between machines. From `agent-backbone/`:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python -m pytest -q
.venv/bin/ruff check .
.venv/bin/python -m pip check
```

The workspace CI verifies the Python service; website CI lives in the website
repository. No production infrastructure or deployment is managed by the demo.

## Phase 3 — Proposal & Client Management

Phase 3 adds a private `/workspace` interface, a D1 schema migration, and Cloudflare Access-protected API routes for leads, proposals, and projects. See [`docs/PHASE-3-PROPOSAL-CLIENT-MANAGEMENT.md`](docs/PHASE-3-PROPOSAL-CLIENT-MANAGEMENT.md) before deploying. **The workspace is not live until Cloudflare Access, D1, environment variables, and named users are configured and verified in staging.**
