const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function decodeBase64Url(value) {
  const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
  const raw = atob(padded);
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}
function decodePart(value) {
  return JSON.parse(new TextDecoder().decode(decodeBase64Url(value)));
}
function readTlv(bytes, offset) {
  const tag = bytes[offset];
  let p = offset + 1;
  let len = bytes[p++];
  if (len & 0x80) {
    const count = len & 0x7f;
    len = 0;
    for (let i = 0; i < count; i++) len = len * 256 + bytes[p++];
  }
  return { tag, start: offset, content: p, end: p + len, length: len };
}
function spkiFromCertificate(certPem) {
  const base64 = certPem.replace(/-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\s/g, '');
  const der = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  const outer = readTlv(der, 0);
  const tbs = readTlv(der, outer.content);
  let cursor = tbs.content;
  let field = readTlv(der, cursor);
  if (field.tag === 0xa0) { cursor = field.end; field = readTlv(der, cursor); }
  // serial, signature, issuer, validity, subject, SubjectPublicKeyInfo
  for (let i = 0; i < 5; i++) { cursor = field.end; field = readTlv(der, cursor); }
  return der.slice(field.start, field.end);
}
async function verifyAccessJwt(token, env) {
  if (!env.CF_ACCESS_TEAM_DOMAIN || !env.CF_ACCESS_AUD) throw new Error('Cloudflare Access is not configured');
  const team = String(env.CF_ACCESS_TEAM_DOMAIN).replace(/^https?:\/\//, '').replace(/\/$/, '');
  const issuer = `https://${team}`;
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('Invalid access token');
  const header = decodePart(parts[0]);
  const payload = decodePart(parts[1]);
  if (header.alg !== 'RS256' || !header.kid) throw new Error('Unsupported access token');
  const now = Math.floor(Date.now() / 1000);
  if (payload.iss !== issuer || !Array.isArray(payload.aud) || !payload.aud.includes(env.CF_ACCESS_AUD) || !payload.exp || payload.exp <= now || (payload.nbf && payload.nbf > now)) throw new Error('Access token claims rejected');
  const certResponse = await fetch(`${issuer}/cdn-cgi/access/certs`, { headers: { Accept: 'application/json' } });
  if (!certResponse.ok) throw new Error('Unable to verify access token');
  const certs = await certResponse.json();
  const cert = (certs.public_certs || []).find((item) => item.kid === header.kid);
  if (!cert || !cert.cert) throw new Error('Unknown access signing key');
  const key = await crypto.subtle.importKey('spki', spkiFromCertificate(cert.cert), { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const signature = decodeBase64Url(parts[2]);
  const signed = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  if (!await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, signature, signed)) throw new Error('Access token signature rejected');
  const email = String(payload.email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) throw new Error('Access token has no valid email');
  return { email, subject: String(payload.sub || ''), aud: payload.aud };
}
export async function requireWorkspaceUser(request, env) {
  const token = request.headers.get('cf-access-jwt-assertion');
  if (!token) return { response: jsonError('Authentication required', 401) };
  let identity;
  try { identity = await verifyAccessJwt(token, env); }
  catch (error) {
    console.error('[workspace-auth] Access verification failed:', error.message);
    return { response: jsonError('Authentication could not be verified', 401) };
  }
  if (!env.DB) return { response: jsonError('Workspace database is not configured', 503) };
  const user = await env.DB.prepare('SELECT email, display_name, role, organization_id, active FROM workspace_users WHERE email = ? COLLATE NOCASE').bind(identity.email).first();
  if (!user || !user.active) return { response: jsonError('Workspace access has not been provisioned', 403) };
  return { user };
}
export function jsonError(message, status = 400) {
  return new Response(JSON.stringify({ error: message }), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
}
export function jsonOk(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
}
export function text(value, max) { return String(value == null ? '' : value).trim().slice(0, max); }
export function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }
export async function audit(env, user, action, recordType, recordId, metadata = {}) {
  await env.DB.prepare('INSERT INTO workspace_audit_log (id, actor_email, action, record_type, record_id, metadata_json) VALUES (?, ?, ?, ?, ?, ?)')
    .bind(id('evt'), user.email, action, recordType, recordId, JSON.stringify(metadata)).run();
}
