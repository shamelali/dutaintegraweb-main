/**
 * POST /api/send-email — Cloudflare Pages Function.
 *
 * Contract (matches the lead form in index.html):
 *   Request:  JSON { name, email, company?, phone?, service, message,
 *                     consent: true, source?, page? }
 *   Success:  200 { ok: true }
 *   Failures: 400 validation, 403 origin, 405 non-POST, 413 oversized body,
 *             429 rate limited, 502 mail rejected, 503 mail not configured.
 *             The form treats any non-2xx as
 *             "fall back to WhatsApp", so no lead is ever silently lost.
 *
 * Env vars (Pages → Settings → Environment variables):
 *   BREVO_API_KEY   secret, required — Brevo transactional API key (xkeysib-…)
 *   EMAIL_TO        required — where enquiries go (e.g. support@dutaintegra.my)
 *   EMAIL_FROM      optional — verified sender, default no-reply@dutaintegra.my
 *                             (covered by the Brevo domain verification)
 *   ALLOWED_ORIGINS required — comma list, e.g.
 *                     https://dutaintegra.my,https://www.dutaintegra.my
 * KV binding (recommended): LEADS — JSON copy of every accepted
 * enquiry is stored BEFORE the mail call, so a provider outage never loses
 * a lead. Without the binding the mail still sends; nothing blocks.
 */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MAX_BODY_BYTES = 16 * 1024;
const MAX_LENGTHS = Object.freeze({
  name: 120,
  email: 254,
  company: 200,
  phone: 40,
  service: 160,
  message: 5000,
  source: 120,
  page: 2048,
});

let corsOrigin = ""; // set after origin validation; echoed back to the browser

function json(data, status, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      ...(corsOrigin ? { "Access-Control-Allow-Origin": corsOrigin } : {}),
      ...extraHeaders,
    },
  });
}

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function validateText(value, label, limit, required = false) {
  if (value == null) return required ? `${label} is required` : null;
  if (typeof value !== "string") return `${label} is invalid`;
  if (value.length > limit) return `${label} is too long`;
  if (required && !value.trim()) return `${label} is required`;
  return null;
}

function validate(b) {
  if (!b || typeof b !== "object") return "Invalid payload";
  for (const [field, label, required] of [
    ["name", "Name", true],
    ["email", "Email", true],
    ["company", "Company", false],
    ["phone", "Phone", false],
    ["service", "Service", true],
    ["message", "Message", true],
    ["source", "Source", false],
    ["page", "Page", false],
  ]) {
    const problem = validateText(b[field], label, MAX_LENGTHS[field], required);
    if (problem) return problem;
  }
  if (!EMAIL_RE.test(b.email.trim())) return "Valid email is required";
  if (b.consent !== true) return "PDPA consent is required";
  return null;
}

// Rate-limit constants (10 req/min per IP, 10-min block on exceed)
const RATE_LIMIT = 10;
const WINDOW_MS = 60_000;
const BLOCK_MS = 600_000;

export async function onRequest(context) {
  const { request, env } = context;

  /* CORS preflight for AGMX (agmx.dutaintegra.my) and same-origin browsers. */
  if (request.method === "OPTIONS") {
    const origin = request.headers.get("Origin") || "";
    const allowed = String(env.ALLOWED_ORIGINS || "")
      .split(",").map((s) => s.trim()).filter(Boolean);
    const corsHeaders = {
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Cache-Control": "no-store",
    };
    if (allowed.includes(origin)) {
      corsHeaders["Access-Control-Allow-Origin"] = origin;
    }
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }

  const allowed = String(env.ALLOWED_ORIGINS || "")
    .split(",").map((s) => s.trim()).filter(Boolean);
  const origin = request.headers.get("Origin") || "";
  // This is a browser-facing public endpoint. An empty allowlist must fail
  // closed rather than silently disabling the origin boundary.
  if (!allowed.length || !origin || !allowed.includes(origin)) {
    return json({ error: "Forbidden origin" }, 403);
  }
  corsOrigin = origin;

  const contentLength = Number(request.headers.get("Content-Length") || 0);
  if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
    return json({ error: "Request body too large" }, 413);
  }

  // ---- rate limit: 10 req/min per IP, 10-min block on exceed ----
  const ip = request.headers.get("cf-connecting-ip") || "unknown";
  const now = Date.now();
  const rlKey = "rl:" + ip;

  try {
    const existing = await env.LEADS?.get?.(rlKey, "json");
    if (existing) {
      const { count, windowStart, blockedUntil } = existing;
      if (blockedUntil && now < blockedUntil) {
        return json({ error: "Too many requests" }, 429, { "Retry-After": "600" });
      }
      if (now - windowStart < WINDOW_MS) {
        if (count >= RATE_LIMIT) {
          await env.LEADS.put(rlKey, JSON.stringify({ count, windowStart, blockedUntil: now + BLOCK_MS }), { expirationTtl: 600 });
          return json({ error: "Too many requests" }, 429, { "Retry-After": "600" });
        }
        await env.LEADS.put(rlKey, JSON.stringify({ count: count + 1, windowStart, blockedUntil: null }), { expirationTtl: 60 });
      } else {
        // window expired, reset
        await env.LEADS.put(rlKey, JSON.stringify({ count: 1, windowStart: now, blockedUntil: null }), { expirationTtl: 60 });
      }
    } else {
      await env.LEADS.put(rlKey, JSON.stringify({ count: 1, windowStart: now, blockedUntil: null }), { expirationTtl: 60 });
    }
  } catch {
    // KV hiccup → fail open (never block legitimate traffic on KV failure)
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }

  // Content-Length can be absent for chunked requests. Check the parsed
  // representation as a second guard before validating or forwarding it.
  if (new TextEncoder().encode(JSON.stringify(body)).byteLength > MAX_BODY_BYTES) {
    return json({ error: "Request body too large" }, 413);
  }

  const problem = validate(body);
  if (problem) return json({ error: problem }, 400);

  if (!env.BREVO_API_KEY) {
    return json({ error: "Mail not configured" }, 503);
  }

  const to = env.EMAIL_TO || "support@dutaintegra.my";
  const from = env.EMAIL_FROM || "no-reply@dutaintegra.my";
  const receivedAt = new Date().toISOString();
  const lead = {
    name: String(body.name).trim(),
    email: String(body.email).trim(),
    company: String(body.company || "").trim(),
    phone: String(body.phone || "").trim(),
    service: String(body.service).trim(),
    message: String(body.message).trim(),
    consent: true,
    source: String(body.source || "direct"),
    page: String(body.page || ""),
    receivedAt,
  };

  // Store BEFORE sending — a mail outage must never lose the lead.
  try {
    if (env.LEADS && typeof env.LEADS.put === "function") {
      const key = "lead:" + Date.now() + ":" +
        Math.random().toString(36).slice(2, 10);
      await env.LEADS.put(key, JSON.stringify(lead), { expirationTtl: 31536000 });
    }
  } catch {
    // KV failure is logged by the platform; the enquiry still sends.
  }

  const subject = "[dutaintegra.my] New enquiry — " + lead.service + " — " + lead.name;
  const text =
    "New enquiry from " + lead.page + "\n\n" +
    "Name: " + lead.name + "\n" +
    "Email: " + lead.email + "\n" +
    (lead.company ? "Company: " + lead.company + "\n" : "") +
    (lead.phone ? "Phone: " + lead.phone + "\n" : "") +
    "Service: " + lead.service + "\n" +
    "Source: " + lead.source + "\n" +
    "PDPA consent: yes (" + receivedAt + ")\n\n" +
    lead.message;
  const html =
    "<p>New enquiry from " + esc(lead.page) + "</p>" +
    "<ul><li><b>Name:</b> " + esc(lead.name) + "</li>" +
    "<li><b>Email:</b> " + esc(lead.email) + "</li>" +
    (lead.company ? "<li><b>Company:</b> " + esc(lead.company) + "</li>" : "") +
    (lead.phone ? "<li><b>Phone:</b> " + esc(lead.phone) + "</li>" : "") +
    "<li><b>Service:</b> " + esc(lead.service) + "</li>" +
    "<li><b>Source:</b> " + esc(lead.source) + "</li>" +
    "<li><b>PDPA consent:</b> yes (" + esc(receivedAt) + ")</li></ul>" +
    "<pre>" + esc(lead.message) + "</pre>";

  let res;
  try {
    res = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": env.BREVO_API_KEY,
      },
      body: JSON.stringify({
        sender: { email: from, name: "Duta Integra Website" },
        to: [{ email: to }],
        replyTo: { email: lead.email, name: lead.name },
        subject,
        textContent: text,
        htmlContent: html,
      }),
    });
  } catch (err) {
    // Never log env: the key is in scope here.
    console.error("[send-email] provider unreachable:", err && err.message ? err.message : String(err));
    return json({ error: "Mail provider unreachable" }, 502);
  }
  if (!res.ok) {
    // Brevo distinguishes "sender not verified", "account/auth" and
    // "out of credits". Without the body a 502 is undiagnosable from
    // Cloudflare logs, so record it. The body never contains the API key.
    const detail = await res.text().catch(() => "");
    console.error("[send-email] provider rejected", res.status,
      "sender=" + from, "to=" + to, "provider_body=" + detail.slice(0, 500));
    return json({ error: "Mail provider rejected the message" }, 502);
  }
  console.log("[send-email] accepted lead:", lead.service,
    "receivedAt=" + receivedAt, "kv_stored=" + Boolean(env.LEADS));
  return json({ ok: true }, 200);
}
