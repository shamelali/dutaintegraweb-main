import { requireWorkspaceUser, jsonError, jsonOk, text, id, audit } from '../../_lib/workspace-auth.js';

const MAX_BODY = 12 * 1024;
const STAFF = new Set(['admin', 'staff']);
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const LEAD_STATUSES = new Set(['new', 'qualified', 'proposal', 'won', 'lost']);
const PROPOSAL_STATUSES = new Set(['draft', 'sent', 'accepted', 'declined', 'expired']);
const PROJECT_STATUSES = new Set(['planned', 'in_progress', 'blocked', 'completed', 'cancelled']);

async function bodyJson(request) {
  const length = Number(request.headers.get('content-length') || 0);
  if (length > MAX_BODY) return { error: jsonError('Request body too large', 413) };
  try {
    const value = await request.json();
    if (!value || typeof value !== 'object' || Array.isArray(value) || new TextEncoder().encode(JSON.stringify(value)).byteLength > MAX_BODY) return { error: jsonError('Invalid or oversized request body', 400) };
    return { value };
  } catch { return { error: jsonError('Invalid JSON body', 400) }; }
}
function staffOnly(user) { return STAFF.has(user.role); }
function validDate(value) { return !value || /^\d{4}-\d{2}-\d{2}$/.test(value); }
async function workspace(request, env, user) {
  const isStaff = staffOnly(user);
  const proposalsQuery = isStaff
    ? env.DB.prepare(`SELECT p.*, l.company AS lead_company FROM proposals p LEFT JOIN leads l ON l.id=p.lead_id ORDER BY p.created_at DESC LIMIT 100`)
    : env.DB.prepare(`SELECT p.*, o.name AS lead_company FROM proposals p LEFT JOIN organizations o ON o.id=p.organization_id WHERE p.organization_id=? ORDER BY p.created_at DESC LIMIT 100`).bind(user.organization_id);
  const projectsQuery = isStaff
    ? env.DB.prepare(`SELECT p.*, o.name AS organization_name FROM projects p JOIN organizations o ON o.id=p.organization_id ORDER BY p.created_at DESC LIMIT 100`)
    : env.DB.prepare(`SELECT p.*, o.name AS organization_name FROM projects p JOIN organizations o ON o.id=p.organization_id WHERE p.organization_id=? ORDER BY p.created_at DESC LIMIT 100`).bind(user.organization_id);
  const [proposals, projects, leads] = await Promise.all([
    proposalsQuery.all(), projectsQuery.all(),
    isStaff ? env.DB.prepare('SELECT * FROM leads ORDER BY created_at DESC LIMIT 100').all() : Promise.resolve({ results: [] }),
  ]);
  return jsonOk({ user: { email: user.email, displayName: user.display_name, role: user.role, organizationId: user.organization_id }, summary: { leads: leads.results.length, proposals: proposals.results.length, projects: projects.results.length, openProposals: proposals.results.filter((p) => ['draft','sent'].includes(p.status)).length, activeProjects: projects.results.filter((p) => ['planned','in_progress','blocked'].includes(p.status)).length }, leads: leads.results, proposals: proposals.results, projects: projects.results });
}
async function createLead(request, env, user) {
  if (!staffOnly(user)) return jsonError('Staff access required', 403);
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  const company = text(b.company, 180), contactName = text(b.contactName, 120), email = text(b.email, 254);
  if (!company || !contactName || !EMAIL_RE.test(email)) return jsonError('Company, contact name and valid email are required');
  const leadId = id('lead');
  await env.DB.prepare('INSERT INTO leads (id, company, contact_name, email, service_interest, source, status, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(leadId, company, contactName, email.toLowerCase(), text(b.serviceInterest, 160) || 'Digital assessment', text(b.source, 120) || 'Manual entry', LEAD_STATUSES.has(b.status) ? b.status : 'new', text(b.notes, 3000), user.email).run();
  await audit(env, user, 'created', 'lead', leadId, { company });
  return jsonOk({ ok: true, id: leadId }, 201);
}
async function updateLead(request, env, user, recordId) {
  if (!staffOnly(user)) return jsonError('Staff access required', 403);
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  const lead = await env.DB.prepare('SELECT id FROM leads WHERE id=?').bind(recordId).first();
  if (!lead) return jsonError('Lead not found', 404);
  if (b.status !== undefined && !LEAD_STATUSES.has(b.status)) return jsonError('Invalid lead status');
  await env.DB.prepare('UPDATE leads SET status=COALESCE(?,status), notes=COALESCE(?,notes), updated_at=datetime(\'now\') WHERE id=?')
    .bind(b.status === undefined ? null : b.status, b.notes === undefined ? null : text(b.notes, 3000), recordId).run();
  await audit(env, user, 'updated', 'lead', recordId, { status: b.status || null });
  return jsonOk({ ok: true });
}
async function createProposal(request, env, user) {
  if (!staffOnly(user)) return jsonError('Staff access required', 403);
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  const title = text(b.title, 180), summary = text(b.summary, 5000);
  const amount = Number(b.amount);
  if (!title || !Number.isFinite(amount) || amount < 0 || amount > 100000000) return jsonError('A title and valid non-negative MYR amount are required');
  if (!validDate(b.validUntil)) return jsonError('Use YYYY-MM-DD for the validity date');
  let leadId = text(b.leadId, 100) || null;
  if (leadId && !await env.DB.prepare('SELECT id FROM leads WHERE id=?').bind(leadId).first()) return jsonError('Lead not found', 404);
  const organizationId = text(b.organizationId, 100) || null;
  if (organizationId && !await env.DB.prepare('SELECT id FROM organizations WHERE id=?').bind(organizationId).first()) return jsonError('Organisation not found', 404);
  const proposalId = id('prop');
  await env.DB.prepare('INSERT INTO proposals (id, lead_id, organization_id, title, summary, amount_cents, status, valid_until, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(proposalId, leadId, organizationId, title, summary, Math.round(amount * 100), b.status === 'sent' ? 'sent' : 'draft', b.validUntil || null, user.email).run();
  await audit(env, user, 'created', 'proposal', proposalId, { amountCents: Math.round(amount * 100), status: b.status === 'sent' ? 'sent' : 'draft' });
  return jsonOk({ ok: true, id: proposalId, status: b.status === 'sent' ? 'sent' : 'draft' }, 201);
}
async function updateProposal(request, env, user, recordId) {
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  const proposal = await env.DB.prepare('SELECT * FROM proposals WHERE id=?').bind(recordId).first();
  if (!proposal) return jsonError('Proposal not found', 404);
  const isStaff = staffOnly(user);
  if (!isStaff && (!user.organization_id || proposal.organization_id !== user.organization_id)) return jsonError('Proposal not found', 404);
  const status = text(b.status, 20);
  if (!PROPOSAL_STATUSES.has(status)) return jsonError('Invalid proposal status');
  if (isStaff) {
    await env.DB.prepare('UPDATE proposals SET status=?, updated_at=datetime(\'now\') WHERE id=?').bind(status, recordId).run();
  } else {
    if (proposal.status !== 'sent' || !['accepted','declined'].includes(status)) return jsonError('Clients can accept or decline sent proposals only', 409);
    await env.DB.prepare('UPDATE proposals SET status=?, updated_at=datetime(\'now\') WHERE id=?').bind(status, recordId).run();
  }
  await audit(env, user, 'status_changed', 'proposal', recordId, { status });
  return jsonOk({ ok: true, status });
}
async function createProject(request, env, user) {
  if (!staffOnly(user)) return jsonError('Staff access required', 403);
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  const organizationId = text(b.organizationId, 100), name = text(b.name, 180), nextAction = text(b.nextAction, 1000);
  if (!organizationId || !name) return jsonError('Organisation and project name are required');
  if (!await env.DB.prepare('SELECT id FROM organizations WHERE id=?').bind(organizationId).first()) return jsonError('Organisation not found', 404);
  if (b.targetDate && !validDate(b.targetDate)) return jsonError('Use YYYY-MM-DD for target date');
  const projectId = id('proj');
  await env.DB.prepare('INSERT INTO projects (id, proposal_id, organization_id, name, status, next_action, target_date, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(projectId, text(b.proposalId, 100) || null, organizationId, name, PROJECT_STATUSES.has(b.status) ? b.status : 'planned', nextAction, b.targetDate || null, user.email).run();
  await audit(env, user, 'created', 'project', projectId, { organizationId });
  return jsonOk({ ok: true, id: projectId }, 201);
}
async function updateProject(request, env, user, recordId) {
  if (!staffOnly(user)) return jsonError('Staff access required', 403);
  const parsed = await bodyJson(request); if (parsed.error) return parsed.error;
  const b = parsed.value;
  if (b.status !== undefined && !PROJECT_STATUSES.has(b.status)) return jsonError('Invalid project status');
  const project = await env.DB.prepare('SELECT id FROM projects WHERE id=?').bind(recordId).first();
  if (!project) return jsonError('Project not found', 404);
  await env.DB.prepare('UPDATE projects SET status=COALESCE(?,status), next_action=COALESCE(?,next_action), target_date=COALESCE(?,target_date), updated_at=datetime(\'now\') WHERE id=?')
    .bind(b.status === undefined ? null : b.status, b.nextAction === undefined ? null : text(b.nextAction, 1000), b.targetDate === undefined ? null : (validDate(b.targetDate) ? b.targetDate : null), recordId).run();
  await audit(env, user, 'updated', 'project', recordId, { status: b.status || null });
  return jsonOk({ ok: true });
}
export async function onRequest(context) {
  const { request, env, params } = context;
  if (!env.DB) return jsonError('Workspace database is not configured', 503);
  const auth = await requireWorkspaceUser(request, env);
  if (auth.response) return auth.response;
  const user = auth.user;
  const path = Array.isArray(params.path) ? params.path : params.path ? [params.path] : [];
  const resource = path[0] || '';
  const recordId = path[1] || '';
  if (path.length > 2) return jsonError('Not found', 404);
  try {
    if (!resource && request.method === 'GET') return await workspace(request, env, user);
    if (resource === 'leads' && request.method === 'GET') {
      if (!staffOnly(user)) return jsonError('Staff access required', 403);
      const rows = await env.DB.prepare('SELECT * FROM leads ORDER BY created_at DESC LIMIT 100').all(); return jsonOk({ leads: rows.results });
    }
    if (resource === 'leads' && !recordId && request.method === 'POST') return await createLead(request, env, user);
    if (resource === 'leads' && recordId && request.method === 'PATCH') return await updateLead(request, env, user, recordId);
    if (resource === 'proposals' && request.method === 'GET') {
      const rows = staffOnly(user)
        ? await env.DB.prepare('SELECT * FROM proposals ORDER BY created_at DESC LIMIT 100').all()
        : await env.DB.prepare('SELECT * FROM proposals WHERE organization_id=? ORDER BY created_at DESC LIMIT 100').bind(user.organization_id).all();
      return jsonOk({ proposals: rows.results });
    }
    if (resource === 'proposals' && !recordId && request.method === 'POST') return await createProposal(request, env, user);
    if (resource === 'proposals' && recordId && request.method === 'PATCH') return await updateProposal(request, env, user, recordId);
    if (resource === 'projects' && request.method === 'GET') {
      const rows = staffOnly(user)
        ? await env.DB.prepare('SELECT * FROM projects ORDER BY created_at DESC LIMIT 100').all()
        : await env.DB.prepare('SELECT * FROM projects WHERE organization_id=? ORDER BY created_at DESC LIMIT 100').bind(user.organization_id).all();
      return jsonOk({ projects: rows.results });
    }
    if (resource === 'projects' && !recordId && request.method === 'POST') return await createProject(request, env, user);
    if (resource === 'projects' && recordId && request.method === 'PATCH') return await updateProject(request, env, user, recordId);
    return jsonError('Not found or method not allowed', 404);
  } catch (error) {
    console.error('[workspace-api] Request failed:', error.message);
    return jsonError('Workspace request could not be completed', 500);
  }
}
