/**
 * POST /api/business-health-check
 *
 * Public-evidence business scan. The first pass is useful without an AI key:
 * it crawls a small set of same-site public pages and produces rule-based
 * findings. If AI_API_KEY, AI_BASE_URL and AI_MODEL are configured, the same
 * evidence is sent to an OpenAI-compatible model (including NVIDIA NIM) for a
 * structured recommendation. No pages, user answers or company data are
 * stored by this function.
 *
 * For OpenAI models, set AI_PROVIDER=openai to use the standard
 * `/chat/completions` endpoint. NVIDIA NIM models are OpenAI-compatible
 * for reasoning, but NIM itself is not a web search engine; NIM mode
 * therefore uses the supplied public website unless a separate search
 * connector is added.
 */

const MAX_BODY_BYTES = 16 * 1024;
const MAX_HTML_CHARS = 12000;
const MAX_PAGES = 6;
const MAX_REDIRECTS = 3;
const PAGE_PATHS = ["/", "/privacy", "/privacy-policy", "/terms", "/services", "/pricing", "/contact", "/about"];
const ALLOWED_SIGNALS = new Set(["sales-marketing", "manual-work", "pdpa", "it-security"]);
const RATE_LIMIT = 5;
const RATE_WINDOW_MS = 10 * 60 * 1000;

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...extraHeaders },
  });
}

function text(value, max) {
  return String(value == null ? "" : value).trim().slice(0, max);
}

function safeUrl(value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    if (url.username || url.password || url.port && !['80', '443'].includes(url.port)) return null;
    const host = url.hostname.toLowerCase();
    if (host === 'localhost' || host.endsWith('.local') || host === '::1' || host.includes(':')) return null;
    if (/^(127\.|10\.|192\.168\.|169\.254\.)/.test(host)) return null;
    const private172 = host.match(/^172\.(\d{1,3})\./);
    if (private172 && Number(private172[1]) >= 16 && Number(private172[1]) <= 31) return null;
    return url;
  } catch {
    return null;
  }
}

function cleanHtml(html) {
  return text(html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' '), MAX_HTML_CHARS);
}

function pageEvidence(url, html, status) {
  const title = text((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1], 240);
  const description = text((html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)["']/i) || [])[1], 500);
  const headings = [...html.matchAll(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/gi)]
    .map((match) => cleanHtml(match[1]).slice(0, 180)).filter(Boolean).slice(0, 12);
  const links = [...html.matchAll(/<a[^>]+href=["']([^"']+)["']/gi)]
    .map((match) => match[1]).filter((href) => /privacy|terms|contact|pricing|service|demo|book|quote|whatsapp|wa\.me/i.test(href)).slice(0, 20);
  const plain = cleanHtml(html);
  return { url: url.toString(), status, title, description, headings, links, text: plain };
}

async function fetchPage(url, origin, redirects = 0) {
  try {
    const response = await fetch(url, {
      headers: { Accept: 'text/html,application/xhtml+xml', 'User-Agent': 'DutaIntegra-HealthCheck/1.0' },
      redirect: 'manual',
      signal: AbortSignal.timeout(8000),
    });
    if (response.status >= 300 && response.status < 400) {
      if (redirects >= MAX_REDIRECTS) return null;
      const location = response.headers.get('Location');
      if (!location) return null;
      const next = safeUrl(new URL(location, url));
      if (!next || next.origin !== origin) return null;
      return fetchPage(next, origin, redirects + 1);
    }
    const resolved = safeUrl(response.url || url);
    if (!resolved || resolved.origin !== origin) return null;
    if (!response.ok) return null;
    const type = response.headers.get('content-type') || '';
    if (!type.includes('text/html') && !type.includes('application/xhtml+xml')) return null;
    const html = (await response.text()).slice(0, 160000);
    return pageEvidence(resolved, html, response.status);
  } catch {
    return null;
  }
}

async function crawl(website) {
  const root = safeUrl(website);
  if (!root) return { root: null, pages: [] };
  const urls = PAGE_PATHS.map((path) => new URL(path, root).toString()).slice(0, MAX_PAGES);
  const pages = (await Promise.all(urls.map((url) => fetchPage(url, root.origin)))).filter(Boolean);
  return { root: root.toString(), pages };
}

async function allowedRequest(request, env) {
  const allowed = String(env.ALLOWED_ORIGINS || '').split(',').map((value) => value.trim()).filter(Boolean);
  const origin = request.headers.get('Origin') || '';
  if (!allowed.length || !origin || !allowed.includes(origin)) return { allowed: false, rateLimited: false };
  if (!env.LEADS || typeof env.LEADS.get !== 'function' || typeof env.LEADS.put !== 'function') return { allowed: true, rateLimited: false };
  const ip = request.headers.get('cf-connecting-ip') || 'unknown';
  const key = 'health-rl:' + ip;
  const now = Date.now();
  try {
    const current = await env.LEADS.get(key, 'json');
    if (current && now - current.windowStart < RATE_WINDOW_MS) {
      if (current.count >= RATE_LIMIT) return { allowed: false, rateLimited: true };
      await env.LEADS.put(key, JSON.stringify({ count: current.count + 1, windowStart: current.windowStart }), { expirationTtl: 600 });
    } else {
      await env.LEADS.put(key, JSON.stringify({ count: 1, windowStart: now }), { expirationTtl: 600 });
    }
  } catch {
    // A KV outage must not turn a valid public scan into a hard failure.
  }
  return { allowed: true, rateLimited: false };
}

function deterministicReport(input, crawlResult) {
  const pages = crawlResult.pages;
  const allText = pages.map((page) => page.text + ' ' + page.title + ' ' + page.description).join(' ').toLowerCase();
  const hasPrivacy = /privacy|privasi|pdpa|personal data|data peribadi/.test(allText);
  const hasContact = pages.some((page) => /mailto:|wa\.me|whatsapp|contact|hubungi|telefon|phone/.test((page.links || []).join(' ').toLowerCase() + page.text.toLowerCase()));
  const hasPricing = /rm\s?\d|pricing|harga|price|harga/.test(allText);
  const hasLeadPath = /quote|book|audit|demo|enquir|hubungi|whatsapp|wa\.me/.test(allText);
  const requested = input.signals.length ? input.signals : ['sales-marketing', 'manual-work', 'pdpa', 'it-security'];
  const findings = [];
  if (requested.includes('sales-marketing')) findings.push({ title: 'Sales and marketing path', detail: hasLeadPath ? 'A contact or conversion path is visible; review whether enquiries are qualified, routed and followed up consistently.' : 'No clear conversion path was detected in the sampled public pages.' });
  if (requested.includes('manual-work')) findings.push({ title: 'Automation opportunity', detail: 'Public pages cannot prove internal manual work. Confirm the top recurring task, its weekly volume and the systems involved.' });
  if (requested.includes('pdpa')) findings.push({ title: 'PDPA and privacy visibility', detail: hasPrivacy ? 'Privacy or PDPA language was found in the sampled pages; verify bilingual coverage, consent evidence and retention periods.' : 'No obvious privacy or PDPA page was found in the sampled pages.' });
  if (requested.includes('it-security')) findings.push({ title: 'IT and security visibility', detail: 'Public pages cannot verify backups, MFA, patching or incident readiness. Confirm ownership, restore testing and current risks with the team.' });
  let recommended = 'AI Business Health Check → scoped discovery';
  if (requested.includes('pdpa') && !hasPrivacy) recommended = 'PDPA Starter Pack → begin with the free gap check';
  else if (requested.includes('sales-marketing') && !hasLeadPath) recommended = 'Sales & Marketing Automation → lead capture and follow-up workflow';
  else if (requested.includes('manual-work')) recommended = 'AI Software & Automation → map one repetitive workflow first';
  return {
    mode: 'public evidence',
    recommended_service: recommended,
    summary: input.language === 'bm'
      ? `Semakan awal untuk ${input.company}. Kami menyemak ${pages.length} halaman awam dan membezakan bukti yang dilihat daripada perkara yang perlu disahkan bersama pasukan anda.`
      : `Initial review for ${input.company}. We checked ${pages.length} public pages and separated visible evidence from questions that require confirmation with your team.`,
    findings,
    confirm_with_team: input.language === 'bm'
      ? ['Siapa memiliki susulan prospek dan berapa cepat balasan pertama dihantar?', 'Apakah proses manual yang paling kerap berulang setiap minggu?', 'Di manakah data pelanggan disimpan dan bagaimana keizinan direkodkan?', 'Bilakah sandaran dan pemulihan terakhir diuji?']
      : ['Who owns lead follow-up and how quickly is the first response sent?', 'Which manual process repeats most often each week?', 'Where is customer data stored and how is consent recorded?', 'When were backups and recovery last tested?'],
    sources: pages.map((page) => page.url),
    evidence: pages,
  };
}

function parseJson(textValue) {
  const raw = textValue.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  try { return JSON.parse(raw); } catch { return null; }
}

async function aiReport(input, baseReport, env) {
  if (!env.AI_API_KEY || !env.AI_BASE_URL || !env.AI_MODEL) return baseReport;
  const evidence = baseReport.evidence.map((page) => ({ url: page.url, status: page.status, title: page.title, description: page.description, headings: page.headings, links: page.links, text: page.text })).slice(0, MAX_PAGES);
  const prompt = `You are Duta Integra's business health analyst. Analyze the public website evidence below. If public web search is available, use it only to check the identity of the supplied company name, registration number and website; do not access private systems. Do not invent facts, legal conclusions, customer numbers, security controls or revenue. If sources conflict, state the uncertainty. Return JSON only with keys: recommended_service (string), summary (string), findings (array of {title,detail}), confirm_with_team (array of strings), sources (array of URLs). Write in ${input.language === 'bm' ? 'Bahasa Malaysia' : 'English'}. Company: ${input.company}. Registration number: ${input.registrationNumber || 'not supplied'}. Requested focus: ${input.signals.join(', ') || 'all areas'}. Evidence: ${JSON.stringify(evidence)}`;
  const base = String(env.AI_BASE_URL).replace(/\/$/, '');
  try {
    let response;
    const provider = String(env.AI_PROVIDER || 'nim').toLowerCase();
    if (provider === 'openai') {
      // Use Chat Completions API (more widely available than Responses API)
      // Include web search via function calling if model supports it
      const tools = env.AI_ENABLE_WEB_SEARCH === 'true' ? [{ type: 'function', function: { name: 'web_search', description: 'Search the web for company identity verification', parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } } }] : [];
      response = await fetch(`${base}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.AI_API_KEY}` },
        body: JSON.stringify({ model: env.AI_MODEL, temperature: 0.1, messages: [{ role: 'user', content: prompt }], tools: tools.length ? tools : undefined, tool_choice: tools.length ? 'auto' : undefined })
      });
      const body = await response.json();
      if (!response.ok) {
        console.error('[business-health-check] OpenAI API error:', response.status, body);
        return baseReport;
      }
      const content = body.choices?.[0]?.message?.content || '';
      const parsed = parseJson(content);
      if (!parsed || typeof parsed !== 'object') {
        console.error('[business-health-check] Failed to parse OpenAI response:', content.slice(0, 500));
        return baseReport;
      }
      return mergeAiReport(baseReport, parsed);
    }
    // NIM or other OpenAI-compatible /chat/completions endpoint
    response = await fetch(`${base}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.AI_API_KEY}` }, body: JSON.stringify({ model: env.AI_MODEL, temperature: 0.1, messages: [{ role: 'user', content: prompt }] }) });
    const body = await response.json();
    if (!response.ok) {
      console.error('[business-health-check] AI provider error:', response.status, body);
      return baseReport;
    }
    const parsed = parseJson(body.choices?.[0]?.message?.content || '');
    if (!parsed || typeof parsed !== 'object') {
      console.error('[business-health-check] Failed to parse AI response:', body.choices?.[0]?.message?.content?.slice(0, 500));
      return baseReport;
    }
    return mergeAiReport(baseReport, parsed);
  } catch (err) {
    console.error('[business-health-check] AI request failed:', err);
    return baseReport;
  }
}

function mergeAiReport(baseReport, parsed, extraSources = []) {
  const allowedSources = new Set([...baseReport.sources, ...extraSources]);
  const sources = Array.isArray(parsed.sources)
    ? parsed.sources.map((source) => text(source, 2048)).filter((source) => allowedSources.has(source))
    : [];
  const findings = Array.isArray(parsed.findings)
    ? parsed.findings.slice(0, 8).map((finding) => ({
      title: text(finding && finding.title, 160),
      detail: text(finding && finding.detail, 800),
    })).filter((finding) => finding.title && finding.detail)
    : [];
  const confirm = Array.isArray(parsed.confirm_with_team)
    ? parsed.confirm_with_team.slice(0, 8).map((item) => text(item, 400)).filter(Boolean)
    : [];
  return {
    ...baseReport,
    recommended_service: text(parsed.recommended_service, 240) || baseReport.recommended_service,
    summary: text(parsed.summary, 1200) || baseReport.summary,
    findings: findings.length ? findings : baseReport.findings,
    confirm_with_team: confirm.length ? confirm : baseReport.confirm_with_team,
    sources: sources.length ? sources : baseReport.sources,
    mode: 'AI + public evidence',
    evidence: undefined,
  };
}

export async function onRequest(context) {
  const { request, env } = context;
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const gate = await allowedRequest(request, env);
  if (!gate.allowed) {
    return json(
      { error: gate.rateLimited ? 'Too many requests' : 'Forbidden origin' },
      gate.rateLimited ? 429 : 403,
      gate.rateLimited ? { 'Retry-After': '600' } : {},
    );
  }
  const length = Number(request.headers.get('Content-Length') || 0);
  if (length > MAX_BODY_BYTES) return json({ error: 'Request body too large' }, 413);
  let body;
  try { body = await request.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return json({ error: 'Invalid payload' }, 400);
  for (const field of ['company', 'registrationNumber', 'website', 'language']) {
    if (body[field] != null && typeof body[field] !== 'string') return json({ error: `${field} is invalid` }, 400);
  }
  if (new TextEncoder().encode(JSON.stringify(body)).byteLength > MAX_BODY_BYTES) return json({ error: 'Request body too large' }, 413);
  const input = {
    company: text(body.company, 160),
    registrationNumber: text(body.registrationNumber, 40),
    website: text(body.website, 2048),
    language: body.language === 'bm' ? 'bm' : 'en',
    signals: Array.isArray(body.signals) ? body.signals.filter((signal) => ALLOWED_SIGNALS.has(signal)).slice(0, 4) : [],
  };
  if (!input.company || !safeUrl(input.website)) return json({ error: 'Company and a valid public website are required' }, 400);
  const crawled = await crawl(input.website);
  if (!crawled.pages.length) return json({ error: 'The public website could not be read' }, 422);
  const report = deterministicReport(input, crawled);
  const finalReport = await aiReport(input, report, env);
  delete finalReport.evidence;
  return json(finalReport);
}
